package com.mindrush.app

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.mindrush.app.data.AnswerEventEntity
import com.mindrush.app.data.AppDatabase
import com.mindrush.app.data.SessionEntity
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class DatabaseTest {
    private lateinit var db: AppDatabase

    @Before fun setUp() {
        val ctx = ApplicationProvider.getApplicationContext<Context>()
        db = Room.inMemoryDatabaseBuilder(ctx, AppDatabase::class.java).build()
    }

    @After fun tearDown() = db.close()

    private fun session() = SessionEntity(
        sessionUuid = "u1", gameId = "addition", mode = "SPEED", status = "COMPLETED", startedAt = 1, endedAt = 2,
        durationMs = 1, score = 10, correct = 1, wrong = 0, skipped = 0, unanswered = 0, accuracy = 1.0,
        meanMs = 100, medianMs = 100, bestStreak = 1, startLevel = 1, endLevel = 1, fixedLevel = false,
        dayKey = "2026-10-13", scoringVersion = 1
    )

    @Test fun duplicateAnswerEventsAreIgnored() = runBlocking {
        val id = db.sessions().insert(session())
        val e = AnswerEventEntity("u1:0", id, "addition", null, null, 0, 1, true, false, 100, 80, 5, "")
        db.events().insertAll(listOf(e))
        db.events().insertAll(listOf(e))
        assertEquals(1, db.events().forSession(id).size)
    }

    @Test fun deletingASessionCascadesToItsEvents() = runBlocking {
        val id = db.sessions().insert(session())
        db.events().insertAll(listOf(AnswerEventEntity("u1:0", id, "addition", null, null, 0, 1, true, false, 100, 80, 5, "")))
        db.sessions().delete(id)
        assertEquals(0, db.events().forSession(id).size)
    }
}
