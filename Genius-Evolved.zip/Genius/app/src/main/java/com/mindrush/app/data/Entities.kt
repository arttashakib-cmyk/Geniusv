package com.mindrush.app.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "sessions",
    indices = [Index(value = ["sessionUuid"], unique = true), Index("gameId"), Index("dayKey"), Index("startedAt")]
)
data class SessionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sessionUuid: String,
    val gameId: String,
    val mode: String,
    /** COMPLETED, ABANDONED or INTERRUPTED (row created at start, finalized at end). */
    val status: String,
    val startedAt: Long,
    val endedAt: Long?,
    val durationMs: Long,
    val score: Int,
    val correct: Int,
    val wrong: Int,
    val skipped: Int,
    val unanswered: Int,
    val accuracy: Double,
    val meanMs: Long?,
    val medianMs: Long?,
    val bestStreak: Int,
    val startLevel: Int,
    val endLevel: Int,
    val fixedLevel: Boolean,
    val dayKey: String,
    val scoringVersion: Int
)

@Entity(
    tableName = "answer_events",
    foreignKeys = [ForeignKey(entity = SessionEntity::class, parentColumns = ["id"], childColumns = ["sessionId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("sessionId"), Index("gameId"), Index("answeredAt")]
)
data class AnswerEventEntity(
    /** "<sessionUuid>:<index>" - unique, so duplicate inserts are ignored. */
    @PrimaryKey val eventId: String,
    val sessionId: Long,
    val gameId: String,
    val subGameId: String?,
    val component: String?,
    val questionIndex: Int,
    val level: Int,
    val correct: Boolean,
    val skipped: Boolean,
    val responseMs: Long?,
    val points: Int,
    val answeredAt: Long,
    val meta: String
)

@Entity(tableName = "personal_records")
data class PersonalRecordEntity(
    @PrimaryKey val key: String,
    val gameId: String,
    val mode: String,
    val bestScore: Int,
    val bestAchievedAt: Long,
    val lastScore: Int,
    val previousScore: Int?
)

@Entity(tableName = "difficulty_profiles")
data class DifficultyProfileEntity(
    @PrimaryKey val gameId: String,
    val level: Int,
    val updatedAt: Long,
    val answeredCount: Int
)

@Entity(tableName = "daily_summaries", indices = [Index("dayKey")])
data class DailySummaryEntity(
    @PrimaryKey val key: String,
    val dayKey: String,
    val gameId: String,
    val sessions: Int,
    val answered: Int,
    val correct: Int,
    val score: Int,
    val durationMs: Long
)

@Entity(tableName = "achievements")
data class AchievementEntity(
    @PrimaryKey val id: String,
    val unlockedAt: Long
)

data class GameAggregate(
    val gameId: String,
    val sessions: Int,
    val totalScore: Int,
    val correct: Int,
    val wrong: Int,
    val skipped: Int,
    val bestStreak: Int
)

data class StatusCount(val status: String, val n: Int)
data class ComponentAggregate(val component: String, val total: Int, val correct: Int)
data class DayTotals(val sessions: Int, val answered: Int, val correct: Int, val score: Int)

@Entity(tableName = "user_progress")
data class UserProgressEntity(
    @PrimaryKey val id: Int = 1,
    val totalXp: Int = 0,
    val level: Int = 1,
    val lastDailyKey: String = "",
    val dailyCompleted: Int = 0,
    val updatedAt: Long = 0
)

@Entity(tableName = "daily_missions", indices = [Index("dayKey")])
data class DailyMissionEntity(
    @PrimaryKey val id: String,
    val dayKey: String,
    val gameId: String,
    val mode: String,
    val targetCorrect: Int,
    val completed: Boolean,
    val progress: Int,
    val xpReward: Int
)

@Entity(tableName = "skill_stats", indices = [Index("skillId")])
data class SkillStatEntity(
    @PrimaryKey val skillId: String,
    val sampleCount: Int,
    val correctCount: Int,
    val totalResponseMs: Long,
    val lastPlayedAt: Long,
    val bestAccuracy: Double
)
