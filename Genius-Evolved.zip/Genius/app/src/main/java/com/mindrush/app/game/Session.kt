package com.mindrush.app.game

import com.mindrush.app.core.Clock
import kotlin.random.Random

data class SessionConfig(
    val sessionId: String,
    val gameId: String,
    val mode: GameMode,
    val durationSec: Int,
    val questionCount: Int,
    val lives: Int,
    val fixedLevel: Int?,
    val startLevel: Int,
    val seed: Long
)

enum class Phase { READY, ACTIVE, PAUSED, FINISHED }
enum class FinishReason { TIME_UP, QUESTIONS_DONE, LIVES_OUT, USER_EXIT }
enum class SessionStatus { COMPLETED, ABANDONED, INTERRUPTED }

data class Feedback(
    val seq: Int,
    val correct: Boolean,
    val skipped: Boolean,
    val points: Int,
    val explanation: String
)

data class AnswerRecord(
    val index: Int,
    val questionId: String,
    val gameId: String,
    val subGameId: String?,
    val component: String?,
    val level: Int,
    val correct: Boolean,
    val skipped: Boolean,
    val responseMs: Long?,
    val points: Int,
    val answeredAtWall: Long,
    val meta: String
)

data class SessionState(
    val phase: Phase = Phase.READY,
    val question: Question? = null,
    val presentationKey: Int = 0,
    val questionNumber: Int = 0,
    val totalQuestions: Int? = null,
    val score: Int = 0,
    val correct: Int = 0,
    val wrong: Int = 0,
    val skipped: Int = 0,
    val streak: Int = 0,
    val bestStreak: Int = 0,
    val lives: Int? = null,
    val level: Int = 1,
    val displayMs: Long = 0,
    val countdown: Boolean = false,
    val feedback: Feedback? = null,
    val awaitingAdvance: Boolean = false,
    val finishReason: FinishReason? = null
)

data class ComponentStat(val total: Int, val correct: Int)

data class SessionSummary(
    val correct: Int,
    val wrong: Int,
    val skipped: Int,
    val accuracy: Double,
    val meanMs: Long?,
    val medianMs: Long?,
    val bestStreak: Int,
    val components: Map<String, ComponentStat>
)

object SessionAnalytics {
    fun summarize(records: List<AnswerRecord>): SessionSummary {
        val answered = records.filter { !it.skipped }
        val correct = answered.count { it.correct }
        val wrong = answered.size - correct
        val skipped = records.count { it.skipped }
        val accuracy = if (answered.isEmpty()) 0.0 else correct.toDouble() / answered.size
        val times = answered.mapNotNull { it.responseMs }.sorted()
        val mean = if (times.isEmpty()) null else times.sum() / times.size
        val median = if (times.isEmpty()) null else {
            val n = times.size
            if (n % 2 == 1) times[n / 2] else (times[n / 2 - 1] + times[n / 2]) / 2
        }
        var streak = 0
        var best = 0
        for (r in records) {
            if (r.correct) { streak++; if (streak > best) best = streak } else streak = 0
        }
        val comps = LinkedHashMap<String, ComponentStat>()
        for (r in answered) {
            val c = r.component ?: continue
            val old = comps[c] ?: ComponentStat(0, 0)
            comps[c] = ComponentStat(old.total + 1, old.correct + if (r.correct) 1 else 0)
        }
        return SessionSummary(correct, wrong, skipped, accuracy, mean, median, best, comps)
    }
}

data class SessionResult(
    val config: SessionConfig,
    val status: SessionStatus,
    val reason: FinishReason,
    val startedAtWall: Long,
    val endedAtWall: Long,
    val durationMs: Long,
    val score: Int,
    val correct: Int,
    val wrong: Int,
    val skipped: Int,
    val unanswered: Int,
    val accuracy: Double,
    val meanMs: Long?,
    val medianMs: Long?,
    val bestStreak: Int,
    val startLevel: Int,
    val endLevel: Int,
    val records: List<AnswerRecord>,
    val components: Map<String, ComponentStat>,
    val scoringVersion: Int
)

object ResultCalculator {
    fun compute(
        config: SessionConfig,
        reason: FinishReason,
        startedWall: Long,
        endedWall: Long,
        durationMs: Long,
        records: List<AnswerRecord>,
        unanswered: Int,
        startLevel: Int,
        endLevel: Int
    ): SessionResult {
        val s = SessionAnalytics.summarize(records)
        return SessionResult(
            config = config,
            status = if (reason == FinishReason.USER_EXIT) SessionStatus.ABANDONED else SessionStatus.COMPLETED,
            reason = reason,
            startedAtWall = startedWall,
            endedAtWall = endedWall,
            durationMs = durationMs,
            score = records.sumOf { it.points },
            correct = s.correct,
            wrong = s.wrong,
            skipped = s.skipped,
            unanswered = unanswered,
            accuracy = s.accuracy,
            meanMs = s.meanMs,
            medianMs = s.medianMs,
            bestStreak = s.bestStreak,
            startLevel = startLevel,
            endLevel = endLevel,
            records = records,
            components = s.components,
            scoringVersion = ScoringEngine.VERSION
        )
    }
}

/**
 * Pure (Android-free) session state machine shared by all 20 games and all 3 modes.
 * Call from a single thread. Rules:
 *  - a question can be answered once (duplicate ids are ignored);
 *  - response time starts only when input really begins ([beginInput]);
 *  - paused / explanation-reading time is excluded from elapsed time;
 *  - the round ends exactly once ([finish]).
 */
class GameSessionEngine(
    val config: SessionConfig,
    private val game: GameDefinition,
    private val clock: Clock,
    private val difficulty: AdaptiveDifficultyEngine,
    private val wallClock: () -> Long = { System.currentTimeMillis() }
) {
    private val rng = Random(config.seed)
    private val scratch = mutableMapOf<String, Any>()
    private val records = ArrayList<AnswerRecord>()
    private val answeredIds = HashSet<String>()

    private var phase = Phase.READY
    private var question: Question? = null
    private var questionSeq = 0
    private var inputStartedAt: Long? = null
    private var startedAt = 0L
    private var startedWall = 0L
    private var endedWall = 0L
    private var frozenAt: Long? = null
    private var frozenTotal = 0L
    private var score = 0
    private var correct = 0
    private var wrong = 0
    private var skipped = 0
    private var streak = 0
    private var bestStreak = 0
    private var lives: Int? = null
    private var level = config.fixedLevel ?: config.startLevel
    private val startLevel = level
    private var feedbackSeq = 0
    private var feedback: Feedback? = null
    private var awaiting = false
    private var presentationKey = 0
    private var finishReason: FinishReason? = null
    private var lastSignature: String? = null
    private var unanswered = 0

    private val timeLimitMs: Long? = when (config.mode) {
        GameMode.SPEED, GameMode.SURVIVAL -> config.durationSec * 1000L
        GameMode.ACCURACY -> null
    }

    fun start() {
        if (phase != Phase.READY) return
        startedAt = clock.nowMs()
        startedWall = wallClock()
        if (config.mode == GameMode.SURVIVAL) lives = config.lives
        phase = Phase.ACTIVE
        nextQuestion()
    }

    fun elapsedMs(): Long {
        if (phase == Phase.READY) return 0L
        val now = frozenAt ?: clock.nowMs()
        return (now - startedAt - frozenTotal).coerceAtLeast(0)
    }

    private fun freeze() { if (frozenAt == null) frozenAt = clock.nowMs() }
    private fun unfreeze() {
        val f = frozenAt ?: return
        frozenTotal += clock.nowMs() - f
        frozenAt = null
    }

    fun pause() {
        if (phase != Phase.ACTIVE) return
        freeze()
        phase = Phase.PAUSED
    }

    fun resume() {
        if (phase != Phase.PAUSED) return
        phase = Phase.ACTIVE
        if (!awaiting) {
            unfreeze()
            // The presentation restarts, so timing restarts too (no unfair or misleading timestamps).
            presentationKey++
            inputStartedAt = if (question?.body.isImmediateInput()) clock.nowMs() else null
        }
    }

    /** Called by the UI when the answer phase really begins (after memory display / reaction stimulus onset). */
    fun beginInput(questionId: String) {
        if (phase == Phase.ACTIVE && question?.id == questionId && inputStartedAt == null && !awaiting) {
            inputStartedAt = clock.nowMs()
        }
    }

    fun tick() {
        if (phase != Phase.ACTIVE || awaiting) return
        val limit = timeLimitMs ?: return
        if (elapsedMs() >= limit) finish(FinishReason.TIME_UP)
    }

    /** Returns true if the answer was accepted. */
    fun submit(questionId: String, answer: Answer): Boolean {
        val q = question ?: return false
        if (phase != Phase.ACTIVE || awaiting) return false
        if (q.id != questionId) return false
        if (!answeredIds.add(q.id)) return false

        val verdict = game.evaluate(q, answer)
        val rt = if (verdict.skipped) null else inputStartedAt?.let { clock.nowMs() - it }
        val effectiveGame = GameRegistry.byId(q.subGameId ?: q.gameId) ?: game
        val target = effectiveGame.targetTimeMs(q.level)
        val points = ScoringEngine.questionPoints(q.body, q.level, target, rt, verdict)

        score += points
        when {
            verdict.skipped -> { skipped++; streak = 0 }
            verdict.correct -> { correct++; streak++; if (streak > bestStreak) bestStreak = streak }
            else -> { wrong++; streak = 0 }
        }
        if (config.mode == GameMode.SURVIVAL && !verdict.correct) lives = (lives ?: 0) - 1

        records.add(
            AnswerRecord(
                index = records.size, questionId = q.id, gameId = q.gameId, subGameId = q.subGameId,
                component = q.component, level = q.level, correct = verdict.correct,
                skipped = verdict.skipped, responseMs = rt, points = points,
                answeredAtWall = wallClock(), meta = q.meta
            )
        )
        if (config.fixedLevel == null && config.mode != GameMode.SURVIVAL && !verdict.skipped) {
            level = difficulty.record(AdaptiveDifficultyEngine.Sample(verdict.correct, rt, target))
        }
        feedback = Feedback(++feedbackSeq, verdict.correct, verdict.skipped, points, explanationOf(q.body))
        question = q

        if (config.mode == GameMode.ACCURACY && !verdict.correct && !verdict.skipped) {
            awaiting = true
            freeze()
        } else {
            advanceInternal()
        }
        return true
    }

    fun skip(questionId: String): Boolean = submit(questionId, Answer.Skip)

    /** Continue after reading the explanation (Accuracy mode). */
    fun advance() {
        if (phase == Phase.FINISHED || !awaiting) return
        awaiting = false
        if (phase == Phase.ACTIVE) unfreeze()
        advanceInternal()
    }

    private fun advanceInternal() {
        if (phase != Phase.ACTIVE) return
        if (config.mode == GameMode.SURVIVAL && (lives ?: 0) <= 0) { finish(FinishReason.LIVES_OUT); return }
        if (config.mode == GameMode.ACCURACY && records.size >= config.questionCount) {
            finish(FinishReason.QUESTIONS_DONE); return
        }
        val limit = timeLimitMs
        if (limit != null && elapsedMs() >= limit) { question = null; finish(FinishReason.TIME_UP); return }
        nextQuestion()
    }

    private fun nextQuestion() {
        questionSeq++
        level = when {
            config.fixedLevel != null -> config.fixedLevel
            config.mode == GameMode.SURVIVAL -> minOf(10, config.startLevel + correct / 4)
            else -> difficulty.level
        }
        var q: Question? = null
        for (attempt in 0 until 5) {
            val ctx = GenContext(level, rng, questionSeq, config.sessionId, game.id, scratch)
            val candidate = game.generate(ctx)
            val sig = candidate.body.toString()
            q = candidate
            if (sig != lastSignature) break
        }
        val finalQ = q!!
        lastSignature = finalQ.body.toString()
        question = finalQ
        presentationKey++
        inputStartedAt = if (finalQ.body.isImmediateInput()) clock.nowMs() else null
    }

    fun finish(reason: FinishReason) {
        if (phase == Phase.FINISHED) return
        val q = question
        unanswered = if (q != null && !answeredIds.contains(q.id)) 1 else 0
        freeze()
        endedWall = wallClock()
        phase = Phase.FINISHED
        finishReason = reason
    }

    fun state(): SessionState {
        val limit = timeLimitMs
        val elapsed = elapsedMs()
        return SessionState(
            phase = phase,
            question = if (phase == Phase.FINISHED) null else question,
            presentationKey = presentationKey,
            questionNumber = if (config.mode == GameMode.ACCURACY) minOf(records.size + 1, config.questionCount) else records.size + 1,
            totalQuestions = if (config.mode == GameMode.ACCURACY) config.questionCount else null,
            score = score, correct = correct, wrong = wrong, skipped = skipped,
            streak = streak, bestStreak = bestStreak, lives = lives, level = level,
            displayMs = if (limit != null) (limit - elapsed).coerceAtLeast(0) else elapsed,
            countdown = limit != null,
            feedback = feedback,
            awaitingAdvance = awaiting,
            finishReason = finishReason
        )
    }

    /** Only valid after [finish]. */
    fun result(): SessionResult = ResultCalculator.compute(
        config, finishReason ?: FinishReason.USER_EXIT, startedWall, endedWall,
        elapsedMs(), records.toList(), unanswered, startLevel, level
    )

    private fun explanationOf(b: QBody): String = when (b) {
        is ChoiceBody -> b.explanation
        is PickBody -> b.explanation
        is RecallBody -> b.explanation
        is GridBody -> b.explanation
        is ReactionBody -> b.explanation
    }

    private fun QBody?.isImmediateInput(): Boolean = this is ChoiceBody || this is PickBody
}
