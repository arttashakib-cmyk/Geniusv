package com.mindrush.app.feature

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

private val zoneChoices = listOf(
    "Asia/Tehran" to "تهران",
    "Asia/Dubai" to "دبی",
    "Europe/Istanbul" to "استانبول",
    "Europe/London" to "لندن",
    "Europe/Berlin" to "برلین",
    "America/New_York" to "نیویورک",
    "UTC" to "UTC"
)

@Composable
fun SettingsScreen(vm: MainViewModel) {
    val st by vm.settings.collectAsState()
    val message by vm.message.collectAsState()
    var confirmDelete by remember { mutableStateOf(false) }
    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) vm.export(uri)
    }
    val s = st ?: return

    Column(
        Modifier.fillMaxSize().background(GenColors.bg).verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        FText("تنظیمات", fontSize = 26.sp, fontWeight = FontWeight.Bold)
        if (message != null) {
            GCard(onClick = { vm.clearMessage() }) { FText(message ?: "", color = GenColors.accent) }
        }

        SectionTitle("نمایش اعداد")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Chip("ارقام فارسی ۱۲۳", s.persianDigits) { vm.update { it.copy(persianDigits = true) } }
            Chip("ارقام لاتین 123", !s.persianDigits) { vm.update { it.copy(persianDigits = false) } }
        }

        SectionTitle("مدت حالت سرعتی")
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            for (d in listOf(30, 60, 90, 120)) Chip("$d ثانیه", s.speedDurationSec == d) { vm.update { it.copy(speedDurationSec = d) } }
        }
        SectionTitle("تعداد سؤال حالت دقتی")
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            for (n in listOf(10, 20, 30, 50)) Chip("$n", s.accuracyQuestions == n) { vm.update { it.copy(accuracyQuestions = n) } }
        }
        SectionTitle("جان‌ها در حالت بقا")
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            for (n in listOf(1, 3, 5)) Chip("$n", s.survivalLives == n) { vm.update { it.copy(survivalLives = n) } }
        }
        SectionTitle("حداکثر زمان حالت بقا")
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            for (d in listOf(120, 180, 300)) Chip("${d / 60} دقیقه", s.survivalDurationSec == d) { vm.update { it.copy(survivalDurationSec = d) } }
        }

        SectionTitle("منطقه‌ی زمانی (برای خلاصه‌ی روزانه)")
        FText("فعلی: ${s.timeZoneId}", fontSize = 13.sp, color = GenColors.muted)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Chip("پیش‌فرض دستگاه", s.timeZoneId == TimeZone.getDefault().id) { vm.changeTimeZone(TimeZone.getDefault().id) }
            for ((id, name) in zoneChoices) Chip(name, s.timeZoneId == id) { vm.changeTimeZone(id) }
        }

        SectionTitle("داده‌ها")
        FText("همه‌ی اطلاعات فقط روی همین دستگاه ذخیره می‌شود و بدون اجازه‌ی تو جایی فرستاده نمی‌شود.", fontSize = 13.sp, color = GenColors.muted)
        SecondaryButton("خروجی گرفتن از داده‌ها (JSON)") {
            val stamp = SimpleDateFormat("yyyyMMdd-HHmm", Locale.US).format(Date())
            exportLauncher.launch("genius-export-$stamp.json")
        }
        SecondaryButton("ساخت دوباره‌ی خلاصه‌ها و رکوردها") { vm.rebuild() }
        SecondaryButton("حذف کامل همه‌ی داده‌ها") { confirmDelete = true }

        SectionTitle("درباره")
        GCard {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                FText("Genius نسخه‌ی 1.0.0", fontWeight = FontWeight.Bold)
                FText("مجموعه‌ی ۲۰ بازی ذهنی آفلاین. امتیاز و سطح، شاخص‌های بازی هستند و نمره‌ی هوش یا ارزیابی پزشکی به حساب نمی‌آیند.", fontSize = 13.sp, color = GenColors.muted)
            }
        }
        Spacer(Modifier.height(16.dp))
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { FText("حذف همه‌ی داده‌ها؟", fontWeight = FontWeight.Bold) },
            text = { FText("همه‌ی سوابق، رکوردها، دستاوردها و تنظیمات برای همیشه پاک می‌شود و برگشت‌پذیر نیست.") },
            confirmButton = { TextButton(onClick = { confirmDelete = false; vm.deleteAll() }) { FText("حذف کن", color = GenColors.bad) } },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { FText("انصراف") } }
        )
    }
}
