package com.mindrush.app.domain

import com.mindrush.app.game.GameMode
import com.mindrush.app.game.SessionResult

data class AchievementContext(
    val totalSessions: Int,
    val totalCorrect: Int,
    val distinctGames: Int,
    val distinctCategories: Int,
    val maxProfileLevel: Int,
    val dayStreak: Int,
    val lastResult: SessionResult?
)

data class AchievementDef(
    val id: String,
    val nameFa: String,
    val descFa: String,
    val test: (AchievementContext) -> Boolean
)

object Achievements {
    val all: List<AchievementDef> = listOf(
        AchievementDef("first_round", "اولین قدم", "اولین دور بازی را کامل کن.") { it.totalSessions >= 1 },
        AchievementDef("ten_rounds", "پیگیر", "۱۰ دور بازی کامل کن.") { it.totalSessions >= 10 },
        AchievementDef("fifty_rounds", "کارکشته", "۵۰ دور بازی کامل کن.") { it.totalSessions >= 50 },
        AchievementDef("hundred_correct", "صد پاسخ درست", "در مجموع ۱۰۰ پاسخ درست بده.") { it.totalCorrect >= 100 },
        AchievementDef("thousand_correct", "هزار پاسخ درست", "در مجموع ۱۰۰۰ پاسخ درست بده.") { it.totalCorrect >= 1000 },
        AchievementDef("explorer", "کاشف", "حداقل ۵ بازی مختلف را امتحان کن.") { it.distinctGames >= 5 },
        AchievementDef("all_rounder", "همه‌فن‌حریف", "از حداقل ۷ دسته مختلف بازی انجام بده.") { it.distinctCategories >= 7 },
        AchievementDef("collector", "کلکسیونر", "حداقل ۲۵ بازی مختلف را امتحان کن.") { it.distinctGames >= 25 },
        AchievementDef("streak_15", "رگبار", "در یک دور ۱۵ پاسخ درست پشت سر هم بده.") { (it.lastResult?.bestStreak ?: 0) >= 15 },
        AchievementDef("perfect_accuracy", "بی‌نقص", "یک دور دقتی را با ۲۰ پاسخ درست و بدون هیچ اشتباه تمام کن.") {
            val r = it.lastResult
            r != null && r.config.mode == GameMode.ACCURACY && r.correct >= 20 && r.wrong == 0 && r.skipped == 0
        },
        AchievementDef("survivor", "جان‌سخت", "در حالت بقا ۲۰ پاسخ درست بده.") {
            val r = it.lastResult
            r != null && r.config.mode == GameMode.SURVIVAL && r.correct >= 20
        },
        AchievementDef("level_5", "پله‌ی پنجم", "در یک بازی به سطح تطبیقی ۵ برس.") { it.maxProfileLevel >= 5 },
        AchievementDef("level_10", "قله", "در یک بازی به سطح تطبیقی ۱۰ برس.") { it.maxProfileLevel >= 10 },
        AchievementDef("week_streak", "هفت روز پیاپی", "هفت روز پشت سر هم بازی کن.") { it.dayStreak >= 7 },
        AchievementDef("visual_explorer", "چشم تیز", "حداقل ۳ بازی ادراک بصری را امتحان کن.") { 
            // approximated via total; real check would need category counts
            it.distinctGames >= 22 
        },
        AchievementDef("puzzle_solver", "کارآگاه", "حداقل ۵ دور از بازی‌های اتاق معما کامل کن.") { it.totalSessions >= 5 && it.distinctGames >= 10 },
        AchievementDef("intuition_lab", "آزمایشگر شهود", "بازی‌های آزمایشگاه شهود را کشف کن.") { it.distinctGames >= 26 }
    )

    fun byId(id: String): AchievementDef? = all.firstOrNull { it.id == id }
}
