package com.mindrush.app.game

import kotlin.random.Random

/** Everything a generator needs for one question. [scratch] persists across questions of one session. */
class GenContext(
    val level: Int,
    val rng: Random,
    val index: Int,
    val sessionId: String,
    val gameId: String,
    val scratch: MutableMap<String, Any> = mutableMapOf()
) {
    fun question(body: QBody, meta: String = ""): Question =
        Question("$sessionId-$index", gameId, level, null, null, meta, body)

    fun child(otherGameId: String): GenContext =
        GenContext(level, rng, index, sessionId, otherGameId, scratch)
}

interface GameDefinition {
    val id: String
    val nameFa: String
    val category: Category
    val emoji: String
    val shortDescFa: String
    val instructionsFa: String

    /** Expected response time in ms for the given level (used by scoring and adaptive difficulty). */
    fun targetTimeMs(level: Int): Long

    fun generate(ctx: GenContext): Question

    fun evaluate(question: Question, answer: Answer): Verdict = AnswerEvaluator.evaluate(question, answer)
}

abstract class BaseGame(
    override val id: String,
    override val nameFa: String,
    override val category: Category,
    override val emoji: String,
    override val shortDescFa: String,
    override val instructionsFa: String,
    private val baseTargetMs: Long,
    private val stepMs: Long
) : GameDefinition {
    override fun targetTimeMs(level: Int): Long = (baseTargetMs + stepMs * (level - 1)).coerceAtLeast(300L)
}

object GameUtil {
    fun pow10(n: Int): Long {
        var r = 1L
        repeat(n) { r *= 10 }
        return r
    }

    /** Random number with exactly [digits] digits (1 digit => 1..9). */
    fun randomWithDigits(rng: Random, digits: Int): Long {
        val lo = if (digits <= 1) 1L else pow10(digits - 1)
        val hi = pow10(digits) - 1
        return rng.nextLong(lo, hi + 1)
    }

    /**
     * Four distinct numeric options containing [correct]; returns (options as text, index of correct).
     * Bounded attempts, then deterministic fallback so it never loops forever.
     */
    fun numericOptions(
        rng: Random,
        correct: Long,
        spread: Long,
        count: Int = 4,
        nonNegative: Boolean = false
    ): Pair<List<String>, Int> {
        val set = LinkedHashSet<Long>()
        set.add(correct)
        val sp = if (spread < 2) 2L else spread
        var attempts = 0
        while (set.size < count && attempts < 120) {
            attempts++
            val delta = when (rng.nextInt(4)) {
                0 -> 1L
                1 -> 10L
                else -> rng.nextLong(1, sp + 1)
            }
            val c = if (rng.nextBoolean()) correct + delta else correct - delta
            if (nonNegative && c < 0) continue
            set.add(c)
        }
        var k = 1L
        while (set.size < count) {
            set.add(correct + k)
            k++
        }
        val list = set.toList().shuffled(rng)
        return list.map { it.toString() } to list.indexOf(correct)
    }

    fun numericChoice(
        ctx: GenContext,
        prompt: String,
        expression: String?,
        correct: Long,
        spread: Long,
        explanation: String,
        nonNegative: Boolean = false,
        meta: String = ""
    ): Question {
        val (opts, idx) = numericOptions(ctx.rng, correct, spread, 4, nonNegative)
        return ctx.question(
            ChoiceBody(prompt, expression, emptyList(), opts, emptyList(), idx, explanation),
            meta
        )
    }

    fun <T> pick(rng: Random, list: List<T>): T = list[rng.nextInt(list.size)]
}

/** Minimal, independent arithmetic evaluator for strings like "12 + 3 × 4" (used by tests and fallbacks). */
object Arith {
    fun evaluate(expr: String): Long? {
        val tokens = tokenize(expr) ?: return null
        if (tokens.isEmpty() || tokens.size % 2 == 0) return null
        val nums = ArrayList<Long>()
        val ops = ArrayList<Char>()
        for ((i, t) in tokens.withIndex()) {
            if (i % 2 == 0) nums.add(t.toLongOrNull() ?: return null) else ops.add(t[0])
        }
        return evalList(nums, ops)
    }

    fun evalList(nums: List<Long>, ops: List<Char>): Long? {
        val vals = nums.toMutableList()
        val o = ops.toMutableList()
        var i = 0
        while (i < o.size) {
            when (o[i]) {
                '×', '*' -> {
                    vals[i] = vals[i] * vals[i + 1]
                    vals.removeAt(i + 1); o.removeAt(i)
                }
                '÷', '/' -> {
                    if (vals[i + 1] == 0L || vals[i] % vals[i + 1] != 0L) return null
                    vals[i] = vals[i] / vals[i + 1]
                    vals.removeAt(i + 1); o.removeAt(i)
                }
                else -> i++
            }
        }
        var r = vals[0]
        for (j in o.indices) {
            r = if (o[j] == '+') r + vals[j + 1] else r - vals[j + 1]
        }
        return r
    }

    private fun tokenize(expr: String): List<String>? {
        val out = ArrayList<String>()
        var cur = StringBuilder()
        for (c in expr) {
            when {
                c.isDigit() -> cur.append(c)
                c == ' ' -> Unit
                c in "+-−×÷*/" -> {
                    if (cur.isEmpty()) return null
                    out.add(cur.toString()); cur = StringBuilder()
                    out.add(if (c == '−') "-" else c.toString())
                }
                else -> return null
            }
        }
        if (cur.isEmpty()) return null
        out.add(cur.toString())
        return out
    }
}
