package com.mindrush.app.game.games

import com.mindrush.app.game.*
import kotlin.math.max

/** Shared color palette semantics: index -> (Persian name, marker shape). Colors are never the only cue. */
object GamePalette {
    val names = listOf("قرمز", "آبی", "سبز", "زرد")
    val markers = listOf("●", "■", "▲", "◆")
}

/** 13. Target search */
object TargetSearchGame : BaseGame(
    "target_search", "جست‌وجوی هدف", Category.ATTENTION, "🔍",
    "هدف را بین حواس‌پرت‌کن‌ها پیدا کن",
    "نماد هدف بالای صفحه نشان داده می‌شود. آن را در میان نمادهای شبیه به هم پیدا کن و روی آن بزن. فقط یک هدف در شبکه هست.",
    4500, 500
) {
    private val sets = listOf(
        listOf("O", "Q", "C", "G", "D"),
        listOf("b", "d", "p", "q"),
        listOf("6", "9", "8", "0", "3"),
        listOf("M", "N", "W", "H", "V"),
        listOf("E", "F", "B", "P", "R"),
        listOf("S", "5", "2", "Z", "7"),
        listOf("◐", "◑", "◒", "◓")
    )

    override fun generate(ctx: GenContext): Question {
        val rng = ctx.rng
        val l = ctx.level
        val set = GameUtil.pick(rng, sets)
        val target = GameUtil.pick(rng, set)
        val count = minOf(30, 6 + l * 2)
        val similar = set.filter { it != target }
        val others = sets.filter { it !== set }.flatten()
        val pool = if (l >= 5) similar else similar + others.shuffled(rng).take(4)
        val distractors = List(count - 1) { GameUtil.pick(rng, if (l >= 5) similar else if (rng.nextInt(100) < 60) similar else pool) }
        val items = (distractors + target).shuffled(rng)
        val idx = items.indexOf(target)
        val cols = if (count <= 12) 4 else if (count <= 20) 5 else 6
        return ctx.question(
            PickBody(
                "هدف را پیدا کن و روی آن بزن.", listOf(Glyph(target, description = "هدف")),
                items.map { Glyph(it) }, cols, idx, "هدف «$target» در خانه‌ی شماره‌ی ${idx + 1} بود."
            ),
            "target:$target:${items.joinToString("")}"
        )
    }
}

/** 14. Rapid match */
object RapidMatchGame : BaseGame(
    "rapid_match", "تطبیق سریع", Category.ATTENTION, "👀",
    "بگو دو نماد یکسان‌اند یا متفاوت",
    "دو رشته‌ی نماد می‌بینی. اگر دقیقاً یکسان‌اند «یکسان» و اگر حتی یک نماد یا ترتیب فرق دارد «متفاوت» را بزن.",
    2500, 300
) {
    private val alphabets = listOf("▲▼◀▶●■◆★", "bdpqnumw", "0123456789")

    override fun generate(ctx: GenContext): Question {
        val rng = ctx.rng
        val l = ctx.level
        val alphabet = alphabets[if (l <= 3) 0 else rng.nextInt(alphabets.size)]
        val len = 2 + l / 3
        val a = List(len) { alphabet[rng.nextInt(alphabet.length)] }
        val same = rng.nextBoolean()
        var b = a.toMutableList()
        if (!same) {
            var changed = false
            if (l >= 4 && rng.nextBoolean()) {
                val i = rng.nextInt(len - 1)
                if (b[i] != b[i + 1]) { val t = b[i]; b[i] = b[i + 1]; b[i + 1] = t; changed = true }
            }
            if (!changed) {
                val i = rng.nextInt(len)
                var c = alphabet[rng.nextInt(alphabet.length)]
                var guard = 0
                while (c == b[i] && guard < 50) { c = alphabet[rng.nextInt(alphabet.length)]; guard++ }
                if (c == b[i]) c = alphabet[(alphabet.indexOf(b[i]) + 1) % alphabet.length]
                b[i] = c
            }
        }
        val sa = a.joinToString(" "); val sb = b.joinToString(" ")
        val isSame = sa == sb
        return ctx.question(
            ChoiceBody(
                "این دو یکسان‌اند؟", null, listOf(Glyph(sa, description = "اول"), Glyph(sb, description = "دوم")),
                listOf("یکسان", "متفاوت"), emptyList(), if (isSame) 0 else 1,
                if (isSame) "هر دو دقیقاً «$sa» هستند." else "«$sa» و «$sb» در چیدمان یا یکی از نمادها تفاوت دارند."
            ),
            "match:$sa|$sb"
        )
    }
}

/** 15. Color and direction (Stroop-like with explicit active rule and non-color cues). */
object ColorDirectionGame : BaseGame(
    "color_direction", "رنگ و جهت", Category.ATTENTION, "🎨",
    "قانون را دنبال کن، نه حواس‌پرتی را",
    "قانون فعال بالای هر سؤال نوشته شده: «رنگ جوهر»، «معنی کلمه» یا «جهت پیکان». کنار هر رنگ یک شکل هم هست (قرمز ●، آبی ■، سبز ▲، زرد ◆) تا فقط به رنگ وابسته نباشی. گاهی کلمه و رنگ یا جهت عمداً با هم تضاد دارند.",
    2800, 300
) {
    private val dirNames = listOf("چپ", "راست", "بالا", "پایین")
    private val dirArrows = listOf("←", "→", "↑", "↓")

    override fun generate(ctx: GenContext): Question {
        val rng = ctx.rng
        val l = ctx.level
        val rules = when {
            l <= 3 -> listOf("INK")
            l <= 6 -> listOf("INK", "WORD")
            else -> listOf("INK", "WORD", "ARROW")
        }
        val rule = GameUtil.pick(rng, rules)
        val congruent = rng.nextInt(100) < (if (l <= 2) 100 else if (l <= 5) 50 else 20)
        val ink = rng.nextInt(4)
        var word = if (congruent) ink else rng.nextInt(4)
        if (!congruent && word == ink) word = (ink + 1) % 4
        return when (rule) {
            "INK" -> colorQuestion(ctx, "رنگ جوهر کلمه را انتخاب کن", ink, word, ink, "قانون فعال: رنگ جوهر")
            "WORD" -> colorQuestion(ctx, "معنی کلمه را انتخاب کن (نه رنگ آن را)", ink, word, word, "قانون فعال: معنی کلمه")
            else -> {
                val dir = rng.nextInt(4)
                var wordDir = if (congruent) dir else rng.nextInt(4)
                if (!congruent && wordDir == dir) wordDir = (dir + 1) % 4
                ctx.question(
                    ChoiceBody(
                        "جهت پیکان را انتخاب کن (به کلمه توجه نکن)", null,
                        listOf(
                            Glyph(dirArrows[dir], colorIdx = ink, description = "پیکان ${GamePalette.names[ink]}"),
                            Glyph(dirNames[wordDir], colorIdx = -1, description = "کلمه")
                        ),
                        dirNames.indices.map { "${dirArrows[it]} ${dirNames[it]}" }, emptyList(), dir,
                        "پیکان به سمت ${dirNames[dir]} بود؛ کلمه‌ی «${dirNames[wordDir]}» فقط حواس‌پرتی بود.", "قانون فعال: جهت پیکان"
                    ),
                    "cd:ARROW:$dir:$wordDir"
                )
            }
        }
    }

    private fun colorQuestion(ctx: GenContext, prompt: String, ink: Int, word: Int, answer: Int, rule: String): Question {
        val order = (0 until 4).shuffled(ctx.rng)
        val options = order.map { "${GamePalette.markers[it]} ${GamePalette.names[it]}" }
        return ctx.question(
            ChoiceBody(
                prompt, null,
                listOf(Glyph("${GamePalette.markers[ink]} ${GamePalette.names[word]}", colorIdx = ink,
                    description = "کلمه‌ی ${GamePalette.names[word]} با جوهر ${GamePalette.names[ink]}")),
                options, order, order.indexOf(answer),
                "کلمه «${GamePalette.names[word]}» با جوهر «${GamePalette.names[ink]}» نوشته شده بود؛ پاسخ ${GamePalette.names[answer]} است.", rule
            ),
            "cd:${if (answer == ink) "INK" else "WORD"}:$ink:$word"
        )
    }
}

/** 16. Selective reaction: reaction time is measured only from real stimulus onset. */
object SelectiveReactionGame : BaseGame(
    "selective_reaction", "واکنش انتخابی", Category.ATTENTION, "⚡",
    "فقط به هدف واکنش نشان بده",
    "فقط وقتی «دایره‌ی سبز ●» ظاهر شد سریع روی صفحه بزن. روی بقیه‌ی شکل‌ها (مربع، مثلث، دایره‌ی رنگ دیگر) و علامت ممنوع ✖ هرگز نزن. زودتر از ظهور شکل زدن، خطا حساب می‌شود. زمان واکنش فقط از لحظه‌ی ظهور شکل اندازه‌گیری می‌شود.",
    650, -25
) {
    override fun generate(ctx: GenContext): Question {
        val rng = ctx.rng
        val l = ctx.level
        val isTarget = rng.nextInt(100) < 60
        val glyph: Glyph = if (isTarget) {
            Glyph("●", colorIdx = 2, description = "دایره‌ی سبز")
        } else {
            val options = ArrayList<Glyph>()
            options.add(Glyph("■", colorIdx = 2, description = "مربع سبز"))
            options.add(Glyph("▲", colorIdx = 1, description = "مثلث آبی"))
            if (l >= 3) options.add(Glyph("●", colorIdx = 0, description = "دایره‌ی قرمز"))
            if (l >= 5) options.add(Glyph("✖", colorIdx = 0, description = "علامت ممنوع"))
            GameUtil.pick(rng, options)
        }
        val window = max(500L, 1300L - 70L * l)
        return ctx.question(
            ReactionBody(
                "منتظر بمان…", "فقط روی دایره‌ی سبز ● بزن", isTarget, glyph,
                rng.nextLong(700, 1801), window,
                if (isTarget) "هدف (${glyph.description}) ظاهر شد و باید می‌زدی."
                else "این شکل (${glyph.description}) هدف نبود و نباید می‌زدی."
            ),
            "react:${glyph.description}:target=$isTarget"
        )
    }
}
