package com.mindrush.app.feature

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

/** Digit formatter provided app-wide (Persian digits on/off). */
val LocalFmt = staticCompositionLocalOf<(String) -> String> { { it } }

object GenColors {
    val bg = Color(0xFF0B0B0D)
    val surface = Color(0xFF17171B)
    val surfaceHigh = Color(0xFF212127)
    val accent = Color(0xFFE0B454)
    val good = Color(0xFF30C48D)
    val bad = Color(0xFFFF6B6B)
    val muted = Color(0xFFA3A3AD)
    private val ink = listOf(Color(0xFFE5484D), Color(0xFF4C8DFF), Color(0xFF30C48D), Color(0xFFF5C542))
    fun ink(i: Int): Color = if (i in ink.indices) ink[i] else Color(0xFFF2F2F2)
}

private val scheme = darkColorScheme(
    primary = Color(0xFFF2F2F2),
    onPrimary = Color(0xFF0B0B0D),
    secondary = GenColors.accent,
    onSecondary = Color(0xFF0B0B0D),
    background = GenColors.bg,
    onBackground = Color(0xFFF2F2F2),
    surface = GenColors.surface,
    onSurface = Color(0xFFF2F2F2),
    surfaceVariant = GenColors.surfaceHigh,
    onSurfaceVariant = GenColors.muted,
    error = GenColors.bad
)

@Composable
fun GeniusTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = scheme, content = content)
}
