package com.mindrush.app.data

import android.util.JsonWriter
import androidx.room.withTransaction
import com.mindrush.app.domain.AchievementContext
import com.mindrush.app.domain.Achievements
import com.mindrush.app.domain.DayStreak
import com.mindrush.app.game.GameMode
import com.mindrush.app.game.GameRegistry
import com.mindrush.app.game.SessionConfig
import com.mindrush.app.game.SessionResult
import com.mindrush.app.game.SessionStatus
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import java.io.OutputStream
import java.io.OutputStreamWriter
import java.time.LocalDate

data class SaveOutcome(
    val isNewBest: Boolean,
    val previousBest: Int?,
    val previousScore: Int?,
    val newAchievements: List<String>
)

data class GameDetail(
    val gameId: String,
    val meanMs: Long?,
    val medianMs: Long?,
    val sampleSize: Int,
    val components: List<ComponentAggregate>
)

class GameRepository(private val db: AppDatabase) {
    private val pageSize = 500

    // ---------- reads ----------
    fun gameAggregates(): Flow<List<GameAggregate>> = db.sessions().gameAggregatesFlow()
    fun statusCounts(): Flow<List<StatusCount>> = db.sessions().statusCountsFlow()
    fun profiles(): Flow<List<DifficultyProfileEntity>> = db.difficulty().allFlow()
    fun achievements(): Flow<List<AchievementEntity>> = db.achievements().allFlow()
    fun todayTotals(tzId: String): Flow<DayTotals> =
        db.daily().totalsFlow(DayStreak.dayKey(System.currentTimeMillis(), tzId))

    fun dayStreak(tzId: String): Flow<Int> = db.daily().dayKeysFlow(400).map { keys ->
        DayStreak.compute(keys, LocalDate.now(DayStreak.zone(tzId)))
    }

    suspend fun profileLevel(gameId: String): Int = db.difficulty().get(gameId)?.level ?: 1
    suspend fun record(gameId: String, mode: GameMode): PersonalRecordEntity? = db.records().get("$gameId|${mode.name}")

    suspend fun gameDetail(gameId: String): GameDetail = withContext(Dispatchers.IO) {
        val times = db.events().responseTimes(gameId, 500).sorted()
        val mean = if (times.isEmpty()) null else times.sum() / times.size
        val median = if (times.isEmpty()) null else {
            val n = times.size
            if (n % 2 == 1) times[n / 2] else (times[n / 2 - 1] + times[n / 2]) / 2
        }
        GameDetail(gameId, mean, median, times.size, db.events().componentStats(gameId))
    }

    // ---------- session persistence ----------
    suspend fun beginSession(config: SessionConfig, startedWall: Long, tzId: String): Long =
        db.sessions().insert(
            SessionEntity(
                sessionUuid = config.sessionId, gameId = config.gameId, mode = config.mode.name,
                status = SessionStatus.INTERRUPTED.name, startedAt = startedWall, endedAt = null,
                durationMs = 0, score = 0, correct = 0, wrong = 0, skipped = 0, unanswered = 0,
                accuracy = 0.0, meanMs = null, medianMs = null, bestStreak = 0,
                startLevel = config.fixedLevel ?: config.startLevel, endLevel = config.fixedLevel ?: config.startLevel,
                fixedLevel = config.fixedLevel != null, dayKey = DayStreak.dayKey(startedWall, tzId),
                scoringVersion = 1
            )
        )

    suspend fun discardSession(rowId: Long) = db.sessions().delete(rowId)

    /** Saves the whole result atomically; duplicate event ids are ignored. */
    suspend fun finalizeSession(rowId: Long, result: SessionResult, tzId: String): SaveOutcome =
        db.withTransaction {
            val row = db.sessions().get(rowId) ?: throw IllegalStateException("session row missing")
            val now = result.endedAtWall
            db.sessions().update(
                row.copy(
                    status = result.status.name, endedAt = now, durationMs = result.durationMs, score = result.score,
                    correct = result.correct, wrong = result.wrong, skipped = result.skipped, unanswered = result.unanswered,
                    accuracy = result.accuracy, meanMs = result.meanMs, medianMs = result.medianMs,
                    bestStreak = result.bestStreak, startLevel = result.startLevel, endLevel = result.endLevel,
                    dayKey = DayStreak.dayKey(result.startedAtWall, tzId), scoringVersion = result.scoringVersion
                )
            )
            db.events().insertAll(result.records.map {
                AnswerEventEntity(
                    eventId = "${result.config.sessionId}:${it.index}", sessionId = rowId, gameId = it.gameId,
                    subGameId = it.subGameId, component = it.component, questionIndex = it.index, level = it.level,
                    correct = it.correct, skipped = it.skipped, responseMs = it.responseMs, points = it.points,
                    answeredAt = it.answeredAtWall, meta = it.meta
                )
            })
            if (result.status != SessionStatus.COMPLETED) {
                return@withTransaction SaveOutcome(false, null, null, emptyList())
            }

            val key = "${result.config.gameId}|${result.config.mode.name}"
            val old = db.records().get(key)
            val isBest = result.score > 0 && (old == null || result.score > old.bestScore)
            db.records().upsert(
                PersonalRecordEntity(
                    key, result.config.gameId, result.config.mode.name,
                    if (isBest) result.score else (old?.bestScore ?: result.score),
                    if (isBest) now else (old?.bestAchievedAt ?: now),
                    result.score, old?.lastScore
                )
            )

            if (result.config.fixedLevel == null && result.config.mode != GameMode.SURVIVAL) {
                val p = db.difficulty().get(result.config.gameId)
                db.difficulty().upsert(
                    DifficultyProfileEntity(result.config.gameId, result.endLevel, now, (p?.answeredCount ?: 0) + result.correct + result.wrong)
                )
            }

            val dayKey = DayStreak.dayKey(result.startedAtWall, tzId)
            val dKey = "$dayKey|${result.config.gameId}"
            val d = db.daily().get(dKey)
            db.daily().upsert(
                DailySummaryEntity(
                    dKey, dayKey, result.config.gameId, (d?.sessions ?: 0) + 1,
                    (d?.answered ?: 0) + result.correct + result.wrong, (d?.correct ?: 0) + result.correct,
                    (d?.score ?: 0) + result.score, (d?.durationMs ?: 0) + result.durationMs
                )
            )

            val unlocked = evaluateAchievements(result, tzId, now)
            SaveOutcome(isBest, old?.bestScore, old?.lastScore, unlocked)
        }

    private suspend fun evaluateAchievements(last: SessionResult?, tzId: String, now: Long): List<String> {
        val aggs = db.sessions().gameAggregatesNow()
        val games = aggs.map { it.gameId }.toSet()
        val categories = games.mapNotNull { GameRegistry.byId(it)?.category }.toSet()
        val ctx = AchievementContext(
            totalSessions = aggs.sumOf { it.sessions },
            totalCorrect = aggs.sumOf { it.correct },
            distinctGames = games.size,
            distinctCategories = categories.size,
            maxProfileLevel = db.difficulty().all().maxOfOrNull { it.level } ?: 1,
            dayStreak = DayStreak.compute(db.daily().dayKeys(400), LocalDate.now(DayStreak.zone(tzId))),
            lastResult = last
        )
        val have = db.achievements().all().map { it.id }.toSet()
        val fresh = ArrayList<String>()
        for (a in Achievements.all) {
            if (a.id !in have && a.test(ctx)) {
                if (db.achievements().insert(AchievementEntity(a.id, now)) != -1L) fresh.add(a.id)
            }
        }
        return fresh
    }

    // ---------- maintenance ----------
    /** Rebuilds records, daily summaries and difficulty profiles from the source session rows. */
    suspend fun rebuildDerived(tzId: String) = withContext(Dispatchers.IO) {
        db.withTransaction {
            db.records().deleteAll(); db.daily().deleteAll(); db.difficulty().deleteAll()
            val records = HashMap<String, PersonalRecordEntity>()
            val daily = HashMap<String, DailySummaryEntity>()
            val levels = HashMap<String, DifficultyProfileEntity>()
            var after = 0L
            while (true) {
                val page = db.sessions().completedPage(after, pageSize)
                if (page.isEmpty()) break
                for (s in page) {
                    after = s.id
                    val dayKey = DayStreak.dayKey(s.startedAt, tzId)
                    if (dayKey != s.dayKey) db.sessions().updateDayKey(s.id, dayKey)
                    val rk = "${s.gameId}|${s.mode}"
                    val r = records[rk]
                    records[rk] = if (r == null) PersonalRecordEntity(rk, s.gameId, s.mode, s.score, s.startedAt, s.score, null)
                    else r.copy(
                        bestScore = maxOf(r.bestScore, s.score),
                        bestAchievedAt = if (s.score > r.bestScore) s.startedAt else r.bestAchievedAt,
                        lastScore = s.score, previousScore = r.lastScore
                    )
                    val dk = "$dayKey|${s.gameId}"
                    val d = daily[dk]
                    daily[dk] = DailySummaryEntity(
                        dk, dayKey, s.gameId, (d?.sessions ?: 0) + 1, (d?.answered ?: 0) + s.correct + s.wrong,
                        (d?.correct ?: 0) + s.correct, (d?.score ?: 0) + s.score, (d?.durationMs ?: 0) + s.durationMs
                    )
                    if (!s.fixedLevel && s.mode != GameMode.SURVIVAL.name) {
                        val p = levels[s.gameId]
                        levels[s.gameId] = DifficultyProfileEntity(s.gameId, s.endLevel, s.endedAt ?: s.startedAt, (p?.answeredCount ?: 0) + s.correct + s.wrong)
                    }
                }
            }
            records.values.forEach { db.records().upsert(it) }
            daily.values.forEach { db.daily().upsert(it) }
            levels.values.forEach { db.difficulty().upsert(it) }
        }
    }

    suspend fun deleteAllData() = withContext(Dispatchers.IO) { db.clearAllTables() }

    /** Streams all data as JSON without loading everything into memory. */
    suspend fun exportJson(out: OutputStream, appVersion: String) = withContext(Dispatchers.IO) {
        val w = JsonWriter(OutputStreamWriter(out, Charsets.UTF_8))
        w.setIndent("  ")
        w.beginObject()
        w.name("app").value("Genius")
        w.name("appVersion").value(appVersion)
        w.name("schemaVersion").value(1L)
        w.name("exportedAt").value(System.currentTimeMillis())
        w.name("sessions").beginArray()
        var after = 0L
        while (true) {
            val page = db.sessions().page(after, 200)
            if (page.isEmpty()) break
            for (s in page) {
                after = s.id
                w.beginObject()
                w.name("sessionUuid").value(s.sessionUuid)
                w.name("gameId").value(s.gameId)
                w.name("mode").value(s.mode)
                w.name("status").value(s.status)
                w.name("startedAt").value(s.startedAt)
                if (s.endedAt != null) w.name("endedAt").value(s.endedAt) else w.name("endedAt").nullValue()
                w.name("durationMs").value(s.durationMs)
                w.name("score").value(s.score.toLong())
                w.name("correct").value(s.correct.toLong())
                w.name("wrong").value(s.wrong.toLong())
                w.name("skipped").value(s.skipped.toLong())
                w.name("unanswered").value(s.unanswered.toLong())
                w.name("accuracy").value(s.accuracy)
                w.name("bestStreak").value(s.bestStreak.toLong())
                w.name("startLevel").value(s.startLevel.toLong())
                w.name("endLevel").value(s.endLevel.toLong())
                w.name("fixedLevel").value(s.fixedLevel)
                w.name("dayKey").value(s.dayKey)
                w.name("scoringVersion").value(s.scoringVersion.toLong())
                w.name("answers").beginArray()
                for (e in db.events().forSession(s.id)) {
                    w.beginObject()
                    w.name("index").value(e.questionIndex.toLong())
                    w.name("gameId").value(e.gameId)
                    if (e.subGameId != null) w.name("subGameId").value(e.subGameId)
                    if (e.component != null) w.name("component").value(e.component)
                    w.name("level").value(e.level.toLong())
                    w.name("correct").value(e.correct)
                    w.name("skipped").value(e.skipped)
                    if (e.responseMs != null) w.name("responseMs").value(e.responseMs) else w.name("responseMs").nullValue()
                    w.name("points").value(e.points.toLong())
                    w.name("answeredAt").value(e.answeredAt)
                    w.endObject()
                }
                w.endArray()
                w.endObject()
            }
        }
        w.endArray()
        w.name("personalRecords").beginArray()
        for (r in db.records().all()) {
            w.beginObject()
            w.name("gameId").value(r.gameId); w.name("mode").value(r.mode)
            w.name("bestScore").value(r.bestScore.toLong()); w.name("lastScore").value(r.lastScore.toLong())
            w.endObject()
        }
        w.endArray()
        w.name("difficultyProfiles").beginArray()
        for (p in db.difficulty().all()) {
            w.beginObject()
            w.name("gameId").value(p.gameId); w.name("level").value(p.level.toLong())
            w.endObject()
        }
        w.endArray()
        w.name("achievements").beginArray()
        for (a in db.achievements().all()) {
            w.beginObject()
            w.name("id").value(a.id); w.name("unlockedAt").value(a.unlockedAt)
            w.endObject()
        }
        w.endArray()
        w.endObject()
        w.flush()
    }

    // ---------- progress / XP / missions / skills (v2) ----------
    suspend fun getProgress(): UserProgressEntity =
        db.progress().get() ?: UserProgressEntity(1, 0, 1, "", 0, 0)

    suspend fun addXp(amount: Int) {
        val p = getProgress()
        val newXp = p.totalXp + amount.coerceAtLeast(0)
        val newLevel = 1 + (newXp / 500)
        db.progress().upsert(p.copy(totalXp = newXp, level = newLevel, updatedAt = System.currentTimeMillis()))
    }

    suspend fun ensureDailyMissions(dayKey: String) {
        val existing = db.missions().forDay(dayKey)
        if (existing.isNotEmpty()) return
        val games = GameRegistry.all.shuffled().take(3)
        val missions = games.mapIndexed { i, g ->
            DailyMissionEntity(
                id = "$dayKey-$i",
                dayKey = dayKey,
                gameId = g.id,
                mode = GameMode.ACCURACY.name,
                targetCorrect = 8 + i * 2,
                completed = false,
                progress = 0,
                xpReward = 40 + i * 20
            )
        }
        db.missions().upsertAll(missions)
    }

    suspend fun missionsForToday(dayKey: String): List<DailyMissionEntity> {
        ensureDailyMissions(dayKey)
        return db.missions().forDay(dayKey)
    }

    suspend fun recordSkillSample(skillId: String, correct: Boolean, responseMs: Long?) {
        val old = db.skills().get(skillId)
        val sample = (old?.sampleCount ?: 0) + 1
        val corr = (old?.correctCount ?: 0) + if (correct) 1 else 0
        val totalMs = (old?.totalResponseMs ?: 0L) + (responseMs ?: 0L)
        val acc = if (sample == 0) 0.0 else corr.toDouble() / sample
        val best = maxOf(old?.bestAccuracy ?: 0.0, acc)
        db.skills().upsert(
            SkillStatEntity(skillId, sample, corr, totalMs, System.currentTimeMillis(), best)
        )
    }
}
