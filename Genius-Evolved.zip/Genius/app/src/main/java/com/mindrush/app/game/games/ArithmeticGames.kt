package com.mindrush.app.game.games

import com.mindrush.app.game.*
import kotlin.math.abs
import kotlin.math.max

private fun digitCarry(a: Long, b: Long): Boolean {
    var x = a; var y = b; var carry = 0L
    while (x > 0 || y > 0) {
        val s = x % 10 + y % 10 + carry
        if (s >= 10) return true
        carry = 0
        x /= 10; y /= 10
    }
    return false
}

private fun needsBorrow(a: Long, b: Long): Boolean {
    // requires a >= b
    var x = a; var y = b; var borrow = 0L
    while (x > 0 || y > 0) {
        val dx = x % 10 - borrow
        val dy = y % 10
        if (dx < dy) return true
        borrow = 0
        x /= 10; y /= 10
    }
    return false
}

/** 1. Fast addition */
object AdditionGame : BaseGame(
    "addition", "جمع سریع", Category.ARITHMETIC, "➕",
    "جمع‌های ذهنی با رقم‌های بیشتر و رقم نقلی",
    "حاصل جمع را هر چه سریع‌تر پیدا کن. با بالا رفتن سطح، عددها بزرگ‌تر می‌شوند، رقم نقلی بیشتر پیش می‌آید و از سطح ۸ سه عدد باید جمع شوند.",
    3000, 600
) {
    override fun generate(ctx: GenContext): Question {
        val rng = ctx.rng
        val l = ctx.level
        val digits = 2 + (l - 1) / 3
        val operands = if (l >= 8) 3 else 2
        var chosen: List<Long>? = null
        for (attempt in 0 until 40) {
            val nums = List(operands) { i ->
                GameUtil.randomWithDigits(rng, if (i == 0) digits else max(1, digits - rng.nextInt(0, 2)))
            }
            if (l >= 3 && attempt < 35) {
                var acc = nums[0]; var carry = false
                for (i in 1 until nums.size) { if (digitCarry(acc, nums[i])) carry = true; acc += nums[i] }
                if (!carry) continue
            }
            chosen = nums; break
        }
        val nums = chosen ?: List(operands) { GameUtil.randomWithDigits(rng, digits) }
        val sum = nums.sum()
        val expr = nums.joinToString(" + ")
        return GameUtil.numericChoice(
            ctx, "حاصل جمع را پیدا کن", expr, sum,
            max(9L, GameUtil.pow10(digits - 1)), "$expr = $sum", meta = "add:$expr"
        )
    }
}

/** 2. Fast subtraction: negative results only from level 8. */
object SubtractionGame : BaseGame(
    "subtraction", "تفریق سریع", Category.ARITHMETIC, "➖",
    "تفریق ذهنی با قرض‌گرفتن و پاسخ منفی",
    "حاصل تفریق را پیدا کن. تا سطح ۷ پاسخ همیشه صفر یا مثبت است؛ از سطح ۸ تا ۱۰ ممکن است پاسخ منفی شود. از سطح ۴ به بعد قرض‌گرفتن لازم است.",
    3200, 600
) {
    override fun generate(ctx: GenContext): Question {
        val rng = ctx.rng
        val l = ctx.level
        val digits = 2 + (l - 1) / 3
        val allowNegative = l >= 8
        var a = 0L; var b = 0L
        var ok = false
        for (attempt in 0 until 40) {
            val x = GameUtil.randomWithDigits(rng, digits)
            val y = GameUtil.randomWithDigits(rng, max(1, digits - rng.nextInt(0, 2)))
            if (x == y) continue
            val hi = max(x, y); val lo = minOf(x, y)
            if (l >= 4 && attempt < 35 && !needsBorrow(hi, lo)) continue
            if (allowNegative && rng.nextInt(100) < 40) { a = lo; b = hi } else { a = hi; b = lo }
            ok = true; break
        }
        if (!ok) { a = 52; b = 17 }
        val result = a - b
        val expr = "$a − $b"
        val note = if (allowNegative) "پاسخ ممکن است منفی باشد" else "پاسخ صفر یا مثبت است"
        return GameUtil.numericChoice(
            ctx, "حاصل تفریق را پیدا کن ($note)", expr, result,
            max(9L, GameUtil.pow10(digits - 1)), "$expr = $result",
            nonNegative = !allowNegative, meta = "sub:$a-$b"
        )
    }
}

/** 3. Mental multiplication with helpful patterns. */
object MultiplicationGame : BaseGame(
    "multiplication", "ضرب ذهنی", Category.ARITHMETIC, "✖️",
    "ضرب ذهنی با الگوهای میان‌بر",
    "حاصل ضرب را پیدا کن. در سطح‌های بالاتر الگوهایی مثل ضرب در ۱۱، ۵، ۲۵، مربع عددهای مختوم به ۵ و عددهای نزدیک ۱۰۰ می‌آیند که حل ذهنی را آسان می‌کنند.",
    4000, 900
) {
    override fun generate(ctx: GenContext): Question {
        val rng = ctx.rng
        val l = ctx.level
        val a: Long; val b: Long
        when {
            l <= 2 -> { a = rng.nextLong(2, 6 + l * 2L); b = rng.nextLong(2, 10) }
            l <= 4 -> { a = rng.nextLong(11, if (l == 3) 31 else 100); b = rng.nextLong(2, 10) }
            else -> {
                when (rng.nextInt(6)) {
                    0 -> { a = rng.nextLong(12, 100); b = 11 }
                    1 -> { a = rng.nextLong(12, 97); b = if (rng.nextBoolean()) 5 else 25 }
                    2 -> { val n = rng.nextLong(1, 10) * 10 + 5; a = n; b = n }
                    3 -> { a = rng.nextLong(95, 100); b = rng.nextLong(3, 10) }
                    4 -> if (l >= 9) { a = rng.nextLong(100, 1000); b = rng.nextLong(3, 10) } else { a = rng.nextLong(12, 100); b = rng.nextLong(12, 40) }
                    else -> {
                        val limit = when { l <= 6 -> 2000L; l <= 8 -> 6000L; l == 9 -> 10000L; else -> 25000L }
                        var x = 12L; var y = 13L
                        for (attempt in 0 until 40) {
                            val cx = rng.nextLong(12, 100); val cy = rng.nextLong(12, 100)
                            if (cx * cy <= limit) { x = cx; y = cy; break }
                        }
                        a = x; b = y
                    }
                }
            }
        }
        val product = a * b
        val expr = "$a × $b"
        return GameUtil.numericChoice(
            ctx, "حاصل ضرب را پیدا کن", expr, product,
            max(10L, product / 10), "$expr = $product", nonNegative = true, meta = "mul:$a*$b"
        )
    }
}

/** 4. Mixed operations with correct precedence; division only when exact. */
object MixedOperationsGame : BaseGame(
    "mixed_ops", "عملیات ترکیبی", Category.ARITHMETIC, "🔣",
    "چندعملیاتی با رعایت اولویت ضرب و تقسیم",
    "عبارت را با رعایت اولویت عملگرها حساب کن: ضرب و تقسیم قبل از جمع و تفریق. تقسیم‌ها همیشه دقیق (بدون باقی‌مانده) هستند.",
    6000, 1200
) {
    private val ops = charArrayOf('+', '−', '×', '÷')

    override fun generate(ctx: GenContext): Question {
        val rng = ctx.rng
        val l = ctx.level
        val count = when { l <= 4 -> 3; l <= 8 -> 4; else -> 5 }
        val maxN = if (l <= 3) 9L else 12L + l
        for (attempt in 0 until 150) {
            val o = List(count - 1) { ops[rng.nextInt(4)] }
            if (l >= 3 && o.none { it == '×' || it == '÷' }) continue
            val nums = MutableList(count) { rng.nextLong(2, maxN + 1) }
            for (i in o.indices) {
                if (o[i] == '÷') {
                    val prevIsMulDiv = i > 0 && (o[i - 1] == '×' || o[i - 1] == '÷')
                    if (!prevIsMulDiv) nums[i] = nums[i + 1] * rng.nextLong(1, 10)
                }
            }
            val value = Arith.evalList(nums, o) ?: continue
            if (abs(value) > 100_000) continue
            val expr = buildString {
                append(nums[0])
                for (i in o.indices) { append(' ').append(o[i]).append(' ').append(nums[i + 1]) }
            }
            return GameUtil.numericChoice(
                ctx, "عبارت را حساب کن", expr, value, max(6L, abs(value) / 5),
                "$expr = $value (ابتدا ضرب و تقسیم، سپس جمع و تفریق)", meta = "mix:$expr"
            )
        }
        return GameUtil.numericChoice(ctx, "عبارت را حساب کن", "2 + 3 × 4", 14, 6, "2 + 3 × 4 = 14", meta = "mix:fallback")
    }
}
