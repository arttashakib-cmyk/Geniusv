package com.mindrush.app.feature

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.mindrush.app.AppContainer
import com.mindrush.app.core.Fa
import com.mindrush.app.game.GameMode

private val tabs = listOf(
    Triple("home", "خانه", "🏠"),
    Triple("stats", "آمار", "📊"),
    Triple("achievements", "دستاوردها", "🏅"),
    Triple("settings", "تنظیمات", "⚙️")
)

@Composable
fun GeniusApp(container: AppContainer) {
    val mainVm: MainViewModel = viewModel(factory = viewModelFactory { initializer { MainViewModel(container) } })
    val settings by mainVm.settings.collectAsState()
    val persian = settings?.persianDigits ?: true
    val fmt: (String) -> String = remember(persian) { { s: String -> Fa.format(s, persian) } }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl, LocalFmt provides fmt) {
        GeniusTheme {
            val s = settings
            if (s == null) {
                Box(Modifier.fillMaxSize().background(GenColors.bg), contentAlignment = Alignment.Center) { FText("Genius", fontSize = 28.sp) }
            } else {
                val start = remember { if (s.onboardingDone) "home" else "onboarding" }
                AppNav(container, mainVm, start)
            }
        }
    }
}

@Composable
private fun AppNav(container: AppContainer, mainVm: MainViewModel, start: String) {
    val nav = rememberNavController()
    val entry by nav.currentBackStackEntryAsState()
    val route = entry?.destination?.route
    val showBar = route in tabs.map { it.first }

    Scaffold(
        containerColor = GenColors.bg,
        bottomBar = {
            if (showBar) {
                NavigationBar(containerColor = GenColors.surface) {
                    for ((r, label, emoji) in tabs) {
                        NavigationBarItem(
                            selected = route == r,
                            onClick = {
                                nav.navigate(r) {
                                    popUpTo(nav.graph.findStartDestination().id) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = { Text(emoji, fontSize = 20.sp) },
                            label = { FText(label, fontSize = 11.sp) },
                            colors = NavigationBarItemDefaults.colors(indicatorColor = GenColors.surfaceHigh)
                        )
                    }
                }
            }
        }
    ) { pad ->
        NavHost(nav, startDestination = start, modifier = Modifier.padding(pad)) {
            composable("onboarding") {
                OnboardingScreen(onDone = {
                    mainVm.update { it.copy(onboardingDone = true) }
                    nav.navigate("home") { popUpTo("onboarding") { inclusive = true } }
                })
            }
            composable("home") { HomeScreen(mainVm) { id -> nav.navigate("setup/$id") } }
            composable("stats") { StatsScreen(mainVm) }
            composable("achievements") { AchievementsScreen(mainVm) }
            composable("settings") { SettingsScreen(mainVm) }
            composable("setup/{gameId}", arguments = listOf(navArgument("gameId") { type = NavType.StringType })) { e ->
                val id = e.arguments?.getString("gameId") ?: ""
                SetupScreen(
                    mainVm, id,
                    onStart = { mode, level -> nav.navigate("play/$id/${mode.name}/$level") },
                    onBack = { nav.popBackStack() }
                )
            }
            composable(
                "play/{gameId}/{mode}/{level}",
                arguments = listOf(
                    navArgument("gameId") { type = NavType.StringType },
                    navArgument("mode") { type = NavType.StringType },
                    navArgument("level") { type = NavType.StringType }
                )
            ) { e ->
                val gameId = e.arguments?.getString("gameId") ?: ""
                val mode = try { GameMode.valueOf(e.arguments?.getString("mode") ?: "SPEED") } catch (t: Exception) { GameMode.SPEED }
                val level = e.arguments?.getString("level")?.toIntOrNull() ?: 0
                val vm: PlayViewModel = viewModel(factory = viewModelFactory {
                    initializer { PlayViewModel(container, gameId, mode, if (level == 0) null else level) }
                })
                PlayScreen(
                    vm, gameId, mode,
                    onFinished = { nav.navigate("result") { popUpTo("home") { inclusive = false } } },
                    onExit = { nav.popBackStack("home", false) }
                )
            }
            composable("result") {
                val finished by container.lastResult.collectAsState()
                ResultScreen(
                    finished,
                    onRetry = { id, mode, level ->
                        nav.navigate("play/$id/${mode.name}/$level") { popUpTo("home") { inclusive = false } }
                    },
                    onHome = { nav.popBackStack("home", false) }
                )
            }
        }
    }
}
