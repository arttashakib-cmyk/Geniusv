package com.mindrush.app.feature

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mindrush.app.R
import com.mindrush.app.core.Fa
import com.mindrush.app.data.PersonalRecordEntity
import com.mindrush.app.game.Category
import com.mindrush.app.game.GameMode
import com.mindrush.app.game.GameRegistry

@Composable
fun OnboardingScreen(onDone: () -> Unit) {
    val pages = listOf(
        Triple("🧠", "به Genius خوش آمدی", "۳۴+ بازی ذهنی در دسته‌های متنوع: حساب، منطق، حافظه، توجه، تفکر منعطف، ادراک بصری، شهود و اتاق معما. همه‌چیز روی گوشی خودت اجرا می‌شود و به اینترنت نیاز ندارد."),
        Triple("⏱️", "سه حالت بازی", "سرعتی: تا پایان زمان هرچه می‌توانی پاسخ بده. دقتی: تعداد سؤال ثابت و توضیح بعد از هر اشتباه. بقا: با هر خطا یک جان از دست می‌دهی."),
        Triple("📈", "سطح تطبیقی", "سختی هر بازی از ۱ تا ۱۰ با عملکرد خودت تنظیم می‌شود. سطح فقط یک شاخص بازی است؛ نه نمره‌ی هوش و نه ارزیابی پزشکی. داده‌هایت فقط روی همین دستگاه می‌ماند.")
    )
    var page by remember { mutableStateOf(0) }
    val p = pages[page]
    Column(
        Modifier.fillMaxSize().background(GenColors.bg).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
    ) {
        Image(painterResource(R.drawable.ic_launcher_foreground), null, Modifier.size(120.dp).clip(RoundedCornerShape(28.dp)).background(androidx.compose.ui.graphics.Color.Black))
        Spacer(Modifier.height(24.dp))
        FText(p.first, fontSize = 44.sp)
        Spacer(Modifier.height(8.dp))
        FText(p.second, fontSize = 24.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        Spacer(Modifier.height(12.dp))
        FText(p.third, fontSize = 16.sp, color = GenColors.muted, textAlign = TextAlign.Center)
        Spacer(Modifier.height(24.dp))
        FText("${page + 1} از ${pages.size}", color = GenColors.muted, fontSize = 13.sp)
        Spacer(Modifier.height(12.dp))
        PrimaryButton(if (page == pages.lastIndex) "بزن بریم" else "بعدی") {
            if (page == pages.lastIndex) onDone() else page++
        }
    }
}

@Composable
fun HomeScreen(vm: MainViewModel, onOpenGame: (String) -> Unit) {
    val today by vm.today.collectAsState()
    val streak by vm.dayStreak.collectAsState()
    val aggregates by vm.aggregates.collectAsState()
    val best = aggregates.associate { it.gameId to it.bestStreak }

    LazyColumn(
        Modifier.fillMaxSize().background(GenColors.bg),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Image(painterResource(R.drawable.ic_launcher_foreground), null, Modifier.size(56.dp).clip(RoundedCornerShape(14.dp)).background(androidx.compose.ui.graphics.Color.Black))
                Column {
                    FText("Genius", fontSize = 28.sp, fontWeight = FontWeight.Bold)
                    FText("ورزش ذهن، هر روز", color = GenColors.muted, fontSize = 14.sp)
                }
            }
        }
        item {
            GCard {
                val t = today
                if (t == null || t.sessions == 0) {
                    FText("امروز هنوز بازی نکرده‌ای. یک بازی انتخاب کن و شروع کن!", color = GenColors.muted)
                } else {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        StatTile("دور امروز", t.sessions.toString(), Modifier.weight(1f))
                        StatTile("پاسخ درست", t.correct.toString(), Modifier.weight(1f))
                        StatTile("امتیاز", t.score.toString(), Modifier.weight(1f))
                        StatTile("روز پیاپی", streak.toString(), Modifier.weight(1f))
                    }
                }
            }
        }
        for (cat in Category.values()) {
            item { SectionTitle("${cat.emoji} ${cat.fa}") }
            items(GameRegistry.byCategory(cat), key = { it.id }) { g ->
                GCard(onClick = { onOpenGame(g.id) }) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        FText(g.emoji, fontSize = 30.sp)
                        Column(Modifier.weight(1f)) {
                            FText(g.nameFa, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                            FText(g.shortDescFa, fontSize = 13.sp, color = GenColors.muted)
                        }
                    }
                }
            }
        }
        item { Spacer(Modifier.height(8.dp)) }
    }
}

@Composable
fun SetupScreen(
    vm: MainViewModel, gameId: String,
    onStart: (GameMode, Int) -> Unit, onBack: () -> Unit
) {
    val game = GameRegistry.byId(gameId)
    val settings by vm.settings.collectAsState()
    var mode by remember { mutableStateOf(GameMode.SPEED) }
    var fixed by remember { mutableStateOf(0) }
    var record by remember { mutableStateOf<PersonalRecordEntity?>(null) }
    var profile by remember { mutableStateOf(1) }

    LaunchedEffect(gameId, mode) { record = vm.record(gameId, mode) }
    LaunchedEffect(gameId) { profile = vm.profileLevel(gameId) }

    if (game == null) { onBack(); return }
    val st = settings

    Column(Modifier.fillMaxSize().background(GenColors.bg).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Chip("بازگشت", false) { onBack() }
        }
        FText("${game.emoji} ${game.nameFa}", fontSize = 26.sp, fontWeight = FontWeight.Bold)
        FText(game.category.fa, color = GenColors.accent, fontSize = 14.sp)
        GCard { FText(game.instructionsFa) }

        SectionTitle("حالت بازی")
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            for (m in GameMode.values()) Chip(m.fa, mode == m) { mode = m }
        }
        GCard {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                FText(mode.ruleFa)
                if (st != null) {
                    val detail = when (mode) {
                        GameMode.SPEED -> "مدت: ${Fa.clock(st.speedDurationSec * 1000L)} دقیقه"
                        GameMode.ACCURACY -> "تعداد سؤال: ${st.accuracyQuestions}"
                        GameMode.SURVIVAL -> "جان‌ها: ${st.survivalLives} • حداکثر زمان: ${Fa.clock(st.survivalDurationSec * 1000L)}"
                    }
                    FText(detail, color = GenColors.muted, fontSize = 13.sp)
                }
            }
        }

        SectionTitle("سختی")
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Chip("خودکار (سطح $profile)", fixed == 0) { fixed = 0 }
            for (l in 1..10) Chip("$l", fixed == l) { fixed = l }
        }
        FText(
            if (fixed == 0) "سختی با عملکردت تنظیم می‌شود؛ تغییر فقط بعد از چند پاسخ پایدار رخ می‌دهد." else "سختی روی سطح $fixed ثابت می‌ماند و تغییر نمی‌کند.",
            color = GenColors.muted, fontSize = 13.sp
        )

        SectionTitle("رکورد")
        GCard {
            val r = record
            if (r == null) FText("برای این حالت هنوز رکوردی ثبت نشده است.", color = GenColors.muted)
            else Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatTile("بهترین امتیاز", r.bestScore.toString(), Modifier.weight(1f))
                StatTile("دور آخر", r.lastScore.toString(), Modifier.weight(1f))
                StatTile("دور قبلش", r.previousScore?.toString() ?: "—", Modifier.weight(1f))
            }
        }
        PrimaryButton("ادامه به بازی") { onStart(mode, fixed) }
        Spacer(Modifier.height(16.dp))
    }
}
