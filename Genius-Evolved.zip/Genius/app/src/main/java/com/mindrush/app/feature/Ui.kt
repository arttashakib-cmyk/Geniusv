package com.mindrush.app.feature

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mindrush.app.game.Glyph

/** Text whose digits follow the app-wide Persian/Latin digit policy. */
@Composable
fun FText(
    text: String,
    modifier: Modifier = Modifier,
    fontSize: TextUnit = 16.sp,
    color: Color = MaterialTheme.colorScheme.onSurface,
    fontWeight: FontWeight? = null,
    textAlign: TextAlign? = null,
    maxLines: Int = Int.MAX_VALUE
) {
    Text(
        text = LocalFmt.current(text), modifier = modifier, fontSize = fontSize, color = color,
        fontWeight = fontWeight, textAlign = textAlign, maxLines = maxLines
    )
}

@Composable
fun Ltr(content: @Composable () -> Unit) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr, content = content)
}

@Composable
fun GCard(modifier: Modifier = Modifier, onClick: (() -> Unit)? = null, content: @Composable () -> Unit) {
    val base = modifier
        .fillMaxWidth()
        .background(GenColors.surface, RoundedCornerShape(16.dp))
    Box(
        (if (onClick != null) base.clickable(onClick = onClick) else base).padding(14.dp)
    ) { content() }
}

@Composable
fun PrimaryButton(text: String, modifier: Modifier = Modifier, enabled: Boolean = true, onClick: () -> Unit) {
    Button(
        onClick = onClick, enabled = enabled, modifier = modifier.fillMaxWidth().heightIn(min = 52.dp),
        shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = MaterialTheme.colorScheme.primary, contentColor = MaterialTheme.colorScheme.onPrimary
        )
    ) { FText(text, fontSize = 17.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimary) }
}

@Composable
fun SecondaryButton(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    OutlinedButton(
        onClick = onClick, modifier = modifier.fillMaxWidth().heightIn(min = 48.dp), shape = RoundedCornerShape(14.dp)
    ) { FText(text, fontSize = 16.sp) }
}

@Composable
fun Chip(text: String, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Box(
        modifier
            .background(if (selected) MaterialTheme.colorScheme.primary else GenColors.surfaceHigh, shape)
            .border(1.dp, if (selected) MaterialTheme.colorScheme.primary else GenColors.surfaceHigh, shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        FText(text, fontSize = 14.sp, color = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface)
    }
}

@Composable
fun StatTile(label: String, value: String, modifier: Modifier = Modifier) {
    Column(
        modifier.background(GenColors.surface, RoundedCornerShape(14.dp)).padding(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        FText(value, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        FText(label, fontSize = 12.sp, color = GenColors.muted, textAlign = TextAlign.Center)
    }
}

@Composable
fun SectionTitle(text: String) {
    FText(text, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp, bottom = 4.dp))
}

/** Renders a text glyph or a cell-pattern shape. */
@Composable
fun GlyphView(glyph: Glyph, modifier: Modifier = Modifier, boxSize: Dp = 64.dp, fontSize: TextUnit = 28.sp) {
    val desc = glyph.description.ifEmpty { glyph.text }
    if (glyph.cells.isNotEmpty() && glyph.gridSize > 0) {
        val n = glyph.gridSize
        val filled = glyph.cells.toSet()
        Canvas(modifier.size(boxSize).semantics { contentDescription = desc }) {
            val cell = size.width / n
            for (i in 0 until n * n) {
                val r = i / n; val c = i % n
                val on = filled.contains(i)
                drawRect(
                    color = if (on) Color(0xFFF2F2F2) else Color(0xFF2A2A31),
                    topLeft = Offset(c * cell + 1.5f, r * cell + 1.5f),
                    size = Size(cell - 3f, cell - 3f)
                )
            }
        }
    } else {
        Box(modifier.heightIn(min = boxSize).semantics { contentDescription = desc }, contentAlignment = Alignment.Center) {
            Ltr {
                FText(
                    glyph.text, fontSize = fontSize, fontWeight = FontWeight.Bold,
                    color = if (glyph.colorIdx >= 0) GenColors.ink(glyph.colorIdx) else MaterialTheme.colorScheme.onSurface
                )
            }
        }
    }
}

