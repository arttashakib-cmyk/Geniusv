package com.mindrush.app.game

import com.mindrush.app.game.games.*

object GameRegistry {
    val all: List<GameDefinition> = listOf(
        // Original 20
        AdditionGame, SubtractionGame, MultiplicationGame, MixedOperationsGame,
        NumberSequenceGame, RuleHunterGame, LogicDeductionGame, NumberComparisonGame,
        NumberMemoryGame, ReverseMemoryGame, GridMemoryGame, MentalUpdateGame,
        TargetSearchGame, RapidMatchGame, ColorDirectionGame, SelectiveReactionGame,
        SpatialRotationGame, OddOneOutGame, RuleSwitchGame, MentalChainGame,
        // Visual (21-25)
        LengthIllusionGame, OddShapeGame, MentalRotation2DGame, ChangeDetectionGame, SymmetryGame,
        // Intuition (26-29)
        ProbabilityEstimateGame, SequencePredictionGame, ConfidenceGame, SignalNoiseGame,
        // Puzzle (30-34)
        CipherGame, LogicGridGame, NumberLockGame, ContradictionGame, OrderingGame,
        MemoryMathGame, RuleUnderLoadGame
    )

    private val byId: Map<String, GameDefinition> = all.associateBy { it.id }

    init {
        require(byId.size == all.size) { "Duplicate game ids: size ${all.size} vs unique ${byId.size}" }
    }

    fun byId(id: String): GameDefinition? = byId[id]

    fun byCategory(c: Category): List<GameDefinition> = all.filter { it.category == c }

    fun componentFa(component: String?): String = when (component) {
        "ARITHMETIC" -> "حساب"
        "LOGIC" -> "منطق"
        "MEMORY" -> "حافظه"
        "ATTENTION" -> "توجه"
        "VISUAL" -> "بصری"
        "INTUITION" -> "شهود"
        "PUZZLE" -> "معما"
        else -> component ?: ""
    }
}
