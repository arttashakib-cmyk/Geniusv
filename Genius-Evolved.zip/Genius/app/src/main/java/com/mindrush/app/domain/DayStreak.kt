package com.mindrush.app.domain

import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

object DayStreak {
    fun zone(id: String): ZoneId = try { ZoneId.of(id) } catch (e: Exception) { ZoneId.systemDefault() }

    fun dayKey(wallMs: Long, tzId: String): String =
        Instant.ofEpochMilli(wallMs).atZone(zone(tzId)).toLocalDate().toString()

    /** Consecutive days ending today (or yesterday, so the streak is not lost before today's first round). */
    fun compute(dayKeysDesc: List<String>, today: LocalDate): Int {
        if (dayKeysDesc.isEmpty()) return 0
        val days = dayKeysDesc.mapNotNull { try { LocalDate.parse(it) } catch (e: Exception) { null } }.toSet()
        var cursor = if (days.contains(today)) today else today.minusDays(1)
        var n = 0
        while (days.contains(cursor)) { n++; cursor = cursor.minusDays(1) }
        return n
    }
}
