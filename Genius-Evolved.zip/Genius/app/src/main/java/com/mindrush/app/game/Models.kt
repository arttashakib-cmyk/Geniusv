package com.mindrush.app.game

import com.mindrush.app.core.Fa

enum class Category(val fa: String, val emoji: String) {
    ARITHMETIC("حساب ذهنی", "🧮"),
    LOGIC("منطق و الگو", "🧩"),
    MEMORY("حافظه فعال", "🧠"),
    ATTENTION("توجه و واکنش", "🎯"),
    FLEXIBLE("تفکر منعطف", "🔀"),
    VISUAL("ادراک بصری", "👁️"),
    INTUITION("آزمایشگاه شهود", "🔮"),
    PUZZLE("اتاق معما", "🔐"),
    CREATIVE("خلاقیت و انعطاف", "💡"),
    MIXED("چالش ترکیبی", "⚡")
}

enum class GameMode(val fa: String, val ruleFa: String) {
    SPEED("سرعتی", "تا پایان زمان تعیین‌شده تا جایی که می‌توانی پاسخ بده."),
    ACCURACY("دقتی", "تعداد سؤال ثابت است، بدون شمارش معکوس؛ بعد از هر اشتباه توضیح می‌بینی."),
    SURVIVAL("بقا", "هر پاسخ اشتباه، ردکردن یا ضربه‌ی اشتباه یک جان کم می‌کند؛ با تمام‌شدن جان‌ها یا زمان، بازی تمام می‌شود.")
}

/** A displayable stimulus: text, colored text, or a cell-pattern shape. */
data class Glyph(
    val text: String = "",
    val colorIdx: Int = -1,
    val cells: List<Int> = emptyList(),
    val gridSize: Int = 0,
    val description: String = ""
)

enum class RecallMode { FORWARD, REVERSE, NUMERIC }

data class Question(
    val id: String,
    val gameId: String,
    val level: Int,
    val component: String?,
    val subGameId: String?,
    val meta: String,
    val body: QBody
)

sealed interface QBody

data class ChoiceBody(
    val prompt: String,
    val expression: String? = null,
    val glyphs: List<Glyph> = emptyList(),
    val options: List<String>,
    val optionColors: List<Int> = emptyList(),
    val correctIndex: Int,
    val explanation: String,
    val rule: String? = null
) : QBody

data class PickBody(
    val prompt: String,
    val target: List<Glyph> = emptyList(),
    val items: List<Glyph>,
    val columns: Int,
    val correctIndex: Int,
    val explanation: String,
    val rule: String? = null,
    val banner: String? = null
) : QBody

data class RecallBody(
    val prompt: String,
    val steps: List<String>,
    val showMsPerStep: Long,
    val mode: RecallMode,
    val expected: String,
    val explanation: String
) : QBody

data class GridBody(
    val prompt: String,
    val size: Int,
    val cells: Set<Int>,
    val showMs: Long,
    val explanation: String
) : QBody

data class ReactionBody(
    val prompt: String,
    val rule: String,
    val isTarget: Boolean,
    val glyph: Glyph,
    val preDelayMs: Long,
    val windowMs: Long,
    val explanation: String
) : QBody

sealed interface Answer {
    data class Index(val i: Int) : Answer
    data class Typed(val text: String) : Answer
    data class Cells(val cells: Set<Int>) : Answer
    data class Reaction(val tapped: Boolean, val premature: Boolean = false) : Answer
    object Skip : Answer
}

data class Verdict(
    val correct: Boolean,
    val skipped: Boolean = false,
    val fraction: Double = if (correct) 1.0 else 0.0,
    val detail: String = ""
)

object AnswerEvaluator {
    fun evaluate(q: Question, a: Answer): Verdict {
        if (a is Answer.Skip) return Verdict(correct = false, skipped = true, detail = "skipped")
        return when (val b = q.body) {
            is ChoiceBody -> if (a is Answer.Index) Verdict(a.i == b.correctIndex) else Verdict(false)
            is PickBody -> if (a is Answer.Index) Verdict(a.i == b.correctIndex) else Verdict(false)
            is RecallBody -> if (a is Answer.Typed) evalRecall(b, a.text) else Verdict(false)
            is GridBody -> if (a is Answer.Cells) evalGrid(b, a.cells) else Verdict(false)
            is ReactionBody -> if (a is Answer.Reaction) {
                if (a.premature) Verdict(false, detail = "premature")
                else Verdict(a.tapped == b.isTarget)
            } else Verdict(false)
        }
    }

    private fun evalRecall(b: RecallBody, raw: String): Verdict {
        val given = Fa.normalizeDigits(raw).trim()
        if (b.mode == RecallMode.NUMERIC) {
            val g = given.removePrefix("+").toLongOrNull()?.toString()
            return Verdict(g != null && g == b.expected)
        }
        val exp = b.expected
        val matches = exp.indices.count { given.getOrNull(it) == exp[it] }
        val fraction = if (exp.isEmpty()) 0.0 else matches.toDouble() / exp.length
        return Verdict(given == exp, fraction = if (given == exp) 1.0 else fraction)
    }

    private fun evalGrid(b: GridBody, given: Set<Int>): Verdict {
        val inter = given.intersect(b.cells).size
        val union = given.union(b.cells).size
        val fraction = if (union == 0) 0.0 else inter.toDouble() / union
        return Verdict(given == b.cells, fraction = if (given == b.cells) 1.0 else fraction)
    }
}
