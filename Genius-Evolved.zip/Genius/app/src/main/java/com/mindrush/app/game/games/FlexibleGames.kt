package com.mindrush.app.game.games

import com.mindrush.app.game.*
import kotlin.math.abs
import kotlin.random.Random

/** Shape geometry on an n x n grid; a cell is index = row * n + col. */
object ShapeOps {
    fun rotate90(cells: Set<Int>, n: Int): Set<Int> =
        cells.map { val r = it / n; val c = it % n; c * n + (n - 1 - r) }.toSet()

    fun mirror(cells: Set<Int>, n: Int): Set<Int> =
        cells.map { val r = it / n; val c = it % n; r * n + (n - 1 - c) }.toSet()

    fun rotate(cells: Set<Int>, n: Int, quarterTurns: Int): Set<Int> {
        var s = cells
        repeat(((quarterTurns % 4) + 4) % 4) { s = rotate90(s, n) }
        return s
    }

    fun rotations(cells: Set<Int>, n: Int): List<Set<Int>> = (0 until 4).map { rotate(cells, n, it) }

    /** Connected random shape with [k] cells. */
    fun randomShape(rng: Random, n: Int, k: Int): Set<Int> {
        val cells = LinkedHashSet<Int>()
        cells.add(rng.nextInt(n * n))
        var guard = 0
        while (cells.size < k && guard < 500) {
            guard++
            val base = cells.elementAt(rng.nextInt(cells.size))
            val r = base / n; val c = base % n
            val nb = ArrayList<Int>()
            if (r > 0) nb.add(base - n); if (r < n - 1) nb.add(base + n)
            if (c > 0) nb.add(base - 1); if (c < n - 1) nb.add(base + 1)
            cells.add(nb[rng.nextInt(nb.size)])
        }
        return cells
    }

    /** True if the shape is neither rotation-symmetric (to itself) nor equal to any rotation of its mirror image. */
    fun isChiral(s: Set<Int>, n: Int): Boolean {
        val rots = rotations(s, n)
        if (rotate(s, n, 1) == s || rotate(s, n, 2) == s || rotate(s, n, 3) == s) return false
        return rots.none { it == mirror(s, n) }
    }
}

/** 17. Spatial rotation: correct option is a true rotation; distractors are mirror images or altered shapes. */
object SpatialRotationGame : BaseGame(
    "spatial_rotation", "چرخش فضایی", Category.FLEXIBLE, "🧊",
    "شکلِ چرخیده را از شکلِ آینه‌ای تشخیص بده",
    "شکل بالا را در ذهن بچرخان و گزینه‌ای را انتخاب کن که همان شکل است که فقط چرخیده. گزینه‌های آینه‌ای (بازتاب‌یافته) یا کمی تغییریافته اشتباه‌اند.",
    9000, 1500
) {
    override fun generate(ctx: GenContext): Question {
        val rng = ctx.rng
        val l = ctx.level
        val n = when { l <= 3 -> 3; l <= 7 -> 4; else -> 5 }
        val k = minOf(n * n - 2, 4 + l / 3)
        for (attempt in 0 until 200) {
            val shape = ShapeOps.randomShape(rng, n, k)
            if (shape.size != k || !ShapeOps.isChiral(shape, n)) continue
            val turns = rng.nextInt(1, 4)
            val correct = ShapeOps.rotate(shape, n, turns)
            val rots = ShapeOps.rotations(shape, n)
            val options = ArrayList<Set<Int>>()
            options.add(correct)
            // up to two mirror-image distractors (rotated randomly)
            var guard = 0
            while (options.size < 3 && guard < 30) {
                guard++
                val m = ShapeOps.rotate(ShapeOps.mirror(shape, n), n, rng.nextInt(4))
                if (m !in options && rots.none { it == m }) options.add(m)
            }
            // altered shape: move one cell
            guard = 0
            while (options.size < 4 && guard < 60) {
                guard++
                val list = correct.toMutableList()
                val remove = list.removeAt(rng.nextInt(list.size))
                val add = rng.nextInt(n * n)
                if (add in list || add == remove) continue
                list.add(add)
                val alt = list.toSet()
                if (alt !in options && rots.none { it == alt } && ShapeOps.rotations(ShapeOps.mirror(shape, n), n).none { it == alt }) options.add(alt)
            }
            if (options.size < 4) continue
            val shuffled = options.shuffled(rng)
            val idx = shuffled.indexOf(correct)
            return ctx.question(
                PickBody(
                    "کدام گزینه همان شکل است که فقط چرخیده (نه آینه‌ای)؟",
                    listOf(Glyph(cells = shape.sorted(), gridSize = n, description = "شکل اصلی")),
                    shuffled.mapIndexed { i, s -> Glyph(cells = s.sorted(), gridSize = n, description = "گزینه ${i + 1}") },
                    2, idx,
                    "گزینه‌ی ${idx + 1} شکل اصلی است که ${turns * 90} درجه چرخیده؛ گزینه‌های دیگر بازتاب آینه‌ای یا دارای خانه‌ی جابه‌جاشده‌اند."
                ),
                "rot:$n:${shape.sorted().joinToString(",")}:turns=$turns"
            )
        }
        // deterministic fallback L-shape
        val n3 = 3
        val s = setOf(0, 3, 6, 7, 4)
        return fallbackRotation(ctx, s, n3)
    }

    private fun fallbackRotation(ctx: GenContext, shape: Set<Int>, n: Int): Question {
        val correct = ShapeOps.rotate(shape, n, 1)
        val others = listOf(ShapeOps.mirror(shape, n), setOf(0, 1, 2, 5), setOf(2, 4, 6, 8))
            .filter { o -> ShapeOps.rotations(shape, n).none { it == o } }
        val options = (listOf(correct) + others).distinct().take(4)
        val idx = options.indexOf(correct)
        return ctx.question(
            PickBody(
                "کدام گزینه همان شکل است که فقط چرخیده؟",
                listOf(Glyph(cells = shape.sorted(), gridSize = n, description = "شکل اصلی")),
                options.mapIndexed { i, s -> Glyph(cells = s.sorted(), gridSize = n, description = "گزینه ${i + 1}") },
                2, idx, "گزینه‌ی ${idx + 1} همان شکل چرخیده است.", null
            ), "rot:fallback"
        )
    }
}

/** 18. Odd one out under an explicit, verifiable rule. */
object OddOneOutGame : BaseGame(
    "odd_one_out", "یکی نابه‌جا", Category.FLEXIBLE, "🚫",
    "عنصری را پیدا کن که از قانونِ نوشته‌شده پیروی نمی‌کند",
    "قانون بالای سؤال نوشته شده است. فقط یک عدد با بقیه از نظر آن قانون فرق دارد؛ آن را پیدا کن.",
    5500, 700
) {
    private class Pred(val label: String, val minLevel: Int, val lo: Int, val hi: Int, val test: (Int) -> Boolean)

    private fun isPrime(x: Int): Boolean {
        if (x < 2) return false
        var i = 2
        while (i * i <= x) { if (x % i == 0) return false; i++ }
        return true
    }
    private fun isSquare(x: Int): Boolean { var i = 0; while (i * i < x) i++; return i * i == x }
    private fun digitSum(x: Int): Int { var s = 0; var v = abs(x); while (v > 0) { s += v % 10; v /= 10 }; return s }
    private fun isPalin(x: Int): Boolean { val s = x.toString(); return s == s.reversed() }

    private val preds = listOf(
        Pred("زوج", 1, 10, 99) { it % 2 == 0 },
        Pred("فرد", 1, 10, 99) { it % 2 != 0 },
        Pred("مضرب ۳", 2, 10, 99) { it % 3 == 0 },
        Pred("مضرب ۴", 3, 10, 99) { it % 4 == 0 },
        Pred("مضرب ۵", 3, 10, 99) { it % 5 == 0 },
        Pred("مضرب ۷", 4, 10, 99) { it % 7 == 0 },
        Pred("عدد اول", 5, 10, 99) { isPrime(it) },
        Pred("مربع کامل", 6, 10, 199) { isSquare(it) },
        Pred("عدد متقارن (پالیندروم)", 7, 11, 199) { isPalin(it) },
        Pred("مجموع ارقام زوج", 8, 10, 99) { digitSum(it) % 2 == 0 }
    )

    override fun generate(ctx: GenContext): Question {
        val rng = ctx.rng
        val l = ctx.level
        val n = 5 + l / 3
        val avail = preds.filter { it.minLevel <= l }
        for (attempt in 0 until 40) {
            val p = GameUtil.pick(rng, avail)
            val yes = (p.lo..p.hi).filter { p.test(it) }
            val no = (p.lo..p.hi).filter { !p.test(it) }
            var majorityYes = rng.nextBoolean()
            if (majorityYes && yes.size < n - 1) majorityYes = false
            if (!majorityYes && no.size < n - 1) continue
            val majority = if (majorityYes) yes else no
            val minority = if (majorityYes) no else yes
            if (minority.isEmpty()) continue
            val odd = GameUtil.pick(rng, minority)
            val rest = majority.shuffled(rng).take(n - 1)
            val all = (rest + odd).shuffled(rng)
            // verification: exactly one differs
            val count = all.count { p.test(it) == majorityYes }
            if (count != n - 1) continue
            val idx = all.indexOf(odd)
            val rule = if (majorityYes) "همه به‌جز یکی «${p.label}» هستند." else "فقط یکی از اعداد «${p.label}» است."
            return ctx.question(
                PickBody(
                    "عدد نابه‌جا را پیدا کن.", emptyList(), all.map { Glyph(it.toString()) }, if (n <= 6) 3 else 4, idx,
                    "$odd ${if (majorityYes) "این ویژگی را ندارد" else "تنها عددی است که این ویژگی را دارد"} (قانون: ${p.label}).", rule
                ),
                "odd:${p.label}:${all.joinToString(",")}:odd=$odd"
            )
        }
        val items = listOf(2, 4, 6, 7, 8)
        return ctx.question(
            PickBody("عدد نابه‌جا را پیدا کن.", emptyList(), items.map { Glyph(it.toString()) }, 3, 3,
                "۷ تنها عدد فرد است.", "همه به‌جز یکی «زوج» هستند."), "odd:fallback"
        )
    }
}

/** 19. Rule switch: the active rule changes during the round and is announced. */
object RuleSwitchGame : BaseGame(
    "rule_switch", "تغییر قانون", Category.FLEXIBLE, "🔄",
    "قانون وسط بازی عوض می‌شود",
    "هر بار دو عدد می‌بینی و باید طبق «قانون فعال» یکی را انتخاب کنی. هر چند سؤال یک‌بار قانون عوض می‌شود و با پیام هشدار اعلام می‌شود. پاسخ بر اساس قانونی که همان لحظه فعال است سنجیده می‌شود.",
    3500, 400
) {
    private val ruleNames = listOf("بزرگ‌تر را انتخاب کن", "کوچک‌تر را انتخاب کن", "عدد زوج را انتخاب کن", "عددی که مجموع رقم‌هایش بیشتر است را انتخاب کن")

    private fun ds(x: Int): Int = x / 10 + x % 10

    override fun generate(ctx: GenContext): Question {
        val rng = ctx.rng
        val l = ctx.level
        var rule = (ctx.scratch["rule"] as? Int) ?: -1
        var left = (ctx.scratch["left"] as? Int) ?: 0
        var banner: String? = null
        if (rule < 0) {
            rule = rng.nextInt(4)
            left = if (l <= 5) rng.nextInt(3, 7) else rng.nextInt(2, 5)
            banner = "قانون شروع: ${ruleNames[rule]}"
        } else if (left <= 0) {
            var next = rng.nextInt(4)
            if (next == rule) next = (rule + 1) % 4
            rule = next
            left = if (l <= 5) rng.nextInt(3, 7) else rng.nextInt(2, 5)
            banner = "⚠️ قانون عوض شد: ${ruleNames[rule]}"
        }
        left -= 1
        ctx.scratch["rule"] = rule
        ctx.scratch["left"] = left

        var a = 10; var b = 11
        for (attempt in 0 until 80) {
            a = rng.nextInt(10, 100); b = rng.nextInt(10, 100)
            val ok = when (rule) {
                0, 1 -> a != b
                2 -> (a % 2 == 0) != (b % 2 == 0)
                else -> ds(a) != ds(b)
            }
            if (ok) break
            if (attempt == 79) { a = 24; b = 37 }
        }
        val answerFirst = when (rule) {
            0 -> a > b
            1 -> a < b
            2 -> a % 2 == 0
            else -> ds(a) > ds(b)
        }
        val ans = if (answerFirst) a else b
        return ctx.question(
            PickBody(
                "طبق قانون فعال انتخاب کن.", emptyList(), listOf(Glyph(a.toString()), Glyph(b.toString())), 2,
                if (answerFirst) 0 else 1, "طبق قانون «${ruleNames[rule]}» پاسخ $ans بود.",
                "قانون فعال: ${ruleNames[rule]}", banner
            ),
            "switch:rule=$rule:$a,$b"
        )
    }
}

/** 20. Mental chain: rotates through valid sub-questions from the underlying games, tracked per component. */
object MentalChainGame : BaseGame(
    "mental_chain", "زنجیره‌ی ذهنی", Category.FLEXIBLE, "⛓️",
    "ترکیبی از حساب، منطق، حافظه و توجه",
    "در هر مرحله یک سؤال از یکی از چهار حوزه‌ی حساب، منطق، حافظه یا توجه می‌آید. حوزه‌ها پشت سر هم می‌چرخند و نتیجه‌ات برای هر حوزه جداگانه ثبت می‌شود.",
    8000, 1000
) {
    private val arithmetic = listOf(AdditionGame, SubtractionGame, MultiplicationGame, MixedOperationsGame)
    private val logic = listOf(NumberSequenceGame, RuleHunterGame, LogicDeductionGame)
    private val memory = listOf(NumberMemoryGame, MentalUpdateGame, GridMemoryGame)
    private val attention = listOf(TargetSearchGame, RapidMatchGame, ColorDirectionGame)
    val componentNames = listOf("ARITHMETIC", "LOGIC", "MEMORY", "ATTENTION")

    override fun generate(ctx: GenContext): Question {
        val slot = (ctx.index - 1) % 4
        val pool = when (slot) { 0 -> arithmetic; 1 -> logic; 2 -> memory; else -> attention }
        val sub = GameUtil.pick(ctx.rng, pool)
        val q = sub.generate(ctx.child(sub.id))
        return q.copy(gameId = id, subGameId = sub.id, component = componentNames[slot])
    }
}
