package com.mindrush.app.game.games

import com.mindrush.app.game.*
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlin.random.Random

/**
 * Intuition / probabilistic judgment lab.
 * No supernatural claims. Results compared to base rates and calibration.
 */

/** 26. Probability estimation */
object ProbabilityEstimateGame : BaseGame(
    "prob_estimate", "تخمین احتمال", Category.INTUITION, "📊",
    "احتمال رخداد را تخمین بزن",
    "یک سناریوی ساده با احتمال معلوم توصیف می‌شود. درصد احتمال را انتخاب کن. بعد از پاسخ، احتمال واقعی و کیفیت تخمینت نمایش داده می‌شود.",
    6000, 400
) {
    override fun generate(ctx: GenContext): Question {
        val rng = ctx.rng
        val scenarios = listOf(
            Triple("یک تاس شش‌وجهی عادلانه انداخته می‌شود. احتمال آمدن عدد زوج چقدر است؟", 50, "۳ وجه زوج از ۶ وجه → ۵۰٪"),
            Triple("یک سکه عادلانه دو بار پرتاب می‌شود. احتمال دو بار شیر چقدر است؟", 25, "۱/۴ = ۲۵٪"),
            Triple("در یک کیسه ۱۰ مهره قرمز و ۱۰ مهره آبی است. احتمال کشیدن مهره قرمز؟", 50, "۱۰ از ۲۰ = ۵۰٪"),
            Triple("تاس انداخته می‌شود. احتمال آمدن عدد بزرگ‌تر از ۴؟", 33, "۲ از ۶ ≈ ۳۳٪"),
            Triple("دو تاس انداخته می‌شوند. احتمال مجموع ۷؟", 17, "۶ حالت از ۳۶ ≈ ۱۷٪"),
            Triple("یک کارت از دسته ۵۲ تایی. احتمال خال دل؟", 25, "۱۳ از ۵۲ = ۲۵٪"),
            Triple("احتمال اینکه در ۳ پرتاب سکه حداقل یک بار خط بیاید؟", 88, "۱ - (۱/۸) = ۸۷.۵٪ ≈ ۸۸٪"),
            Triple("تاس. احتمال عدد اول (۲،۳،۵)؟", 50, "۳ از ۶ = ۵۰٪")
        )
        val (prompt, trueP, rule) = scenarios[rng.nextInt(scenarios.size)]
        val options = listOf(10, 25, 33, 50, 67, 75, 90).shuffled(rng).take(3).toMutableList()
        if (trueP !in options) options[0] = trueP
        val opts = options.distinct().sorted().map { "$it٪" }
        val correct = opts.indexOf("$trueP٪").coerceAtLeast(0)
        val expl = "احتمال واقعی حدود $trueP٪ است. $rule. تخمین خوب به معنای کالیبراسیون مناسب است، نه حس ششم ماورایی."
        return ctx.question(
            ChoiceBody(prompt, null, emptyList(), opts, emptyList(), correct, expl, "base-rate"),
            "prob:$trueP"
        )
    }
}

/** 27. Next color prediction in a controlled process */
object SequencePredictionGame : BaseGame(
    "seq_predict", "پیش‌بینی دنباله", Category.INTUITION, "🔮",
    "رنگ یا نماد بعدی را پیش‌بینی کن",
    "یک دنباله‌ی کوتاه با قانون پنهان نشان داده می‌شود. نماد بعدی را حدس بزن. بعد از پاسخ قانون فاش می‌شود. این آزمون تشخیص الگو است نه پیش‌گویی.",
    5000, 400
) {
    override fun generate(ctx: GenContext): Question {
        val rng = ctx.rng
        val symbols = listOf("🔴", "🔵", "🟢", "🟡", "⚫")
        val ruleType = rng.nextInt(4)
        val seq = mutableListOf<String>()
        val next: String
        val ruleDesc: String
        when (ruleType) {
            0 -> { // alternating two
                val a = symbols[rng.nextInt(3)]
                val b = symbols.filter { it != a }.random(rng)
                repeat(5) { seq.add(if (it % 2 == 0) a else b) }
                next = if (seq.size % 2 == 0) a else b
                ruleDesc = "تناوب بین $a و $b"
            }
            1 -> { // every third different
                val a = symbols[0]; val b = symbols[1]; val c = symbols[2]
                val pattern = listOf(a, a, b, a, a, b)
                seq.addAll(pattern.take(5))
                next = pattern[5]
                ruleDesc = "دو $a سپس یک $b"
            }
            2 -> { // increasing count
                val a = symbols[rng.nextInt(3)]
                seq.addAll(listOf(a, a, symbols[3], a, a, a))
                next = symbols[3]
                ruleDesc = "گروه‌های در حال رشد از $a با جداکننده"
            }
            else -> { // reverse of previous pair
                val a = symbols[0]; val b = symbols[1]
                seq.addAll(listOf(a, b, b, a, a, b))
                next = b
                ruleDesc = "الگوی آینه‌ای جفت‌ها"
            }
        }
        val shown = seq.joinToString(" ")
        val options = (listOf(next) + symbols.filter { it != next }.shuffled(rng).take(3)).shuffled(rng)
        val correct = options.indexOf(next)
        val expl = "نماد بعدی $next بود. قانون: $ruleDesc. دنباله‌ی کامل: $shown $next"
        return ctx.question(
            ChoiceBody("دنباله: $shown\n\nنماد بعدی کدام است؟", null, emptyList(), options, emptyList(), correct, expl, ruleDesc),
            "seq:$ruleType"
        )
    }
}

/** 28. Confidence calibration */
object ConfidenceGame : BaseGame(
    "confidence", "کالیبراسیون اطمینان", Category.INTUITION, "🎯",
    "پاسخ بده و میزان اطمینان خود را اعلام کن",
    "یک سؤال دانش عمومی ساده یا احتمالاتی می‌بینی. پاسخ را انتخاب کن و سپس بگو چقدر مطمئن هستی. امتیاز به دقت و کالیبراسیون اطمینان بستگی دارد.",
    7000, 300
) {
    override fun generate(ctx: GenContext): Question {
        val rng = ctx.rng
        val items = listOf(
            Triple("پایتخت ایران کدام است؟", listOf("تهران", "اصفهان", "شیراز", "مشهد"), 0),
            Triple("۲ + ۲ × ۲ برابر است با؟", listOf("۶", "۸", "۴", "۱۰"), 0),
            Triple("تعداد روزهای ماه بهمن در سال غیر کبیسه؟", listOf("۲۹", "۳۰", "۲۸", "۳۱"), 0),
            Triple("کدام عدد اول است؟", listOf("۹", "۱۵", "۱۷", "۲۱"), 2),
            Triple("اگر احتمال باران ۷۰٪ باشد، احتمال نباریدن؟", listOf("۳۰٪", "۷۰٪", "۵۰٪", "۰٪"), 0)
        )
        val (q, opts, correct) = items[rng.nextInt(items.size)]
        val confOpts = listOf("اطمینان ۲۵٪", "اطمینان ۵۰٪", "اطمینان ۷۵٪", "اطمینان ۹۰٪")
        // Combined: answer + confidence later evaluated specially; here we only test the factual part
        val expl = "پاسخ درست: ${opts[correct]}. کالیبراسیون خوب یعنی وقتی ۵۰٪ مطمئن هستی حدود نیمی از مواقع درست بگویی."
        return ctx.question(
            ChoiceBody("$q\n\n(پس از انتخاب، میزان اطمینان خود را در نظر بگیر)", null, emptyList(), opts, emptyList(), correct, expl, "calibration"),
            "conf:$correct"
        )
    }
}

/** 29. Signal vs noise */
object SignalNoiseGame : BaseGame(
    "signal_noise", "سیگنال از نویز", Category.INTUITION, "📶",
    "آیا الگوی واقعی وجود دارد یا تصادفی است؟",
    "یک دنباله‌ی کوتاه از نمادها نشان داده می‌شود. تصمیم بگیر آیا از یک قانون ساده پیروی می‌کند یا کاملاً تصادفی تولید شده. پاسخ بر اساس قانون واقعی مولد است.",
    5500, 400
) {
    override fun generate(ctx: GenContext): Question {
        val rng = ctx.rng
        val hasSignal = rng.nextBoolean()
        val symbols = listOf("A", "B", "C")
        val seq: List<String>
        val rule: String
        if (hasSignal) {
            val a = symbols[rng.nextInt(3)]
            val b = symbols.filter { it != a }.random(rng)
            seq = listOf(a, b, a, b, a, b).take(5 + rng.nextInt(2))
            rule = "تناوب $a و $b"
        } else {
            seq = List(6) { symbols[rng.nextInt(3)] }
            rule = "تصادفی واقعی — هیچ قانون ساده‌ای وجود نداشت"
        }
        val options = listOf("الگوی واقعی دارد", "تصادفی است")
        val correct = if (hasSignal) 0 else 1
        val expl = if (hasSignal) "دنباله قانون داشت: $rule" else "دنباله واقعاً تصادفی بود. $rule"
        return ctx.question(
            ChoiceBody("دنباله: ${seq.joinToString(" ")}\n\nآیا الگوی واقعی دارد؟", null, emptyList(), options, emptyList(), correct, expl),
            "sig:$hasSignal"
        )
    }
}
