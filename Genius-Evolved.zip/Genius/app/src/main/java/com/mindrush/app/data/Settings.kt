package com.mindrush.app.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.util.TimeZone

data class AppSettings(
    val persianDigits: Boolean = true,
    val speedDurationSec: Int = 60,
    val accuracyQuestions: Int = 20,
    val survivalLives: Int = 3,
    val survivalDurationSec: Int = 180,
    val timeZoneId: String = TimeZone.getDefault().id,
    val onboardingDone: Boolean = false
)

private val Context.settingsStore: DataStore<Preferences> by preferencesDataStore(name = "genius_settings")

class SettingsRepository(private val context: Context) {
    private object K {
        val persian = booleanPreferencesKey("persian_digits")
        val speed = intPreferencesKey("speed_duration")
        val acc = intPreferencesKey("accuracy_questions")
        val lives = intPreferencesKey("survival_lives")
        val survDur = intPreferencesKey("survival_duration")
        val tz = stringPreferencesKey("time_zone")
        val onboarding = booleanPreferencesKey("onboarding_done")
    }

    val settings: Flow<AppSettings> = context.settingsStore.data.map { p ->
        val d = AppSettings()
        AppSettings(
            persianDigits = p[K.persian] ?: d.persianDigits,
            speedDurationSec = p[K.speed] ?: d.speedDurationSec,
            accuracyQuestions = p[K.acc] ?: d.accuracyQuestions,
            survivalLives = p[K.lives] ?: d.survivalLives,
            survivalDurationSec = p[K.survDur] ?: d.survivalDurationSec,
            timeZoneId = p[K.tz] ?: d.timeZoneId,
            onboardingDone = p[K.onboarding] ?: false
        )
    }

    suspend fun update(transform: (AppSettings) -> AppSettings) {
        context.settingsStore.edit { p ->
            val d = AppSettings()
            val cur = AppSettings(
                p[K.persian] ?: d.persianDigits, p[K.speed] ?: d.speedDurationSec, p[K.acc] ?: d.accuracyQuestions,
                p[K.lives] ?: d.survivalLives, p[K.survDur] ?: d.survivalDurationSec, p[K.tz] ?: d.timeZoneId,
                p[K.onboarding] ?: false
            )
            val n = transform(cur)
            p[K.persian] = n.persianDigits
            p[K.speed] = n.speedDurationSec
            p[K.acc] = n.accuracyQuestions
            p[K.lives] = n.survivalLives
            p[K.survDur] = n.survivalDurationSec
            p[K.tz] = n.timeZoneId
            p[K.onboarding] = n.onboardingDone
        }
    }

    suspend fun clear() {
        context.settingsStore.edit { it.clear() }
    }
}
