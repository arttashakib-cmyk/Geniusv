package com.mindrush.app.core

/** Monotonic clock abstraction so that timing is testable and unaffected by wall-clock changes. */
interface Clock {
    fun nowMs(): Long
}

object MonotonicClock : Clock {
    override fun nowMs(): Long = System.nanoTime() / 1_000_000L
}
