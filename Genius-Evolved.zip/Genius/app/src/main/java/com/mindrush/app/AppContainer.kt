package com.mindrush.app

import android.content.Context
import com.mindrush.app.data.AppDatabase
import com.mindrush.app.data.GameRepository
import com.mindrush.app.data.SaveOutcome
import com.mindrush.app.data.SettingsRepository
import com.mindrush.app.game.SessionResult
import kotlinx.coroutines.flow.MutableStateFlow

data class FinishedSession(val result: SessionResult, val outcome: SaveOutcome?)

/** Simple manual dependency container (no DI framework needed for this app size). */
class AppContainer(val context: Context) {
    val db: AppDatabase by lazy { AppDatabase.build(context) }
    val settings: SettingsRepository by lazy { SettingsRepository(context) }
    val repo: GameRepository by lazy { GameRepository(db) }
    val lastResult = MutableStateFlow<FinishedSession?>(null)
}
