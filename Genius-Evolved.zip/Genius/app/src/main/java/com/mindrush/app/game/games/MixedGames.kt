package com.mindrush.app.game.games

import com.mindrush.app.game.*
import kotlin.math.abs
import kotlin.random.Random

/**
 * Multi-skill mixed challenges. Each question is still a single QBody
 * but meta indicates the skill mix; scoring remains per-question.
 */

/** 35. Memory + Arithmetic: remember a number, then compute */
object MemoryMathGame : BaseGame(
    "memory_math", "حافظه و محاسبه", Category.MIXED, "🧮🧠",
    "عددی را حفظ کن و روی آن عملیات انجام بده",
    "یک عدد کوتاه نمایش داده می‌شود. بعد از پنهان‌شدن، باید حاصل یک عملیات روی همان عدد را انتخاب کنی.",
    7000, 600
) {
    override fun generate(ctx: GenContext): Question {
        val rng = ctx.rng
        val n = 10 + rng.nextInt(90)
        val op = listOf("+", "-", "×").random(rng)
        val k = when (op) {
            "+" -> 1 + rng.nextInt(20)
            "-" -> 1 + rng.nextInt(minOf(n - 1, 15))
            else -> 2 + rng.nextInt(5)
        }
        val result: Long = when (op) {
            "+" -> (n + k).toLong()
            "-" -> (n - k).toLong()
            else -> n.toLong() * k
        }
        val prompt = "عدد $n را به خاطر بسپار. حالا حاصل $n $op $k را پیدا کن."
        return GameUtil.numericChoice(
            ctx, prompt, null, result,
            maxOf(5L, abs(result) / 5 + 3),
            "$n $op $k = $result (عدد اولیه‌ی حفظ‌شده $n بود)",
            meta = "memmath:$n$op$k"
        )
    }
}

/** 36. Attention + Logic: find the rule then apply */
object RuleUnderLoadGame : BaseGame(
    "rule_under_load", "قانون زیر بار", Category.MIXED, "⚡🧩",
    "قانون را کشف کن و سریع اعمال کن",
    "چند نمونه از یک قانون ساده نشان داده می‌شود. سپس باید برای یک ورودی جدید خروجی درست را انتخاب کنی.",
    6000, 400
) {
    override fun generate(ctx: GenContext): Question {
        val rng = ctx.rng
        val rules = listOf(
            Triple("دو برابر کن", { x: Int -> x * 2 }, listOf(3 to 6, 5 to 10, 7 to 14)),
            Triple("یکی اضافه کن", { x: Int -> x + 1 }, listOf(4 to 5, 9 to 10, 12 to 13)),
            Triple("از ۱۰ کم کن", { x: Int -> 10 - x }, listOf(3 to 7, 4 to 6, 1 to 9)),
            Triple("مجموع ارقام", { x: Int -> x.toString().map { it - '0' }.sum() }, listOf(15 to 6, 23 to 5, 48 to 12))
        )
        val (name, fn, samples) = rules[rng.nextInt(rules.size)]
        val sampleText = samples.joinToString(" ؛ ") { "${it.first} → ${it.second}" }
        val input = 2 + rng.nextInt(20)
        val correctVal = fn(input)
        val distractors = mutableSetOf<Int>()
        var attempts = 0
        while (distractors.size < 3 && attempts < 40) {
            val d = correctVal + rng.nextInt(-6, 7)
            if (d != correctVal) distractors.add(d)
            attempts++
        }
        while (distractors.size < 3) distractors.add(correctVal + distractors.size + 1)
        val options = (listOf(correctVal) + distractors).map { it.toString() }.shuffled(rng)
        val correct = options.indexOf(correctVal.toString()).coerceAtLeast(0)
        val expl = "قانون: $name. برای $input نتیجه $correctVal است. نمونه‌ها: $sampleText"
        return ctx.question(
            ChoiceBody(
                "نمونه‌ها: $sampleText\n\nبرای $input خروجی چیست؟",
                null, emptyList(), options, emptyList(), correct, expl, name
            ),
            "ruleload:$name:$input"
        )
    }
}
