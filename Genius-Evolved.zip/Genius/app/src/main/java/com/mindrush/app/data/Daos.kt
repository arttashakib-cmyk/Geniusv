package com.mindrush.app.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

private const val AGG =
    "SELECT gameId AS gameId, COUNT(*) AS sessions, COALESCE(SUM(score),0) AS totalScore, " +
        "COALESCE(SUM(correct),0) AS correct, COALESCE(SUM(wrong),0) AS wrong, COALESCE(SUM(skipped),0) AS skipped, " +
        "COALESCE(MAX(bestStreak),0) AS bestStreak FROM sessions WHERE status='COMPLETED' GROUP BY gameId"

@Dao
interface SessionDao {
    @Insert
    suspend fun insert(s: SessionEntity): Long

    @Update
    suspend fun update(s: SessionEntity)

    @Query("SELECT * FROM sessions WHERE id=:id")
    suspend fun get(id: Long): SessionEntity?

    @Query("DELETE FROM sessions WHERE id=:id")
    suspend fun delete(id: Long)

    @Query("DELETE FROM sessions")
    suspend fun deleteAll()

    @Query("SELECT * FROM sessions WHERE id>:afterId ORDER BY id LIMIT :limit")
    suspend fun page(afterId: Long, limit: Int): List<SessionEntity>

    @Query("SELECT * FROM sessions WHERE status='COMPLETED' AND id>:afterId ORDER BY id LIMIT :limit")
    suspend fun completedPage(afterId: Long, limit: Int): List<SessionEntity>

    @Query("UPDATE sessions SET dayKey=:dayKey WHERE id=:id")
    suspend fun updateDayKey(id: Long, dayKey: String)

    @Query(AGG)
    fun gameAggregatesFlow(): Flow<List<GameAggregate>>

    @Query(AGG)
    suspend fun gameAggregatesNow(): List<GameAggregate>

    @Query("SELECT status AS status, COUNT(*) AS n FROM sessions GROUP BY status")
    fun statusCountsFlow(): Flow<List<StatusCount>>
}

@Dao
interface EventDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAll(events: List<AnswerEventEntity>)

    @Query("SELECT * FROM answer_events WHERE sessionId=:sessionId ORDER BY questionIndex")
    suspend fun forSession(sessionId: Long): List<AnswerEventEntity>

    @Query("SELECT responseMs FROM answer_events WHERE gameId=:gameId AND skipped=0 AND responseMs IS NOT NULL ORDER BY answeredAt DESC LIMIT :limit")
    suspend fun responseTimes(gameId: String, limit: Int): List<Long>

    @Query("SELECT component AS component, COUNT(*) AS total, COALESCE(SUM(CASE WHEN correct=1 THEN 1 ELSE 0 END),0) AS correct FROM answer_events WHERE gameId=:gameId AND component IS NOT NULL AND skipped=0 GROUP BY component")
    suspend fun componentStats(gameId: String): List<ComponentAggregate>
}

@Dao
interface RecordDao {
    @Query("SELECT * FROM personal_records WHERE `key`=:key")
    suspend fun get(key: String): PersonalRecordEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(r: PersonalRecordEntity)

    @Query("SELECT * FROM personal_records")
    suspend fun all(): List<PersonalRecordEntity>

    @Query("DELETE FROM personal_records")
    suspend fun deleteAll()
}

@Dao
interface DifficultyDao {
    @Query("SELECT * FROM difficulty_profiles WHERE gameId=:gameId")
    suspend fun get(gameId: String): DifficultyProfileEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(p: DifficultyProfileEntity)

    @Query("SELECT * FROM difficulty_profiles")
    fun allFlow(): Flow<List<DifficultyProfileEntity>>

    @Query("SELECT * FROM difficulty_profiles")
    suspend fun all(): List<DifficultyProfileEntity>

    @Query("DELETE FROM difficulty_profiles")
    suspend fun deleteAll()
}

@Dao
interface DailyDao {
    @Query("SELECT * FROM daily_summaries WHERE `key`=:key")
    suspend fun get(key: String): DailySummaryEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(d: DailySummaryEntity)

    @Query("SELECT COALESCE(SUM(sessions),0) AS sessions, COALESCE(SUM(answered),0) AS answered, COALESCE(SUM(correct),0) AS correct, COALESCE(SUM(score),0) AS score FROM daily_summaries WHERE dayKey=:dayKey")
    fun totalsFlow(dayKey: String): Flow<DayTotals>

    @Query("SELECT DISTINCT dayKey FROM daily_summaries ORDER BY dayKey DESC LIMIT :limit")
    suspend fun dayKeys(limit: Int): List<String>

    @Query("SELECT DISTINCT dayKey FROM daily_summaries ORDER BY dayKey DESC LIMIT :limit")
    fun dayKeysFlow(limit: Int): Flow<List<String>>

    @Query("SELECT * FROM daily_summaries ORDER BY dayKey")
    suspend fun all(): List<DailySummaryEntity>

    @Query("DELETE FROM daily_summaries")
    suspend fun deleteAll()
}

@Dao
interface AchievementDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(a: AchievementEntity): Long

    @Query("SELECT * FROM achievements")
    fun allFlow(): Flow<List<AchievementEntity>>

    @Query("SELECT * FROM achievements")
    suspend fun all(): List<AchievementEntity>

    @Query("DELETE FROM achievements")
    suspend fun deleteAll()
}

@Dao
interface ProgressDao {
    @Query("SELECT * FROM user_progress WHERE id = 1")
    suspend fun get(): UserProgressEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(p: UserProgressEntity)
}

@Dao
interface MissionDao {
    @Query("SELECT * FROM daily_missions WHERE dayKey = :dayKey")
    suspend fun forDay(dayKey: String): List<DailyMissionEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(items: List<DailyMissionEntity>)

    @Query("UPDATE daily_missions SET completed = 1, progress = :progress WHERE id = :id")
    suspend fun complete(id: String, progress: Int)
}

@Dao
interface SkillDao {
    @Query("SELECT * FROM skill_stats")
    suspend fun all(): List<SkillStatEntity>

    @Query("SELECT * FROM skill_stats WHERE skillId = :id")
    suspend fun get(id: String): SkillStatEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(s: SkillStatEntity)
}
