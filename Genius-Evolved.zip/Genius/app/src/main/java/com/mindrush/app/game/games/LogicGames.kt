package com.mindrush.app.game.games

import com.mindrush.app.game.*
import kotlin.math.abs
import kotlin.math.max
import kotlin.random.Random

/** 5. Number sequence: rule first, then terms; ambiguity rejected by fitting all known rule families. */
object NumberSequenceGame : BaseGame(
    "number_sequence", "دنباله‌ی عددی", Category.LOGIC, "🔢",
    "عدد بعدی دنباله را پیدا کن",
    "قانون پنهان دنباله را کشف کن و عدد بعدی را انتخاب کن. دنباله‌ها حسابی، هندسی، متناوب، مرتبه‌دوم، ترکیبی یا شبیه فیبوناچی‌اند و هر سؤال فقط یک پاسخ منطقی دارد.",
    7000, 1500
) {
    private const val LIMIT = 100_000L

    /** All "next" values predicted by every supported rule family that fits the given terms. */
    fun candidateNext(t: List<Long>): Set<Long> {
        val out = HashSet<Long>()
        val n = t.size
        if (n < 4) return out
        val d = LongArray(n - 1) { t[it + 1] - t[it] }
        if (d.all { it == d[0] }) out.add(t[n - 1] + d[0])
        val dd = LongArray(n - 2) { d[it + 1] - d[it] }
        if (dd.all { it == dd[0] }) out.add(t[n - 1] + d[n - 2] + dd[0])
        if (n >= 5 && (0 until n - 1).all { d[it] == d[it % 2] }) out.add(t[n - 1] + d[(n - 1) % 2])
        if ((2 until n).all { t[it] == t[it - 1] + t[it - 2] }) out.add(t[n - 1] + t[n - 2])
        if (t[1] != t[0]) {
            val num = t[2] - t[1]; val den = t[1] - t[0]
            if (num % den == 0L) {
                val p = num / den; val q = t[1] - p * t[0]
                if ((1 until n).all { t[it] == p * t[it - 1] + q }) out.add(p * t[n - 1] + q)
            }
        }
        if (n >= 6) {
            val c0 = t[2] - t[0]; val c1 = t[3] - t[1]
            if ((2 until n).all { t[it] - t[it - 2] == (if (it % 2 == 0) c0 else c1) }) {
                out.add(t[n - 2] + (if (n % 2 == 0) c0 else c1))
            }
        }
        return out
    }

    private enum class Kind { ARITH, GEOM, SECOND, ALT, AFFINE, FIB, INTERLEAVE }

    private class Built(val full: List<Long>, val explanation: String)

    private fun build(kind: Kind, rng: Random, total: Int): Built {
        val t = ArrayList<Long>()
        val ex: String
        when (kind) {
            Kind.ARITH -> {
                val a = rng.nextLong(1, 30); var d = rng.nextLong(2, 10); if (rng.nextBoolean()) d = -d
                for (i in 0 until total) t.add(a + i * d)
                ex = "هر جمله ${abs(d)} واحد ${if (d > 0) "بیشتر" else "کمتر"} از جمله‌ی قبل است."
            }
            Kind.GEOM -> {
                val a = rng.nextLong(1, 6); val r = rng.nextLong(2, 4)
                var v = a
                for (i in 0 until total) { t.add(v); v *= r }
                ex = "هر جمله $r برابر جمله‌ی قبل است."
            }
            Kind.SECOND -> {
                var v = rng.nextLong(1, 10); var step = rng.nextLong(1, 5); val e = rng.nextLong(1, 4)
                for (i in 0 until total) { t.add(v); v += step; step += e }
                ex = "تفاضل جمله‌ها هر بار $e واحد بیشتر می‌شود."
            }
            Kind.ALT -> {
                val a = rng.nextLong(1, 20); val d1 = rng.nextLong(2, 9); var d2 = rng.nextLong(1, 7); if (d2 == d1) d2 += 1
                var v = a
                for (i in 0 until total) { t.add(v); v += if (i % 2 == 0) d1 else d2 }
                ex = "به‌صورت متناوب $d1 و $d2 واحد اضافه می‌شود."
            }
            Kind.AFFINE -> {
                val a = rng.nextLong(1, 7); val p = rng.nextLong(2, 4); val q = rng.nextLong(-3, 6).let { if (it == 0L) 1L else it }
                var v = a
                for (i in 0 until total) { t.add(v); v = p * v + q }
                ex = "هر جمله برابر است با $p برابر جمله‌ی قبل ${if (q > 0) "به‌اضافه‌ی $q" else "منهای ${-q}"}."
            }
            Kind.FIB -> {
                t.add(rng.nextLong(1, 6)); t.add(rng.nextLong(1, 6))
                for (i in 2 until total) t.add(t[i - 1] + t[i - 2])
                ex = "هر جمله مجموع دو جمله‌ی قبلی است."
            }
            Kind.INTERLEAVE -> {
                val a = rng.nextLong(1, 15); val b = rng.nextLong(1, 15)
                val d1 = rng.nextLong(1, 7); val d2 = rng.nextLong(-5, 8)
                for (i in 0 until total) t.add(if (i % 2 == 0) a + (i / 2) * d1 else b + (i / 2) * d2)
                ex = "دو دنباله در هم تنیده‌اند: جمله‌های جای فرد با گام $d1 و جمله‌های جای زوج با گام $d2 پیش می‌روند."
            }
        }
        return Built(t, ex)
    }

    override fun generate(ctx: GenContext): Question {
        val rng = ctx.rng
        val l = ctx.level
        val kinds = when {
            l <= 2 -> listOf(Kind.ARITH, Kind.GEOM)
            l <= 4 -> listOf(Kind.ARITH, Kind.GEOM, Kind.SECOND, Kind.ALT)
            l <= 7 -> listOf(Kind.SECOND, Kind.ALT, Kind.AFFINE, Kind.GEOM)
            else -> listOf(Kind.AFFINE, Kind.FIB, Kind.INTERLEAVE, Kind.SECOND, Kind.ALT)
        }
        val shown = if (l <= 3) 5 else if (l <= 7) 6 else 7
        for (attempt in 0 until 80) {
            val kind = GameUtil.pick(rng, kinds)
            val b = build(kind, rng, shown + 1)
            val terms = b.full.subList(0, shown)
            val answer = b.full[shown]
            if (b.full.any { abs(it) > LIMIT }) continue
            if (terms.all { it == terms[0] }) continue
            if (candidateNext(terms) != setOf(answer)) continue
            val expr = terms.joinToString(", ") + ", ?"
            return GameUtil.numericChoice(
                ctx, "عدد بعدی دنباله کدام است؟", expr, answer,
                max(6L, abs(answer - terms.last())), "پاسخ $answer است. ${b.explanation}",
                meta = "seq:${kind.name}:${terms.joinToString(",")}"
            )
        }
        return GameUtil.numericChoice(ctx, "عدد بعدی دنباله کدام است؟", "2, 4, 6, 8, 10, ?", 12, 6, "هر جمله ۲ واحد بیشتر است.", meta = "seq:fallback")
    }
}

/** 6. Rule hunter: pick the rule first, derive examples, verify the answer is unique across candidate rules. */
object RuleHunterGame : BaseGame(
    "rule_hunter", "شکارچی قانون", Category.LOGIC, "🕵️",
    "قانون پنهان بین مثال‌ها را پیدا کن",
    "چند مثال به شکل «ورودی ➜ خروجی» می‌بینی. قانون مشترک را کشف کن و خروجی عدد جدید را انتخاب کن.",
    8000, 1500
) {
    private class Rule(val fa: String, val f: (Long) -> Long)

    private fun digitSum(x: Long): Long { var s = 0L; var v = abs(x); while (v > 0) { s += v % 10; v /= 10 }; return s }

    private val family: List<Rule> by lazy {
        val list = ArrayList<Rule>()
        for (a in -3..9) { if (a == 0) continue
            for (b in -10..20) list.add(Rule("ضرب در $a و جمع با $b") { x -> a * x + b })
        }
        for (k in -10..20) list.add(Rule("مربع عدد به‌اضافه‌ی $k") { x -> x * x + k })
        for (k in 1..9) list.add(Rule("مجموع ارقام ضرب در $k") { x -> digitSum(x) * k })
        list
    }

    override fun generate(ctx: GenContext): Question {
        val rng = ctx.rng
        val l = ctx.level
        for (attempt in 0 until 60) {
            val rule: Rule; val lo: Long; val hi: Long
            when {
                l <= 3 -> { val a = rng.nextInt(2, 6); val b = rng.nextInt(0, 10); rule = Rule("ضرب در $a و جمع با $b") { x -> a * x + b }; lo = 1; hi = 15 }
                l <= 6 -> { val a = rng.nextInt(2, 10); val b = rng.nextInt(-9, 21); rule = Rule("ضرب در $a و جمع با $b") { x -> a * x + b }; lo = 2; hi = 25 }
                l <= 8 -> { val k = rng.nextInt(-10, 21); rule = Rule("مربع عدد به‌اضافه‌ی $k") { x -> x * x + k }; lo = 2; hi = 15 }
                else -> {
                    if (rng.nextBoolean()) { val k = rng.nextInt(1, 10); rule = Rule("مجموع ارقام ضرب در $k") { x -> digitSum(x) * k }; lo = 10; hi = 99 }
                    else { val k = rng.nextInt(-10, 21); rule = Rule("مربع عدد به‌اضافه‌ی $k") { x -> x * x + k }; lo = 2; hi = 20 }
                }
            }
            val exampleCount = if (l <= 4) 3 else 4
            val inputs = LinkedHashSet<Long>()
            var guard = 0
            while (inputs.size < exampleCount + 1 && guard < 100) { inputs.add(rng.nextLong(lo, hi + 1)); guard++ }
            if (inputs.size < exampleCount + 1) continue
            val list = inputs.toList()
            val examples = list.take(exampleCount)
            val query = list.last()
            val answer = rule.f(query)
            val consistent = family.filter { r -> examples.all { r.f(it) == rule.f(it) } }
            if (consistent.map { it.f(query) }.toSet() != setOf(answer)) continue
            val prompt = "قانون را از مثال‌ها پیدا کن:\n" + examples.joinToString("\n") { "$it ➜ ${rule.f(it)}" } + "\n\nخروجی $query چیست؟"
            return GameUtil.numericChoice(
                ctx, prompt, null, answer, max(8L, abs(answer) / 5),
                "قانون: ${rule.fa}؛ پس $query ➜ $answer.", meta = "rule:${rule.fa}"
            )
        }
        return GameUtil.numericChoice(ctx, "قانون را از مثال‌ها پیدا کن:\n1 ➜ 3\n2 ➜ 5\n3 ➜ 7\n\nخروجی 5 چیست؟", null, 11, 6, "قانون: ضرب در ۲ و جمع با ۱.", meta = "rule:fallback")
    }
}

/** 7. Logic deduction: orderings checked by brute force, plus fixed valid syllogism / conditional templates. */
object LogicDeductionGame : BaseGame(
    "logic_deduction", "استنتاج منطقی", Category.LOGIC, "⚖️",
    "از روی جمله‌ها نتیجه‌ی قطعی بگیر",
    "فقط با تکیه بر جمله‌های داده‌شده نتیجه بگیر. اگر نتیجه از جمله‌ها قطعاً درست نمی‌شود یا قطعاً غلط است، همان را انتخاب کن؛ اگر نمی‌شود چیزی گفت، گزینه‌ی «نمی‌توان نتیجه گرفت» را بزن.",
    12000, 2500
) {
    private val names = listOf("آرش", "بهار", "کامران", "دریا", "سارا", "نیما", "ماهان", "رها")
    private val attrs = listOf(
        listOf("بلندتر", "بلندقدترین", "کوتاه‌قدترین"),
        listOf("مسن‌تر", "مسن‌ترین", "جوان‌ترین"),
        listOf("سریع‌تر", "سریع‌ترین", "کندترین")
    )
    private val kinds = listOf("دَرکو", "فِلون", "نیمبو", "سارکو", "ترنو", "اوشیل")
    private val pairs = listOf(
        listOf("آرش به مهمانی می‌رود", "آرش به مهمانی نمی‌رود", "بهار به مهمانی می‌رود", "بهار به مهمانی نمی‌رود"),
        listOf("باران می‌بارد", "باران نمی‌بارد", "خیابان خیس می‌شود", "خیابان خیس نمی‌شود"),
        listOf("زنگ به صدا درمی‌آید", "زنگ به صدا درنمی‌آید", "در باز می‌شود", "در باز نمی‌شود")
    )
    private val answers3 = listOf("بله، قطعاً", "خیر، قطعاً نه", "نمی‌توان نتیجه گرفت")

    /** All permutations (index 0 = highest) consistent with premises (x above y). */
    fun consistentOrders(n: Int, premises: List<Pair<Int, Int>>): List<List<Int>> {
        val out = ArrayList<List<Int>>()
        fun rec(cur: MutableList<Int>, used: BooleanArray) {
            if (cur.size == n) {
                val pos = IntArray(n); cur.forEachIndexed { i, p -> pos[p] = i }
                if (premises.all { pos[it.first] < pos[it.second] }) out.add(cur.toList())
                return
            }
            for (p in 0 until n) if (!used[p]) { used[p] = true; cur.add(p); rec(cur, used); cur.removeAt(cur.size - 1); used[p] = false }
        }
        rec(ArrayList(), BooleanArray(n))
        return out
    }

    override fun generate(ctx: GenContext): Question {
        val rng = ctx.rng
        val l = ctx.level
        return if (rng.nextInt(100) < 50) ordering(ctx, rng, l) ?: syllogism(ctx, rng, l) else syllogism(ctx, rng, l)
    }

    private fun ordering(ctx: GenContext, rng: Random, l: Int): Question? {
        val n = when { l <= 3 -> 3; l <= 7 -> 4; else -> 5 }
        val attr = GameUtil.pick(rng, attrs)
        for (attempt in 0 until 60) {
            val people = names.shuffled(rng).take(n)
            val order = (0 until n).shuffled(rng) // order[i] = person index at rank i
            val allPairs = ArrayList<Pair<Int, Int>>()
            for (i in 0 until n) for (j in i + 1 until n) allPairs.add(order[i] to order[j])
            val k = rng.nextInt(n - 1, n + 2).coerceAtMost(allPairs.size)
            val premises = allPairs.shuffled(rng).take(k)
            val worlds = consistentOrders(n, premises)
            val askMax = rng.nextBoolean()
            val answers = worlds.map { if (askMax) it.first() else it.last() }.toSet()
            if (answers.size != 1) continue
            val answer = answers.first()
            val optIdx = (listOf(answer) + (0 until n).filter { it != answer }.shuffled(rng).take(3)).shuffled(rng)
            val text = premises.joinToString("\n") { "${people[it.first]} از ${people[it.second]} ${attr[0]} است." }
            val q = "کدام‌یک ${if (askMax) attr[1] else attr[2]} است؟"
            return ctx.question(
                ChoiceBody(
                    "فقط با این جمله‌ها نتیجه بگیر:\n$text\n\n$q",
                    null, emptyList(), optIdx.map { people[it] }, emptyList(), optIdx.indexOf(answer),
                    "با ترکیب جمله‌ها فقط ${people[answer]} می‌تواند ${if (askMax) attr[1] else attr[2]} باشد؛ بقیه با یکی از جمله‌ها در تناقض‌اند."
                ),
                "order:${premises.joinToString(";") { "${it.first}>${it.second}" }}:max=$askMax"
            )
        }
        return null
    }

    private fun syllogism(ctx: GenContext, rng: Random, l: Int): Question {
        val ks = kinds.shuffled(rng)
        val a = ks[0]; val b = ks[1]; val c = ks[2]
        val x = GameUtil.pick(rng, names)
        val p = GameUtil.pick(rng, pairs)
        // each template: premises, question, answer index (0 yes, 1 no, 2 unknown), explanation
        class T(val prem: List<String>, val q: String, val ans: Int, val why: String)
        val basic = listOf(
            T(listOf("همه‌ی ${a}ها ${b} هستند.", "$x یک $a است."), "آیا $x یک $b است؟", 0, "چون همه‌ی ${a}ها ${b} هستند و $x یک $a است."),
            T(listOf("هیچ $a ای $b نیست.", "$x یک $a است."), "آیا $x یک $b است؟", 1, "هیچ $a ای $b نیست، پس $x نمی‌تواند $b باشد."),
            T(listOf("اگر ${p[0]}، آنگاه ${p[2]}.", "${p[0]}."), "آیا ${p[2]}؟", 0, "از شرط و برقراری مقدم، تالی نتیجه می‌شود.")
        )
        val mid = listOf(
            T(listOf("همه‌ی ${a}ها ${b} هستند.", "$x یک $b است."), "آیا $x یک $a است؟", 2, "$b بودن لزوماً به معنای $a بودن نیست."),
            T(listOf("همه‌ی ${a}ها ${b} هستند.", "$x یک $b نیست."), "آیا $x یک $a است؟", 1, "اگر $x یک $a بود باید $b می‌بود؛ پس $a نیست."),
            T(listOf("اگر ${p[0]}، آنگاه ${p[2]}.", "${p[3]}."), "آیا ${p[0]}؟", 1, "اگر مقدم برقرار بود، تالی هم برقرار می‌شد؛ پس مقدم برقرار نیست.")
        )
        val hard = listOf(
            T(listOf("همه‌ی ${a}ها ${b} و همه‌ی ${b}ها ${c} هستند.", "$x یک $a است."), "آیا $x یک $c است؟", 0, "زنجیره‌ی $a ← $b ← $c برقرار است."),
            T(listOf("همه‌ی ${a}ها ${b} هستند.", "بعضی ${b}ها ${c} هستند.", "$x یک $a است."), "آیا $x یک $c است؟", 2, "معلوم نیست آن ${b}هایی که $c هستند شامل $x باشند."),
            T(listOf("اگر ${p[0]}، آنگاه ${p[2]}.", "${p[2]}."), "آیا ${p[0]}؟", 2, "برقراری تالی دلیل قطعی بر برقراری مقدم نیست."),
            T(listOf("اگر ${p[0]}، آنگاه ${p[2]}.", "${p[1]}."), "آیا ${p[2]}؟", 2, "نبودن مقدم چیزی درباره‌ی تالی نمی‌گوید.")
        )
        val pool = when { l <= 3 -> basic; l <= 6 -> basic + mid; else -> mid + hard }
        val t = GameUtil.pick(rng, pool)
        return ctx.question(
            ChoiceBody("با توجه به این جمله‌ها:\n" + t.prem.joinToString("\n") + "\n\n" + t.q, null, emptyList(), answers3, emptyList(), t.ans, t.why),
            "syl:${t.ans}"
        )
    }
}

/** 8. Number comparison with exact rational arithmetic. */
object NumberComparisonGame : BaseGame(
    "number_comparison", "مقایسه‌ی اعداد", Category.LOGIC, "⚖️",
    "اعداد، کسرها، درصدها و عبارت‌ها را مقایسه کن",
    "دو مقدار را که ممکن است عدد صحیح، اعشاری، کسر، درصد یا عبارت باشند مقایسه کن و بگو کدام بزرگ‌تر است یا برابرند.",
    5000, 800
) {
    private class Rat(val n: Long, val d: Long) {
        fun compareTo(o: Rat): Int = (n * o.d).compareTo(o.n * d)
    }

    private enum class Form { INT, DEC, PCT, FRAC, EXPR }

    private fun decimalText(r: Rat): String {
        val v100 = r.n * 100 / r.d
        val ip = v100 / 100; val fp = (v100 % 100).toInt()
        return when {
            fp == 0 -> "$ip.0"
            fp % 10 == 0 -> "$ip.${fp / 10}"
            else -> "$ip.${if (fp < 10) "0$fp" else "$fp"}"
        }
    }

    private fun render(r: Rat, form: Form, rng: Random): String {
        val isInt = r.n % r.d == 0L
        val f = if (form == Form.INT && !isInt) Form.DEC else if (form == Form.EXPR && !isInt) Form.FRAC else form
        return when (f) {
            Form.INT -> (r.n / r.d).toString()
            Form.DEC -> decimalText(r)
            Form.PCT -> "${r.n * 100 / r.d}%"
            Form.FRAC -> { val k = rng.nextLong(1, 4); "${r.n * k}/${r.d * k}" }
            Form.EXPR -> {
                val v = r.n / r.d
                val divisors = (2..9).filter { v % it == 0L && v / it >= 2 }
                if (divisors.isNotEmpty()) { val dv = GameUtil.pick(rng, divisors); "$dv×${v / dv}" }
                else { val k = rng.nextLong(2, 9); "${v + k}−$k" }
            }
        }
    }

    override fun generate(ctx: GenContext): Question {
        val rng = ctx.rng
        val l = ctx.level
        val forms = when {
            l <= 3 -> listOf(Form.INT, Form.DEC)
            l <= 6 -> listOf(Form.DEC, Form.FRAC, Form.PCT)
            else -> listOf(Form.DEC, Form.FRAC, Form.PCT, Form.EXPR, Form.INT)
        }
        val dens = if (l <= 3) listOf(1L, 2L, 10L) else listOf(2L, 4L, 5L, 10L, 20L, 25L)
        for (attempt in 0 until 50) {
            val d = GameUtil.pick(rng, dens)
            val a = Rat(rng.nextLong(d, 20 * d + 1), d)
            val equalCase = rng.nextInt(100) < 15
            val b: Rat = if (equalCase) a else {
                val d2 = GameUtil.pick(rng, dens)
                val delta = rng.nextLong(1, 4)
                val sign = if (rng.nextBoolean()) 1 else -1
                val nn = a.n * d2 + sign * delta * a.d
                if (nn <= 0) continue
                Rat(nn, a.d * d2).let { Rat(it.n, it.d) }
            }
            if (b.d > 100_000L || b.d <= 0L) continue
            // renderable forms need denominators dividing 100 (decimal/percent); fall back to fraction otherwise
            val renderableB = 100 % b.d == 0L
            val fa = GameUtil.pick(rng, forms)
            var fb = GameUtil.pick(rng, forms)
            if (equalCase && fb == fa) fb = if (fa == Form.FRAC) Form.DEC else Form.FRAC
            val ta = render(a, fa, rng)
            val tb = if (renderableB) render(b, fb, rng) else render(b, Form.FRAC, rng)
            if (ta == tb) continue
            val cmp = a.compareTo(b)
            val idx = if (cmp > 0) 0 else if (cmp < 0) 1 else 2
            val why = when (idx) {
                0 -> "مقدار عبارت اول بزرگ‌تر است."
                1 -> "مقدار عبارت دوم بزرگ‌تر است."
                else -> "هر دو مقدار دقیقاً برابرند."
            }
            return ctx.question(
                ChoiceBody(
                    "کدام مقدار بزرگ‌تر است؟", null,
                    listOf(Glyph(ta, description = "اول"), Glyph(tb, description = "دوم")),
                    listOf("عبارت اول بزرگ‌تر است", "عبارت دوم بزرگ‌تر است", "هر دو برابرند"),
                    emptyList(), idx, "$ta و $tb: $why"
                ),
                "cmp:$ta|$tb"
            )
        }
        return ctx.question(
            ChoiceBody("کدام مقدار بزرگ‌تر است؟", null, listOf(Glyph("3", description = "اول"), Glyph("2", description = "دوم")),
                listOf("عبارت اول بزرگ‌تر است", "عبارت دوم بزرگ‌تر است", "هر دو برابرند"), emptyList(), 0, "۳ از ۲ بزرگ‌تر است."), "cmp:fallback"
        )
    }
}
