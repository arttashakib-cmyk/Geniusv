package com.mindrush.app.feature

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.runtime.collectAsState
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.mindrush.app.core.Fa
import com.mindrush.app.game.Answer
import com.mindrush.app.game.ChoiceBody
import com.mindrush.app.game.Feedback
import com.mindrush.app.game.GameMode
import com.mindrush.app.game.GameRegistry
import com.mindrush.app.game.GridBody
import com.mindrush.app.game.PickBody
import com.mindrush.app.game.Phase
import com.mindrush.app.game.Question
import com.mindrush.app.game.ReactionBody
import com.mindrush.app.game.RecallBody
import com.mindrush.app.game.RecallMode
import kotlinx.coroutines.delay

@Composable
fun PlayScreen(vm: PlayViewModel, gameId: String, mode: GameMode, onFinished: () -> Unit, onExit: () -> Unit) {
    val ui by vm.ui.collectAsState()
    val s = ui.s
    val game = GameRegistry.byId(gameId)
    var showExit by remember { mutableStateOf(false) }

    LifecycleEventEffect(Lifecycle.Event.ON_STOP) { vm.pause() }
    BackHandler(enabled = true) { vm.pause(); showExit = true }

    LaunchedEffect(ui.saved, ui.exited) {
        if (ui.saved) { if (ui.exited) onExit() else onFinished() }
    }
    LaunchedEffect(ui.started, s.phase) {
        if (ui.started && s.phase == Phase.ACTIVE) {
            while (true) { delay(100); vm.tick() }
        }
    }

    var hiddenSeq by remember { mutableStateOf(-1) }
    val fb = s.feedback
    LaunchedEffect(fb?.seq) {
        if (fb != null && !s.awaitingAdvance) { delay(900); hiddenSeq = fb.seq }
    }

    Column(Modifier.fillMaxSize().background(GenColors.bg).padding(horizontal = 16.dp, vertical = 12.dp)) {
        if (ui.loading || game == null) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { FText("در حال آماده‌سازی…") }
        } else if (!ui.started) {
            StartCard(game.nameFa, game.emoji, game.instructionsFa, mode, onStart = { vm.begin() }, onBack = { vm.exit() })
        } else if (ui.saving || s.phase == Phase.FINISHED) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { FText("در حال ذخیره‌ی نتیجه…") }
        } else {
            TopStatus(s, mode, onPause = { vm.pause() })
            Spacer(Modifier.height(10.dp))
            val q = s.question
            Box(Modifier.weight(1f).fillMaxWidth()) {
                if (q != null) {
                    androidx.compose.runtime.key(q.id, s.presentationKey) {
                        QuestionContent(q, vm, enabled = !s.awaitingAdvance && s.phase == Phase.ACTIVE)
                    }
                }
            }
            val showFb = fb != null && (s.awaitingAdvance || fb.seq != hiddenSeq)
            if (showFb && fb != null) {
                FeedbackBar(fb, s.awaitingAdvance, onContinue = { vm.advance() })
            }
            if (q != null && q.body !is ReactionBody && !s.awaitingAdvance) {
                Spacer(Modifier.height(8.dp))
                SecondaryButton("ردکردن این سؤال") { vm.skip(q.id) }
            }
        }
    }

    if (s.phase == Phase.PAUSED && ui.started && !showExit && !ui.saving) {
        AlertDialog(
            onDismissRequest = {},
            title = { FText("بازی متوقف شد", fontWeight = FontWeight.Bold) },
            text = { FText("زمان متوقف شده است. سؤال فعلی بعد از ادامه دوباره از ابتدا نمایش داده می‌شود.") },
            confirmButton = { TextButton(onClick = { vm.resume() }) { FText("ادامه") } },
            dismissButton = { TextButton(onClick = { showExit = true }) { FText("خروج") } }
        )
    }
    if (showExit) {
        AlertDialog(
            onDismissRequest = { showExit = false; vm.resume() },
            title = { FText("خروج از بازی؟", fontWeight = FontWeight.Bold) },
            text = { FText("اگر خارج شوی، این دور «نیمه‌تمام» ثبت می‌شود و در رکوردها حساب نمی‌شود.") },
            confirmButton = { TextButton(onClick = { showExit = false; vm.exit() }) { FText("خروج", color = GenColors.bad) } },
            dismissButton = { TextButton(onClick = { showExit = false; vm.resume() }) { FText("ادامه‌ی بازی") } }
        )
    }
}

@Composable
private fun StartCard(name: String, emoji: String, instructions: String, mode: GameMode, onStart: () -> Unit, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Spacer(Modifier.height(24.dp))
        FText(emoji, fontSize = 48.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
        FText(name, fontSize = 26.sp, fontWeight = FontWeight.Bold, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
        GCard { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            FText("حالت ${mode.fa}", fontWeight = FontWeight.Bold, color = GenColors.accent)
            FText(mode.ruleFa, color = GenColors.muted)
            FText(instructions)
        } }
        PrimaryButton("آماده‌ام، شروع کن") { onStart() }
        SecondaryButton("بازگشت") { onBack() }
    }
}

@Composable
private fun TopStatus(s: com.mindrush.app.game.SessionState, mode: GameMode, onPause: () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Box(
                Modifier.background(GenColors.surfaceHigh, RoundedCornerShape(10.dp)).clickable { onPause() }.padding(horizontal = 12.dp, vertical = 6.dp)
            ) { FText("⏸ توقف", fontSize = 14.sp) }
            FText("امتیاز: ${s.score}", fontSize = 18.sp, fontWeight = FontWeight.Bold)
            val timeText = Fa.clock(s.displayMs)
            FText(if (s.countdown) "⏱ $timeText" else "⏱ $timeText", fontSize = 16.sp,
                color = if (s.countdown && s.displayMs < 10_000) GenColors.bad else MaterialTheme.colorScheme.onSurface)
        }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            FText("سطح ${s.level}", fontSize = 13.sp, color = GenColors.accent)
            if (s.lives != null) FText("جان: " + "❤️".repeat((s.lives ?: 0).coerceAtLeast(0)), fontSize = 14.sp)
            if (s.totalQuestions != null) FText("سؤال ${s.questionNumber} از ${s.totalQuestions}", fontSize = 13.sp, color = GenColors.muted)
            else FText("پشت‌سرهم: ${s.streak}", fontSize = 13.sp, color = GenColors.muted)
        }
        if (s.totalQuestions != null) {
            LinearProgressIndicator(
                progress = { ((s.questionNumber - 1).coerceAtLeast(0).toFloat() / s.totalQuestions!!).coerceIn(0f, 1f) },
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
private fun FeedbackBar(fb: Feedback, awaiting: Boolean, onContinue: () -> Unit) {
    val color = when { fb.skipped -> GenColors.muted; fb.correct -> GenColors.good; else -> GenColors.bad }
    val title = when { fb.skipped -> "ردشد"; fb.correct -> "درست! +${fb.points}"; else -> "نادرست" }
    Column(
        Modifier.fillMaxWidth().padding(top = 8.dp).background(GenColors.surface, RoundedCornerShape(14.dp)).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        FText(title, color = color, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        if (awaiting) {
            FText(fb.explanation, fontSize = 14.sp)
            PrimaryButton("ادامه") { onContinue() }
        }
    }
}

@Composable
private fun QuestionContent(q: Question, vm: PlayViewModel, enabled: Boolean) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        if (q.component != null) {
            FText("حوزه‌ی «${GameRegistry.componentFa(q.component)}»", fontSize = 13.sp, color = GenColors.accent)
        }
        when (val b = q.body) {
            is ChoiceBody -> ChoiceView(b, enabled) { vm.submit(q.id, Answer.Index(it)) }
            is PickBody -> PickView(b, enabled) { vm.submit(q.id, Answer.Index(it)) }
            is RecallBody -> RecallView(q, b, enabled, vm)
            is GridBody -> GridView(q, b, enabled, vm)
            is ReactionBody -> ReactionView(q, b, enabled, vm)
        }
    }
}

@Composable
private fun RuleBanner(rule: String?, banner: String?) {
    if (banner != null) {
        FText(banner, color = GenColors.accent, fontWeight = FontWeight.Bold, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
    }
    if (rule != null) {
        Box(Modifier.fillMaxWidth().background(GenColors.surfaceHigh, RoundedCornerShape(12.dp)).padding(10.dp), contentAlignment = Alignment.Center) {
            FText(rule, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        }
    }
}

@Composable
private fun ChoiceView(b: ChoiceBody, enabled: Boolean, onAnswer: (Int) -> Unit) {
    RuleBanner(b.rule, null)
    FText(b.prompt, fontSize = 17.sp, modifier = Modifier.fillMaxWidth())
    if (b.expression != null) {
        Box(Modifier.fillMaxWidth().padding(vertical = 8.dp), contentAlignment = Alignment.Center) {
            Ltr { FText(b.expression, fontSize = 30.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center) }
        }
    }
    if (b.glyphs.isNotEmpty()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
            for (g in b.glyphs) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    if (b.glyphs.size > 1 && g.description.isNotEmpty()) FText(g.description, fontSize = 12.sp, color = GenColors.muted)
                    GlyphView(g, boxSize = 56.dp, fontSize = 32.sp)
                }
            }
        }
    }
    Spacer(Modifier.height(4.dp))
    b.options.chunked(2).forEachIndexed { row, items ->
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            items.forEachIndexed { col, text ->
                val idx = row * 2 + col
                val colorIdx = b.optionColors.getOrNull(idx) ?: -1
                OptionButton(text, colorIdx, enabled, Modifier.weight(1f)) { onAnswer(idx) }
            }
            if (items.size == 1) Spacer(Modifier.weight(1f))
        }
    }
}

@Composable
private fun OptionButton(text: String, colorIdx: Int, enabled: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Box(
        modifier.heightIn(min = 64.dp)
            .background(GenColors.surfaceHigh, RoundedCornerShape(14.dp))
            .clickable(enabled = enabled, onClick = onClick).padding(10.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (colorIdx >= 0) Box(Modifier.size(16.dp).background(GenColors.ink(colorIdx), RoundedCornerShape(50)))
            Ltr { FText(text, fontSize = 20.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center) }
        }
    }
}

@Composable
private fun PickView(b: PickBody, enabled: Boolean, onAnswer: (Int) -> Unit) {
    RuleBanner(b.rule, b.banner)
    FText(b.prompt, fontSize = 17.sp, modifier = Modifier.fillMaxWidth())
    if (b.target.isNotEmpty()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
            for (g in b.target) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    if (g.description.isNotEmpty()) FText(g.description, fontSize = 12.sp, color = GenColors.muted)
                    GlyphView(g, boxSize = 80.dp, fontSize = 44.sp)
                }
            }
        }
    }
    val cell = if (b.items.firstOrNull()?.cells?.isNotEmpty() == true) 110.dp else 56.dp
    b.items.chunked(b.columns).forEachIndexed { row, items ->
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items.forEachIndexed { col, g ->
                val idx = row * b.columns + col
                Box(
                    Modifier.weight(1f).heightIn(min = cell)
                        .background(GenColors.surfaceHigh, RoundedCornerShape(12.dp))
                        .clickable(enabled = enabled) { onAnswer(idx) }.padding(6.dp),
                    contentAlignment = Alignment.Center
                ) { GlyphView(g, boxSize = if (g.cells.isNotEmpty()) 96.dp else 44.dp, fontSize = if (b.items.size <= 2) 32.sp else 24.sp) }
            }
            repeat(b.columns - items.size) { Spacer(Modifier.weight(1f)) }
        }
    }
}

@Composable
private fun RecallView(q: Question, b: RecallBody, enabled: Boolean, vm: PlayViewModel) {
    var shown by remember { mutableStateOf<String?>(null) }
    var inputPhase by remember { mutableStateOf(false) }
    var text by remember { mutableStateOf("") }

    LaunchedEffect(q.id) {
        delay(400)
        for (step in b.steps) {
            shown = step
            delay(b.showMsPerStep)
            shown = null
            delay(150)
        }
        inputPhase = true
        vm.beginInput(q.id)
    }

    FText(b.prompt, fontSize = 16.sp, modifier = Modifier.fillMaxWidth())
    if (!inputPhase) {
        Box(Modifier.fillMaxWidth().height(160.dp).background(GenColors.surface, RoundedCornerShape(16.dp)), contentAlignment = Alignment.Center) {
            Ltr { FText(shown ?: "", fontSize = 56.sp, fontWeight = FontWeight.Bold) }
        }
        FText("به نمایش دقت کن…", color = GenColors.muted, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
    } else {
        Box(Modifier.fillMaxWidth().heightIn(min = 72.dp).background(GenColors.surface, RoundedCornerShape(16.dp)).padding(12.dp), contentAlignment = Alignment.Center) {
            Ltr { FText(if (text.isEmpty()) "—" else text, fontSize = 32.sp, fontWeight = FontWeight.Bold, maxLines = 2) }
        }
        Keypad(
            allowMinus = b.mode == RecallMode.NUMERIC, enabled = enabled,
            onKey = { k -> if (text.length < 14) text += k },
            onMinus = { if (text.isEmpty()) text = "-" },
            onBackspace = { if (text.isNotEmpty()) text = text.dropLast(1) }
        )
        PrimaryButton("تأیید پاسخ", enabled = enabled && text.isNotEmpty() && text != "-") { vm.submit(q.id, Answer.Typed(text)) }
    }
}

@Composable
private fun Keypad(allowMinus: Boolean, enabled: Boolean, onKey: (String) -> Unit, onMinus: () -> Unit, onBackspace: () -> Unit) {
    Ltr {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            val rows = listOf(listOf("1", "2", "3"), listOf("4", "5", "6"), listOf("7", "8", "9"))
            for (r in rows) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    for (k in r) KeyButton(k, enabled, Modifier.weight(1f)) { onKey(k) }
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (allowMinus) KeyButton("−", enabled, Modifier.weight(1f)) { onMinus() } else Spacer(Modifier.weight(1f))
                KeyButton("0", enabled, Modifier.weight(1f)) { onKey("0") }
                KeyButton("⌫", enabled, Modifier.weight(1f)) { onBackspace() }
            }
        }
    }
}

@Composable
private fun KeyButton(label: String, enabled: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Box(
        modifier.heightIn(min = 56.dp).background(GenColors.surfaceHigh, RoundedCornerShape(12.dp))
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) { FText(label, fontSize = 24.sp, fontWeight = FontWeight.Bold) }
}

@Composable
private fun GridView(q: Question, b: GridBody, enabled: Boolean, vm: PlayViewModel) {
    var phaseInput by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf(setOf<Int>()) }
    LaunchedEffect(q.id) {
        delay(500)
        delay(b.showMs)
        phaseInput = true
        vm.beginInput(q.id)
    }
    FText(b.prompt, fontSize = 17.sp, modifier = Modifier.fillMaxWidth())
    FText(if (phaseInput) "خانه‌های انتخابی: ${selected.size} از ${b.cells.size}" else "به خانه‌های روشن دقت کن…", color = GenColors.muted)
    for (r in 0 until b.size) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            for (c in 0 until b.size) {
                val idx = r * b.size + c
                val lit = !phaseInput && b.cells.contains(idx)
                val sel = phaseInput && selected.contains(idx)
                Box(
                    Modifier.weight(1f).height(if (b.size >= 5) 54.dp else 66.dp)
                        .background(if (lit || sel) MaterialTheme.colorScheme.primary else GenColors.surfaceHigh, RoundedCornerShape(10.dp))
                        .clickable(enabled = enabled && phaseInput) { selected = if (selected.contains(idx)) selected - idx else selected + idx }
                )
            }
        }
    }
    if (phaseInput) PrimaryButton("تأیید", enabled = enabled && selected.isNotEmpty()) { vm.submit(q.id, Answer.Cells(selected)) }
}

@Composable
private fun ReactionView(q: Question, b: ReactionBody, enabled: Boolean, vm: PlayViewModel) {
    var stimulus by remember { mutableStateOf(false) }
    var responded by remember { mutableStateOf(false) }

    LaunchedEffect(q.id) {
        delay(b.preDelayMs)               // waiting time is never part of the reaction time
        stimulus = true
        vm.beginInput(q.id)               // clock for the reaction time starts here, at stimulus onset
        delay(b.windowMs)
        if (!responded) {
            responded = true
            vm.submit(q.id, Answer.Reaction(tapped = false))
        }
    }
    RuleBanner(b.rule, null)
    Box(
        Modifier.fillMaxWidth().height(360.dp).background(GenColors.surface, RoundedCornerShape(20.dp))
            .clickable(enabled = enabled && !responded) {
                responded = true
                vm.submit(q.id, Answer.Reaction(tapped = true, premature = !stimulus))
            },
        contentAlignment = Alignment.Center
    ) {
        if (stimulus) GlyphView(b.glyph, boxSize = 120.dp, fontSize = 110.sp)
        else FText("آماده باش… هنوز نزن", color = GenColors.muted, fontSize = 18.sp)
    }
    FText("فقط وقتی دایره‌ی سبز ● دیدی بزن", color = GenColors.muted, fontSize = 13.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
}
