package com.mindrush.app.feature

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mindrush.app.AppContainer
import com.mindrush.app.FinishedSession
import com.mindrush.app.core.MonotonicClock
import com.mindrush.app.data.AchievementEntity
import com.mindrush.app.data.AppSettings
import com.mindrush.app.data.DayTotals
import com.mindrush.app.data.DifficultyProfileEntity
import com.mindrush.app.data.GameAggregate
import com.mindrush.app.data.GameDetail
import com.mindrush.app.data.PersonalRecordEntity
import com.mindrush.app.data.SaveOutcome
import com.mindrush.app.data.StatusCount
import com.mindrush.app.game.AdaptiveDifficultyEngine
import com.mindrush.app.game.Answer
import com.mindrush.app.game.FinishReason
import com.mindrush.app.game.GameMode
import com.mindrush.app.game.GameRegistry
import com.mindrush.app.game.GameSessionEngine
import com.mindrush.app.game.Phase
import com.mindrush.app.game.SessionConfig
import com.mindrush.app.game.SessionState
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID

@OptIn(ExperimentalCoroutinesApi::class)
class MainViewModel(private val c: AppContainer) : ViewModel() {
    val settings: StateFlow<AppSettings?> =
        c.settings.settings.map<AppSettings, AppSettings?> { it }.stateIn(viewModelScope, SharingStarted.Eagerly, null)
    val aggregates: StateFlow<List<GameAggregate>> =
        c.repo.gameAggregates().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val statusCounts: StateFlow<List<StatusCount>> =
        c.repo.statusCounts().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val profiles: StateFlow<List<DifficultyProfileEntity>> =
        c.repo.profiles().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val achievements: StateFlow<List<AchievementEntity>> =
        c.repo.achievements().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    private val tz = settings.filterNotNull().map { it.timeZoneId }.distinctUntilChanged()
    val today: StateFlow<DayTotals?> =
        tz.flatMapLatest { c.repo.todayTotals(it) }.map<DayTotals, DayTotals?> { it }
            .stateIn(viewModelScope, SharingStarted.Eagerly, null)
    val dayStreak: StateFlow<Int> =
        tz.flatMapLatest { c.repo.dayStreak(it) }.stateIn(viewModelScope, SharingStarted.Eagerly, 0)

    val message = MutableStateFlow<String?>(null)
    val detail = MutableStateFlow<GameDetail?>(null)

    fun update(transform: (AppSettings) -> AppSettings) {
        viewModelScope.launch { c.settings.update(transform) }
    }

    fun changeTimeZone(id: String) {
        viewModelScope.launch {
            c.settings.update { it.copy(timeZoneId = id) }
            try {
                c.repo.rebuildDerived(id)
                message.value = "منطقه‌ی زمانی عوض شد و خلاصه‌ی روزانه دوباره محاسبه شد."
            } catch (t: Throwable) {
                message.value = "تغییر منطقه‌ی زمانی انجام شد، اما بازسازی آمار با خطا روبه‌رو شد."
            }
        }
    }

    suspend fun record(gameId: String, mode: GameMode): PersonalRecordEntity? = c.repo.record(gameId, mode)
    suspend fun profileLevel(gameId: String): Int = c.repo.profileLevel(gameId)

    fun loadDetail(gameId: String) {
        viewModelScope.launch { detail.value = c.repo.gameDetail(gameId) }
    }

    fun closeDetail() { detail.value = null }

    fun export(uri: Uri) {
        viewModelScope.launch {
            try {
                val out = c.context.contentResolver.openOutputStream(uri)
                if (out == null) {
                    message.value = "ساخت فایل خروجی ممکن نشد."
                } else {
                    out.use { c.repo.exportJson(it, "1.0.0") }
                    message.value = "فایل خروجی ذخیره شد."
                }
            } catch (t: Throwable) {
                message.value = "ذخیره‌ی فایل خروجی با خطا روبه‌رو شد."
            }
        }
    }

    fun rebuild() {
        viewModelScope.launch {
            val tzId = settings.value?.timeZoneId ?: java.util.TimeZone.getDefault().id
            try {
                c.repo.rebuildDerived(tzId)
                message.value = "خلاصه‌ها و رکوردها از روی سوابق دوباره ساخته شد."
            } catch (t: Throwable) {
                message.value = "بازسازی با خطا روبه‌رو شد."
            }
        }
    }

    fun deleteAll() {
        viewModelScope.launch {
            try {
                c.repo.deleteAllData()
                c.settings.clear()
                c.settings.update { it.copy(onboardingDone = true) }
                c.lastResult.value = null
                message.value = "همه‌ی داده‌های محلی حذف شد."
            } catch (t: Throwable) {
                message.value = "حذف داده‌ها با خطا روبه‌رو شد."
            }
        }
    }

    fun clearMessage() { message.value = null }
}

data class PlayUi(
    val loading: Boolean = true,
    val started: Boolean = false,
    val s: SessionState = SessionState(),
    val saving: Boolean = false,
    val saved: Boolean = false,
    val exited: Boolean = false
)

class PlayViewModel(
    private val c: AppContainer,
    private val gameId: String,
    private val mode: GameMode,
    private val fixedLevel: Int?
) : ViewModel() {
    private val _ui = MutableStateFlow(PlayUi())
    val ui: StateFlow<PlayUi> = _ui.asStateFlow()

    private var engine: GameSessionEngine? = null
    private var rowId = 0L
    private var tz = "UTC"
    private var lastSec = -1L
    private var finishing = false

    init { viewModelScope.launch { prepare() } }

    private suspend fun prepare() {
        val st = c.settings.settings.first()
        tz = st.timeZoneId
        val game = GameRegistry.byId(gameId)
        if (game == null) { _ui.value = PlayUi(loading = false, saved = true, exited = true); return }
        val startLevel = c.repo.profileLevel(gameId)
        val cfg = SessionConfig(
            sessionId = UUID.randomUUID().toString(), gameId = gameId, mode = mode,
            durationSec = if (mode == GameMode.SURVIVAL) st.survivalDurationSec else st.speedDurationSec,
            questionCount = st.accuracyQuestions, lives = st.survivalLives,
            fixedLevel = fixedLevel, startLevel = startLevel, seed = System.nanoTime()
        )
        val e = GameSessionEngine(cfg, game, MonotonicClock, AdaptiveDifficultyEngine(fixedLevel ?: startLevel, fixedLevel != null))
        engine = e
        _ui.value = PlayUi(loading = false, s = e.state())
    }

    fun begin() {
        val e = engine ?: return
        if (_ui.value.started) return
        viewModelScope.launch {
            rowId = try { c.repo.beginSession(e.config, System.currentTimeMillis(), tz) } catch (t: Throwable) { -1L }
            e.start()
            publish()
        }
    }

    private fun publish() {
        val e = engine ?: return
        val st = e.state()
        lastSec = st.displayMs / 1000
        _ui.value = _ui.value.copy(started = true, s = st)
    }

    fun tick() {
        val e = engine ?: return
        if (finishing || !_ui.value.started) return
        e.tick()
        val st = e.state()
        if (st.phase == Phase.FINISHED) { onFinished(); return }
        val sec = st.displayMs / 1000
        if (sec != lastSec) { lastSec = sec; _ui.value = _ui.value.copy(s = st) }
    }

    fun beginInput(questionId: String) { engine?.beginInput(questionId) }

    fun submit(questionId: String, answer: Answer) {
        val e = engine ?: return
        if (finishing) return
        e.submit(questionId, answer)
        afterAction()
    }

    fun skip(questionId: String) = submit(questionId, Answer.Skip)

    fun advance() { engine?.advance(); afterAction() }

    fun pause() {
        if (!_ui.value.started || finishing) return
        engine?.pause(); publish()
    }

    fun resume() {
        if (!_ui.value.started || finishing) return
        engine?.resume(); publish()
    }

    fun exit() {
        val e = engine
        if (e == null || !_ui.value.started) { _ui.value = _ui.value.copy(saved = true, exited = true); return }
        if (finishing) return
        e.finish(FinishReason.USER_EXIT)
        afterAction()
    }

    private fun afterAction() {
        val e = engine ?: return
        val st = e.state()
        if (st.phase == Phase.FINISHED) onFinished() else publish()
    }

    private fun onFinished() {
        if (finishing) return
        finishing = true
        val e = engine ?: return
        _ui.value = _ui.value.copy(started = true, s = e.state(), saving = true)
        viewModelScope.launch {
            val r = e.result()
            var outcome: SaveOutcome? = null
            try {
                if (rowId > 0) {
                    if (r.records.isEmpty() && r.reason == FinishReason.USER_EXIT) c.repo.discardSession(rowId)
                    else outcome = c.repo.finalizeSession(rowId, r, tz)
                }
            } catch (t: Throwable) {
                outcome = null
            }
            val exited = r.reason == FinishReason.USER_EXIT
            c.lastResult.value = if (exited) null else FinishedSession(r, outcome)
            _ui.value = _ui.value.copy(saving = false, saved = true, exited = exited)
        }
    }
}
