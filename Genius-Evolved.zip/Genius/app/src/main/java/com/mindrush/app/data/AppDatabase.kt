package com.mindrush.app.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [
        SessionEntity::class, AnswerEventEntity::class, PersonalRecordEntity::class,
        DifficultyProfileEntity::class, DailySummaryEntity::class, AchievementEntity::class,
        UserProgressEntity::class, DailyMissionEntity::class, SkillStatEntity::class
    ],
    version = 2,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun sessions(): SessionDao
    abstract fun events(): EventDao
    abstract fun records(): RecordDao
    abstract fun difficulty(): DifficultyDao
    abstract fun daily(): DailyDao
    abstract fun achievements(): AchievementDao
    abstract fun progress(): ProgressDao
    abstract fun missions(): MissionDao
    abstract fun skills(): SkillDao

    companion object {
        fun build(context: Context): AppDatabase =
            Room.databaseBuilder(context, AppDatabase::class.java, "genius.db")
                .addMigrations(*Migrations.ALL)
                .build()
    }
}

/**
 * Add a Migration here whenever [AppDatabase.version] increases. The database is NEVER wiped to
 * solve a migration problem (no fallbackToDestructiveMigration anywhere).
 */
object Migrations {
    val MIGRATION_1_2 = object : Migration(1, 2) {
        override fun migrate(db: SupportSQLiteDatabase) {
            db.execSQL("""
                CREATE TABLE IF NOT EXISTS user_progress (
                    id INTEGER NOT NULL PRIMARY KEY,
                    totalXp INTEGER NOT NULL,
                    level INTEGER NOT NULL,
                    lastDailyKey TEXT NOT NULL,
                    dailyCompleted INTEGER NOT NULL,
                    updatedAt INTEGER NOT NULL
                )
            """.trimIndent())
            db.execSQL("""
                CREATE TABLE IF NOT EXISTS daily_missions (
                    id TEXT NOT NULL PRIMARY KEY,
                    dayKey TEXT NOT NULL,
                    gameId TEXT NOT NULL,
                    mode TEXT NOT NULL,
                    targetCorrect INTEGER NOT NULL,
                    completed INTEGER NOT NULL,
                    progress INTEGER NOT NULL,
                    xpReward INTEGER NOT NULL
                )
            """.trimIndent())
            db.execSQL("CREATE INDEX IF NOT EXISTS index_daily_missions_dayKey ON daily_missions(dayKey)")
            db.execSQL("""
                CREATE TABLE IF NOT EXISTS skill_stats (
                    skillId TEXT NOT NULL PRIMARY KEY,
                    sampleCount INTEGER NOT NULL,
                    correctCount INTEGER NOT NULL,
                    totalResponseMs INTEGER NOT NULL,
                    lastPlayedAt INTEGER NOT NULL,
                    bestAccuracy REAL NOT NULL
                )
            """.trimIndent())
            db.execSQL("CREATE INDEX IF NOT EXISTS index_skill_stats_skillId ON skill_stats(skillId)")
            // Seed default progress row
            db.execSQL("INSERT OR IGNORE INTO user_progress (id, totalXp, level, lastDailyKey, dailyCompleted, updatedAt) VALUES (1, 0, 1, '', 0, 0)")
        }
    }
    val ALL: Array<Migration> = arrayOf(MIGRATION_1_2)
}
