package com.mindrush.app.domain

import com.mindrush.app.game.Category
import com.mindrush.app.game.GameRegistry

/**
 * Hierarchical cognitive skill model.
 * Each skill maps to games that exercise it. Metrics are computed from session history.
 * This is a training/measurement aid, not a clinical assessment.
 */
data class SkillDef(
    val id: String,
    val nameFa: String,
    val nameEn: String,
    val categoryId: String,
    val definitionFa: String,
    val relatedGameIds: List<String>,
    val metrics: List<String> = listOf("accuracy", "median_rt", "sample_count")
)

object SkillRegistry {
    val all: List<SkillDef> = listOf(
        SkillDef("processing_speed", "سرعت پردازش", "Processing Speed", "speed",
            "پاسخ سریع و صحیح به محرک‌های ساده یا پیچیده در شرایط کنترل‌شده.",
            listOf("rapid_match", "target_search", "color_direction", "selective_reaction", "odd_shape")),
        SkillDef("reaction_time", "زمان واکنش", "Reaction Time", "speed",
            "سرعت پاسخ به ظهور محرک هدف و مهار پاسخ به محرک غیرهدف.",
            listOf("selective_reaction", "color_direction")),
        SkillDef("working_memory", "حافظه کاری", "Working Memory", "memory",
            "نگه‌داشتن و دست‌کاری اطلاعات در ذهن برای مدت کوتاه.",
            listOf("number_memory", "reverse_memory", "grid_memory", "mental_update")),
        SkillDef("short_term_memory", "حافظه کوتاه‌مدت", "Short-Term Memory", "memory",
            "یادآوری دقیق محرک‌های اخیر بدون دست‌کاری پیچیده.",
            listOf("number_memory", "grid_memory")),
        SkillDef("selective_attention", "توجه انتخابی", "Selective Attention", "attention",
            "تمرکز روی هدف در حضور عوامل مزاحم.",
            listOf("target_search", "odd_one_out", "odd_shape", "change_detection")),
        SkillDef("inhibitory_control", "کنترل بازداری", "Inhibitory Control", "attention",
            "مهار پاسخ خودکار یا پاسخ به محرک ممنوع.",
            listOf("selective_reaction", "rule_switch")),
        SkillDef("inductive_reasoning", "استدلال استقرایی", "Inductive Reasoning", "logic",
            "کشف قانون از نمونه‌ها و تعمیم آن.",
            listOf("number_sequence", "rule_hunter", "seq_predict")),
        SkillDef("deductive_reasoning", "استدلال قیاسی", "Deductive Reasoning", "logic",
            "نتیجه‌گیری ضروری از مقدمات و سرنخ‌ها.",
            listOf("logic_deduction", "logic_grid", "contradiction", "ordering")),
        SkillDef("pattern_recognition", "تشخیص الگو", "Pattern Recognition", "logic",
            "شناسایی ساختار تکراری یا قانونی در داده‌ها.",
            listOf("number_sequence", "rule_hunter", "seq_predict", "signal_noise")),
        SkillDef("spatial_visualization", "تجسم فضایی", "Spatial Visualization", "visual",
            "تصور تغییرات شکل و موقعیت در ذهن.",
            listOf("spatial_rotation", "mental_rotation_2d", "symmetry")),
        SkillDef("visual_perception", "ادراک بصری", "Visual Perception", "visual",
            "تشخیص تفاوت‌ها، تقارن، تغییر و ویژگی‌های دیداری.",
            listOf("length_illusion", "odd_shape", "change_detection", "symmetry")),
        SkillDef("probabilistic_judgment", "قضاوت احتمالاتی", "Probabilistic Judgment", "intuition",
            "تخمین احتمال و تصمیم‌گیری تحت عدم‌قطعیت با کالیبراسیون اطمینان.",
            listOf("prob_estimate", "confidence", "signal_noise")),
        SkillDef("cognitive_flexibility", "انعطاف شناختی", "Cognitive Flexibility", "flexible",
            "تطبیق با تغییر قانون و جابه‌جایی بین مجموعه‌های ذهنی.",
            listOf("rule_switch", "mental_chain", "odd_one_out")),
        SkillDef("calculation_speed", "سرعت محاسبه", "Calculation Speed", "arithmetic",
            "انجام عملیات عددی ذهنی با دقت و سرعت.",
            listOf("addition", "subtraction", "multiplication", "mixed_operations", "number_comparison")),
        SkillDef("problem_solving", "حل مسئله", "Problem Solving", "puzzle",
            "استفاده از سرنخ‌ها برای رسیدن به راه‌حل یکتا.",
            listOf("cipher", "logic_grid", "number_lock", "contradiction", "ordering"))
    )

    fun byId(id: String) = all.firstOrNull { it.id == id }
    fun forGame(gameId: String) = all.filter { gameId in it.relatedGameIds }
    fun byCategory(cat: String) = all.filter { it.categoryId == cat }
}
