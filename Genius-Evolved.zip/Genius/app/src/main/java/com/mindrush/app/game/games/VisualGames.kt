package com.mindrush.app.game.games

import com.mindrush.app.game.*
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

/**
 * Visual perception games. Use Glyph cells / color for stimuli.
 * All questions validated before return.
 */

/** 21. Length illusion — which line is longer? (Müller-Lyer style simplified) */
object LengthIllusionGame : BaseGame(
    "length_illusion", "توهم طول", Category.VISUAL, "📏",
    "کدام خط واقعاً بلندتر است؟",
    "دو خط با نشانه‌های پیکان یا بدون پیکان نمایش داده می‌شوند. خطی که واقعاً بلندتر است را انتخاب کن. گاهی چشم فریب می‌خورد.",
    4000, 400
) {
    override fun generate(ctx: GenContext): Question {
        val rng = ctx.rng
        val base = 40 + rng.nextInt(20)
        val delta = 4 + ctx.level / 2 + rng.nextInt(3)
        val aLonger = rng.nextBoolean()
        val lenA = if (aLonger) base + delta else base
        val lenB = if (aLonger) base else base + delta
        val wingsA = rng.nextBoolean()
        val wingsB = !wingsA || rng.nextBoolean()
        val prompt = "کدام خط واقعاً بلندتر است؟ (نشانه‌های پیکان ممکن است فریب‌دهنده باشند)"
        val optA = "خط بالا (${if (wingsA) "با پیکان" else "ساده"})"
        val optB = "خط پایین (${if (wingsB) "با پیکان" else "ساده"})"
        val correct = if (aLonger) 0 else 1
        val expl = "خط ${if (aLonger) "بالا" else "پایین"} واقعاً $delta واحد بلندتر بود. اثر مولر-لایر اغلب باعث می‌شود خط با پیکان‌های رو به بیرون کوتاه‌تر به نظر برسد."
        return ctx.question(
            ChoiceBody(prompt, null, emptyList(), listOf(optA, optB, "هر دو برابر"), emptyList(), correct, expl, "muller-lyer"),
            "len:$lenA:$lenB:wA=$wingsA:wB=$wingsB"
        )
    }
}

/** 22. Odd shape out — find the different figure in a set */
object OddShapeGame : BaseGame(
    "odd_shape", "شکل متفاوت", Category.VISUAL, "🔶",
    "شکلی که با بقیه فرق دارد را پیدا کن",
    "چند شکل نمایش داده می‌شود. یکی از آن‌ها از نظر رنگ، پرشدگی یا جهت با بقیه متفاوت است. همان را انتخاب کن.",
    3500, 300
) {
    override fun generate(ctx: GenContext): Question {
        val rng = ctx.rng
        val shapes = listOf("●", "■", "▲", "◆", "★", "✚")
        val colors = listOf(0, 1, 2, 3, 4)
        val baseShape = shapes[rng.nextInt(shapes.size)]
        val baseColor = colors[rng.nextInt(colors.size)]
        val count = min(6, 3 + ctx.level / 3)
        val items = mutableListOf<Glyph>()
        val oddIndex = rng.nextInt(count)
        val oddType = rng.nextInt(3) // 0 shape, 1 color, 2 both
        for (i in 0 until count) {
            val s = if (i == oddIndex && (oddType == 0 || oddType == 2)) shapes.filter { it != baseShape }.random(rng) else baseShape
            val c = if (i == oddIndex && (oddType == 1 || oddType == 2)) colors.filter { it != baseColor }.random(rng) else baseColor
            items.add(Glyph(text = s, colorIdx = c))
        }
        val expl = "شکل شماره ${oddIndex + 1} از نظر ${when (oddType) { 0 -> "شکل"; 1 -> "رنگ"; else -> "شکل و رنگ" }} با بقیه متفاوت بود."
        return ctx.question(
            PickBody("شکلی که با بقیه فرق دارد را انتخاب کن.", emptyList(), items, min(3, count), oddIndex, expl),
            "odd:$oddIndex:type=$oddType"
        )
    }
}

/** 23. Mental rotation 2D simplified */
object MentalRotation2DGame : BaseGame(
    "mental_rotation_2d", "چرخش ذهنی ۲بعدی", Category.VISUAL, "🔄",
    "کدام شکل چرخش‌یافته‌ی شکل اصلی است؟",
    "یک شکل مرجع و چند گزینه می‌بینی. گزینه‌ای را انتخاب کن که همان شکل پس از چرخش (نه آینه) باشد.",
    5000, 500
) {
    override fun generate(ctx: GenContext): Question {
        val rng = ctx.rng
        // Use simple 3x3 cell patterns
        val patterns = listOf(
            listOf(0, 1, 3), // L
            listOf(0, 1, 2, 4), // T-ish
            listOf(0, 1, 4, 7), // S-ish
            listOf(1, 3, 4, 5), // + center
            listOf(0, 2, 4, 6, 8) // X
        )
        val base = patterns[rng.nextInt(patterns.size)]
        val rot90 = base.map { r ->
            val x = r % 3; val y = r / 3
            val nx = 2 - y; val ny = x
            ny * 3 + nx
        }.sorted()
        val rot180 = base.map { r ->
            val x = r % 3; val y = r / 3
            val nx = 2 - x; val ny = 2 - y
            ny * 3 + nx
        }.sorted()
        val mirror = base.map { r ->
            val x = r % 3; val y = r / 3
            val nx = 2 - x
            y * 3 + nx
        }.sorted()
        val targetRot = if (ctx.level <= 4) rot90 else if (rng.nextBoolean()) rot90 else rot180
        val distractors = listOf(mirror, patterns.filter { it != base }.random(rng), rot180).distinct()
        val options = (listOf(targetRot) + distractors).shuffled(rng).take(4)
        val correctIdx = options.indexOf(targetRot).coerceAtLeast(0)
        val glyphs = options.map { cells -> Glyph(cells = cells, gridSize = 3) }
        val expl = "گزینه‌ی ${correctIdx + 1} چرخش واقعی شکل اصلی بود. گزینه‌ی آینه‌ای چرخش نیست."
        return ctx.question(
            PickBody("کدام شکل، چرخش‌یافته‌ی شکل مرجع است؟ (آینه پذیرفته نیست)", listOf(Glyph(cells = base, gridSize = 3)), glyphs, 2, correctIdx, expl, "rotation"),
            "rot2d:$correctIdx"
        )
    }
}

/** 24. Change detection — two grids, find what changed */
object ChangeDetectionGame : BaseGame(
    "change_detection", "تشخیص تغییر", Category.VISUAL, "🔍",
    "چه چیزی بین دو تصویر تغییر کرده؟",
    "دو شبکه پشت سر هم نشان داده می‌شوند. بگو کدام خانه تغییر کرده یا اینکه تغییری نبوده.",
    5500, 400
) {
    override fun generate(ctx: GenContext): Question {
        val rng = ctx.rng
        val size = if (ctx.level <= 4) 3 else 4
        val nCells = size * size
        val count = min(nCells - 1, 2 + ctx.level / 2)
        val cells = (0 until nCells).shuffled(rng).take(count).toSet()
        val changed = rng.nextDouble() < 0.7 || ctx.level > 3
        val changeIdx = if (changed) {
            val candidates = (0 until nCells).filter { it !in cells }
            if (candidates.isEmpty()) cells.random(rng) else candidates.random(rng)
        } else -1
        val prompt = if (changed) "کدام خانه تغییر کرده است؟" else "آیا تغییری رخ داده؟"
        val options = if (changed) {
            val opts = mutableListOf("خانه ${(changeIdx % size) + 1},${(changeIdx / size) + 1}")
            while (opts.size < 4) {
                val fake = rng.nextInt(nCells)
                val label = "خانه ${(fake % size) + 1},${(fake / size) + 1}"
                if (label !in opts) opts.add(label)
            }
            opts.shuffled(rng)
        } else {
            listOf("هیچ تغییری نبود", "یک خانه اضافه شد", "یک خانه کم شد", "رنگ عوض شد")
        }
        val correct = if (changed) {
            val label = "خانه ${(changeIdx % size) + 1},${(changeIdx / size) + 1}"
            options.indexOf(label).coerceAtLeast(0)
        } else 0
        val expl = if (changed) "خانه ${(changeIdx % size) + 1},${(changeIdx / size) + 1} تغییر کرده بود." else "هیچ تغییری رخ نداده بود."
        return ctx.question(
            ChoiceBody(prompt, null, listOf(Glyph(cells = cells.toList(), gridSize = size)), options, emptyList(), correct, expl),
            "change:$changed:$changeIdx"
        )
    }
}

/** 25. Symmetry detection */
object SymmetryGame : BaseGame(
    "symmetry", "تشخیص تقارن", Category.VISUAL, "🪞",
    "آیا شکل متقارن است؟",
    "یک شکل شبکه‌ای می‌بینی. بگو آیا نسبت به محور عمودی متقارن است یا نه.",
    4000, 300
) {
    override fun generate(ctx: GenContext): Question {
        val rng = ctx.rng
        val size = 3
        val wantSym = rng.nextBoolean()
        val cells = mutableSetOf<Int>()
        if (wantSym) {
            for (y in 0 until size) {
                for (x in 0 until (size + 1) / 2) {
                    if (rng.nextBoolean()) {
                        cells.add(y * size + x)
                        cells.add(y * size + (size - 1 - x))
                    }
                }
            }
        } else {
            val n = 3 + rng.nextInt(4)
            cells.addAll((0 until size * size).shuffled(rng).take(n))
            // Ensure not symmetric
            val mirrored = cells.map { r ->
                val x = r % size; val y = r / size
                y * size + (size - 1 - x)
            }.toSet()
            if (mirrored == cells) cells.remove(cells.first())
        }
        val options = listOf("متقارن است", "متقارن نیست")
        val correct = if (wantSym) 0 else 1
        val expl = if (wantSym) "شکل نسبت به محور عمودی متقارن بود." else "شکل متقارن نبود."
        return ctx.question(
            ChoiceBody("آیا این شکل نسبت به محور عمودی متقارن است؟", null, listOf(Glyph(cells = cells.toList(), gridSize = size)), options, emptyList(), correct, expl),
            "sym:$wantSym"
        )
    }
}
