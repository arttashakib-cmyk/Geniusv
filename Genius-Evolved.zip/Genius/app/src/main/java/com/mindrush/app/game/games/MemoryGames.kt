package com.mindrush.app.game.games

import com.mindrush.app.game.*
import kotlin.math.max

private fun digitsQuestion(ctx: GenContext, len: Int, reverse: Boolean): Question {
    val rng = ctx.rng
    val digits = List(len) { rng.nextInt(0, 10) }
    val show = max(450L, 900L - 50L * (ctx.level - 1))
    val shown = digits.joinToString(" ")
    val expected = (if (reverse) digits.reversed() else digits).joinToString("")
    return ctx.question(
        RecallBody(
            if (reverse) "رقم‌ها را ببین و به خاطر بسپار؛ بعد آن‌ها را از آخر به اول وارد کن."
            else "رقم‌ها را ببین و به خاطر بسپار؛ بعد به همان ترتیب وارد کن.",
            digits.map { it.toString() }, show,
            if (reverse) RecallMode.REVERSE else RecallMode.FORWARD, expected,
            "دنباله‌ی نمایش‌داده‌شده «$shown» بود" + if (reverse) " و ترتیب درست وارد کردن «${expected.toList().joinToString(" ")}» است." else "."
        ),
        "mem:${digits.joinToString("")}:rev=$reverse"
    )
}

/** 9. Number memory */
object NumberMemoryGame : BaseGame(
    "number_memory", "حافظه‌ی عدد", Category.MEMORY, "🔟",
    "دنباله‌ی رقم‌ها را حفظ کن و تکرار کن",
    "رقم‌ها یکی‌یکی نشان داده می‌شوند. بعد از پایان نمایش، همه را به همان ترتیب وارد کن. با بالا رفتن سطح، دنباله بلندتر و نمایش سریع‌تر می‌شود.",
    5000, 1500
) {
    override fun generate(ctx: GenContext): Question = digitsQuestion(ctx, minOf(12, 2 + ctx.level), false)
}

/** 10. Reverse memory */
object ReverseMemoryGame : BaseGame(
    "reverse_memory", "حافظه‌ی معکوس", Category.MEMORY, "🔁",
    "رقم‌ها را از آخر به اول بازگو کن",
    "رقم‌ها یکی‌یکی نشان داده می‌شوند. بعد از پایان نمایش، آن‌ها را از آخر به اول وارد کن؛ هم ترتیب و هم طول دنباله بررسی می‌شود.",
    6000, 1500
) {
    override fun generate(ctx: GenContext): Question =
        digitsQuestion(ctx, 3 + (ctx.level - 1) / 2 + if (ctx.level >= 6) 1 else 0, true)
}

/** 11. Grid memory */
object GridMemoryGame : BaseGame(
    "grid_memory", "حافظه‌ی شبکه", Category.MEMORY, "🔲",
    "جای خانه‌های روشن را به خاطر بسپار",
    "چند خانه‌ی شبکه برای مدت کوتاهی روشن می‌شوند. بعد از خاموش‌شدن، همان خانه‌ها را انتخاب کن و «تأیید» بزن؛ باید دقیقاً همان مجموعه باشد.",
    6000, 1200
) {
    override fun generate(ctx: GenContext): Question {
        val l = ctx.level
        val size = when { l <= 3 -> 3; l <= 7 -> 4; else -> 5 }
        val count = minOf(size * size - 1, 3 + (l - 1) / 2)
        val cells = (0 until size * size).shuffled(ctx.rng).take(count).toSet()
        val show = max(900L, 2200L - 100L * l)
        return ctx.question(
            GridBody(
                "جای $count خانه‌ی روشن را حفظ کن.", size, cells, show,
                "خانه‌های درست: " + cells.sorted().joinToString("، ") { "ردیف ${it / size + 1} ستون ${it % size + 1}" }
            ),
            "grid:$size:${cells.sorted().joinToString(",")}"
        )
    }
}

/** 12. Mental update: rolling value or rolling window of recent numbers. */
object MentalUpdateGame : BaseGame(
    "mental_update", "به‌روزرسانی ذهنی", Category.MEMORY, "♻️",
    "مقدار را در ذهن به‌روز نگه دار",
    "گاهی یک عدد شروع و چند تغییر (جمع، تفریق و در سطح‌های بالا ضرب در ۲) می‌بینی و باید مقدار نهایی را وارد کنی؛ گاهی چند عدد پشت سر هم می‌آیند و باید مجموع چند عدد آخر را بنویسی. عددها فقط یک‌بار نمایش داده می‌شوند.",
    9000, 1800
) {
    override fun generate(ctx: GenContext): Question {
        val rng = ctx.rng
        val l = ctx.level
        val show = max(700L, 1500L - 60L * l)
        return if (rng.nextBoolean()) rolling(ctx, rng, l, show) else window(ctx, rng, l, show)
    }

    private fun rolling(ctx: GenContext, rng: kotlin.random.Random, l: Int, show: Long): Question {
        var v = rng.nextLong(5, 31)
        val start = v
        val steps = ArrayList<String>()
        steps.add("شروع: $v")
        val opCount = 3 + l / 2
        repeat(opCount) {
            val roll = rng.nextInt(10)
            if (l >= 6 && roll < 2 && (v >= -50 && v <= 50)) { v *= 2; steps.add("×2") }
            else if (roll % 2 == 0) { val k = rng.nextLong(1, 10); v += k; steps.add("+$k") }
            else { val k = rng.nextLong(1, 10); v -= k; steps.add("−$k") }
        }
        return ctx.question(
            RecallBody(
                "مقدار را در ذهن به‌روز کن و در پایان عدد نهایی را وارد کن.", steps, show, RecallMode.NUMERIC, v.toString(),
                "از $start شروع شد و با اعمال مرحله‌ها به $v رسید."
            ),
            "upd:roll:${steps.joinToString("|")}"
        )
    }

    private fun window(ctx: GenContext, rng: kotlin.random.Random, l: Int, show: Long): Question {
        val n = 4 + l / 2
        val w = if (l >= 6) 3 else 2
        val nums = List(n) { rng.nextLong(1, 10L + l * 2) }
        val sum = nums.takeLast(w).sum()
        return ctx.question(
            RecallBody(
                "فقط مجموع $w عدد آخر را نگه دار و در پایان وارد کن.", nums.map { it.toString() }, show, RecallMode.NUMERIC, sum.toString(),
                "عددها ${nums.joinToString("، ")} بودند؛ مجموع $w عدد آخر ${nums.takeLast(w).joinToString(" + ")} = $sum است."
            ),
            "upd:win:${nums.joinToString(",")}:w=$w"
        )
    }
}
