package com.mindrush.app.core

import java.util.Locale

/** Persian digit presentation and digit normalization. Internal math never depends on locale. */
object Fa {
    private val decimalRegex = Regex("(?<=[0-9])\\.(?=[0-9])")

    fun toPersianDigits(s: String): String {
        val sb = StringBuilder(s.length)
        for (c in s) {
            if (c in '0'..'9') sb.append('\u06F0' + (c - '0')) else sb.append(c)
        }
        return sb.toString()
    }

    /** Converts Persian/Arabic-Indic digits and separators to ASCII. */
    fun normalizeDigits(s: String): String {
        val sb = StringBuilder(s.length)
        for (c in s) {
            when (c) {
                in '\u06F0'..'\u06F9' -> sb.append('0' + (c - '\u06F0'))
                in '\u0660'..'\u0669' -> sb.append('0' + (c - '\u0660'))
                '\u066B' -> sb.append('.')
                '\u066C' -> Unit
                '\u2212' -> sb.append('-')
                else -> sb.append(c)
            }
        }
        return sb.toString()
    }

    fun format(s: String, persian: Boolean): String =
        if (persian) toPersianDigits(decimalRegex.replace(s, "\u066B")) else s

    fun seconds(ms: Long?): String =
        if (ms == null) "—" else String.format(Locale.US, "%.1f", ms / 1000.0)

    fun percent(ratio: Double): String = String.format(Locale.US, "%d%%", Math.round(ratio * 100))

    fun clock(ms: Long): String {
        val total = (ms.coerceAtLeast(0) / 1000)
        return String.format(Locale.US, "%d:%02d", total / 60, total % 60)
    }
}
