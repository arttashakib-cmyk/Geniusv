package com.mindrush.app.game

import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Transparent, deterministic scoring. Formula version 1:
 *   P = round(100 x D x T x B)
 *   D = 0.8 + 0.2 x (L - 1) / 9
 *   T = 0.7 + 0.3 x min(1, targetTime / actualTime)
 *   B = specialised multiplier (memory length / grid size); 1.0 for ordinary questions.
 * This is a game-design formula, not a scientific measure.
 */
object ScoringEngine {
    const val VERSION = 1

    fun difficultyFactor(level: Int): Double = 0.8 + 0.2 * (level.coerceIn(1, 10) - 1) / 9.0

    fun timeFactor(targetMs: Long, actualMs: Long?): Double {
        if (actualMs == null) return 0.85
        val actual = max(actualMs, 1L)
        return 0.7 + 0.3 * min(1.0, targetMs.toDouble() / actual.toDouble())
    }

    fun bonus(body: QBody): Double = when (body) {
        is RecallBody -> if (body.mode == RecallMode.NUMERIC) 1.0 else 1.0 + 0.05 * max(0, body.steps.size - 3)
        is GridBody -> 1.0 + 0.05 * max(0, body.cells.size - 3)
        else -> 1.0
    }

    /** Wrong or skipped answers never earn points. */
    fun questionPoints(body: QBody, level: Int, targetMs: Long, responseMs: Long?, verdict: Verdict): Int {
        if (!verdict.correct || verdict.skipped) return 0
        val t = when (body) {
            is ReactionBody -> if (body.isTarget) timeFactor(targetMs, responseMs) else 0.85
            else -> timeFactor(targetMs, responseMs)
        }
        return (100.0 * difficultyFactor(level) * t * bonus(body)).roundToInt()
    }
}

/**
 * Adaptive difficulty on a bounded 1..10 scale.
 * - Needs at least [minSample] answers since the last change.
 * - Promotion: accuracy >= 85% and median correct response time <= target.
 * - Demotion: accuracy <= 50%.
 * - After any change the window is cleared, preventing oscillation.
 * - In fixed mode the level never changes.
 */
class AdaptiveDifficultyEngine(
    startLevel: Int,
    private val fixed: Boolean = false,
    private val minSample: Int = 5,
    private val windowSize: Int = 10
) {
    data class Sample(val correct: Boolean, val responseMs: Long?, val targetMs: Long)

    var level: Int = startLevel.coerceIn(1, 10)
        private set

    private val window = ArrayDeque<Sample>()

    fun record(sample: Sample): Int {
        if (fixed) return level
        window.addLast(sample)
        while (window.size > windowSize) window.removeFirst()
        if (window.size < minSample) return level

        val accuracy = window.count { it.correct }.toDouble() / window.size
        val correctTimes = window.filter { it.correct && it.responseMs != null }.map { it.responseMs!! }.sorted()
        val target = window.last().targetMs
        val fastEnough = correctTimes.isNotEmpty() && median(correctTimes) <= target

        var changed = false
        if (accuracy >= 0.85 && fastEnough && level < 10) {
            level++; changed = true
        } else if (accuracy <= 0.5 && level > 1) {
            level--; changed = true
        }
        if (changed) window.clear()
        return level
    }

    private fun median(sorted: List<Long>): Long {
        val n = sorted.size
        return if (n % 2 == 1) sorted[n / 2] else (sorted[n / 2 - 1] + sorted[n / 2]) / 2
    }
}
