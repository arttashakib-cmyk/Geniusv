package com.mindrush.app.feature

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mindrush.app.FinishedSession
import com.mindrush.app.core.Fa
import com.mindrush.app.data.GameAggregate
import com.mindrush.app.domain.Achievements
import com.mindrush.app.game.Category
import com.mindrush.app.game.FinishReason
import com.mindrush.app.game.GameMode
import com.mindrush.app.game.GameRegistry

private fun ms(v: Long?): String = if (v == null) "—" else Fa.seconds(v) + " ثانیه"

@Composable
fun ResultScreen(finished: FinishedSession?, onRetry: (String, GameMode, Int) -> Unit, onHome: () -> Unit) {
    if (finished == null) {
        Column(Modifier.fillMaxSize().background(GenColors.bg).padding(24.dp), verticalArrangement = Arrangement.Center) {
            FText("نتیجه‌ای برای نمایش نیست.", textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(12.dp))
            PrimaryButton("بازگشت به خانه") { onHome() }
        }
        return
    }
    val r = finished.result
    val o = finished.outcome
    val game = GameRegistry.byId(r.config.gameId)
    val reasonText = when (r.reason) {
        FinishReason.TIME_UP -> "زمان تمام شد"
        FinishReason.QUESTIONS_DONE -> "همه‌ی سؤال‌ها پاسخ داده شد"
        FinishReason.LIVES_OUT -> "جان‌هایت تمام شد"
        FinishReason.USER_EXIT -> "خروج از بازی"
    }
    Column(
        Modifier.fillMaxSize().background(GenColors.bg).verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        FText("${game?.emoji ?: ""} ${game?.nameFa ?: ""} • ${r.config.mode.fa}", fontSize = 16.sp, color = GenColors.muted)
        FText("$reasonText", fontSize = 14.sp, color = GenColors.muted)
        GCard {
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                FText("امتیاز", color = GenColors.muted)
                FText(r.score.toString(), fontSize = 52.sp, fontWeight = FontWeight.Bold)
                if (o != null && o.isNewBest) FText("🏆 رکورد جدید!", color = GenColors.accent, fontWeight = FontWeight.Bold)
                else if (o?.previousBest != null) FText("بهترین امتیاز قبلی: ${o.previousBest}", color = GenColors.muted, fontSize = 13.sp)
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatTile("درست", r.correct.toString(), Modifier.weight(1f))
            StatTile("نادرست", r.wrong.toString(), Modifier.weight(1f))
            StatTile("ردشده", r.skipped.toString(), Modifier.weight(1f))
            StatTile("بی‌پاسخ", r.unanswered.toString(), Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            val answered = r.correct + r.wrong
            StatTile("دقت", if (answered == 0) "—" else Fa.percent(r.accuracy), Modifier.weight(1f))
            StatTile("میانگین پاسخ", ms(r.meanMs), Modifier.weight(1f))
            StatTile("میانه‌ی پاسخ", ms(r.medianMs), Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatTile("بیشترین پشت‌سرهم", r.bestStreak.toString(), Modifier.weight(1f))
            StatTile("مدت بازی", Fa.clock(r.durationMs), Modifier.weight(1f))
            StatTile("سطح", if (r.startLevel == r.endLevel) "${r.endLevel}" else "${r.startLevel} تا ${r.endLevel}", Modifier.weight(1f))
        }
        if (r.components.isNotEmpty()) {
            SectionTitle("عملکرد به تفکیک حوزه")
            GCard {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    for ((k, v) in r.components) {
                        FText("${GameRegistry.componentFa(k)}: ${v.correct} از ${v.total} درست", fontSize = 15.sp)
                    }
                }
            }
        }
        if (o != null && o.newAchievements.isNotEmpty()) {
            SectionTitle("دستاورد جدید 🎉")
            for (id in o.newAchievements) {
                val a = Achievements.byId(id)
                if (a != null) GCard { Column { FText(a.nameFa, fontWeight = FontWeight.Bold); FText(a.descFa, fontSize = 13.sp, color = GenColors.muted) } }
            }
        }
        if (o == null) FText("ذخیره‌ی این دور با مشکل روبه‌رو شد؛ نتیجه فقط در همین صفحه نمایش داده می‌شود.", color = GenColors.bad, fontSize = 13.sp)
        FText("سطح فقط یک شاخص بازی است، نه نمره‌ی هوش و نه ارزیابی پزشکی.", fontSize = 12.sp, color = GenColors.muted)
        PrimaryButton("بازی دوباره") { onRetry(r.config.gameId, r.config.mode, r.config.fixedLevel ?: 0) }
        SecondaryButton("بازگشت به خانه") { onHome() }
        Spacer(Modifier.height(16.dp))
    }
}

@Composable
fun StatsScreen(vm: MainViewModel) {
    val aggs by vm.aggregates.collectAsState()
    val counts by vm.statusCounts.collectAsState()
    val streak by vm.dayStreak.collectAsState()
    val profiles by vm.profiles.collectAsState()
    val detail by vm.detail.collectAsState()

    Column(
        Modifier.fillMaxSize().background(GenColors.bg).verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        FText("آمار من", fontSize = 26.sp, fontWeight = FontWeight.Bold)
        val total = aggs.sumOf { it.sessions }
        if (total == 0) {
            GCard { FText("هنوز داده‌ی کافی نیست. چند دور بازی کن تا آمار واقعی تو اینجا نمایش داده شود.", color = GenColors.muted) }
        } else {
            val correct = aggs.sumOf { it.correct }
            val wrong = aggs.sumOf { it.wrong }
            val skipped = aggs.sumOf { it.skipped }
            val acc = if (correct + wrong == 0) null else correct.toDouble() / (correct + wrong)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatTile("دور کامل", total.toString(), Modifier.weight(1f))
                StatTile("دقت کلی", if (acc == null) "—" else Fa.percent(acc), Modifier.weight(1f))
                StatTile("روز پیاپی", streak.toString(), Modifier.weight(1f))
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatTile("درست", correct.toString(), Modifier.weight(1f))
                StatTile("نادرست", wrong.toString(), Modifier.weight(1f))
                StatTile("ردشده", skipped.toString(), Modifier.weight(1f))
            }
            val ab = counts.firstOrNull { it.status == "ABANDONED" }?.n ?: 0
            val inter = counts.firstOrNull { it.status == "INTERRUPTED" }?.n ?: 0
            FText("دورهای نیمه‌تمام: $ab • دورهای قطع‌شده: $inter", fontSize = 13.sp, color = GenColors.muted)

            SectionTitle("به تفکیک دسته")
            for (cat in Category.values()) {
                val ids = GameRegistry.byCategory(cat).map { it.id }.toSet()
                val list = aggs.filter { it.gameId in ids }
                val c = list.sumOf { it.correct }; val w = list.sumOf { it.wrong }
                GCard {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        FText("${cat.emoji} ${cat.fa}")
                        FText(if (c + w < 10) "تمرین بیشتری لازم است" else "دقت ${Fa.percent(c.toDouble() / (c + w))}", color = GenColors.muted, fontSize = 14.sp)
                    }
                }
            }
            SectionTitle("به تفکیک بازی (برای جزئیات بزن)")
            for (a in aggs.sortedByDescending { it.sessions }) GameRow(a, profiles.firstOrNull { it.gameId == a.gameId }?.level) { vm.loadDetail(a.gameId) }
        }
        Spacer(Modifier.height(16.dp))
    }

    val d = detail
    if (d != null) {
        val g = GameRegistry.byId(d.gameId)
        AlertDialog(
            onDismissRequest = { vm.closeDetail() },
            title = { FText(g?.nameFa ?: d.gameId, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (d.sampleSize < 5) FText("برای محاسبه‌ی زمان پاسخ، داده‌ی کافی نیست؛ بیشتر تمرین کن.", color = GenColors.muted)
                    else {
                        FText("میانگین زمان پاسخ: ${ms(d.meanMs)}")
                        FText("میانه‌ی زمان پاسخ: ${ms(d.medianMs)}")
                        FText("بر پایه‌ی ${d.sampleSize} پاسخ اخیر", fontSize = 12.sp, color = GenColors.muted)
                    }
                    for (c in d.components) FText("${GameRegistry.componentFa(c.component)}: ${c.correct} از ${c.total} درست", fontSize = 14.sp)
                }
            },
            confirmButton = { TextButton(onClick = { vm.closeDetail() }) { FText("بستن") } }
        )
    }
}

@Composable
private fun GameRow(a: GameAggregate, level: Int?, onClick: () -> Unit) {
    val g = GameRegistry.byId(a.gameId)
    GCard(onClick = onClick) {
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                FText("${g?.emoji ?: ""} ${g?.nameFa ?: a.gameId}", fontWeight = FontWeight.Bold)
                FText("سطح ${level ?: 1}", color = GenColors.accent, fontSize = 13.sp)
            }
            val answered = a.correct + a.wrong
            FText(
                "${a.sessions} دور • " + (if (answered == 0) "بدون پاسخ" else "دقت ${Fa.percent(a.correct.toDouble() / answered)}") + " • بیشترین پشت‌سرهم ${a.bestStreak}",
                fontSize = 13.sp, color = GenColors.muted
            )
        }
    }
}

@Composable
fun AchievementsScreen(vm: MainViewModel) {
    val unlocked by vm.achievements.collectAsState()
    val ids = unlocked.map { it.id }.toSet()
    Column(
        Modifier.fillMaxSize().background(GenColors.bg).verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        FText("دستاوردها", fontSize = 26.sp, fontWeight = FontWeight.Bold)
        FText("${ids.size} از ${Achievements.all.size} باز شده", color = GenColors.muted)
        for (a in Achievements.all) {
            val on = a.id in ids
            GCard {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    FText(if (on) "🏅" else "🔒", fontSize = 28.sp)
                    Column {
                        FText(a.nameFa, fontWeight = FontWeight.Bold, color = if (on) GenColors.accent else GenColors.muted)
                        FText(a.descFa, fontSize = 13.sp, color = GenColors.muted)
                    }
                }
            }
        }
        Spacer(Modifier.height(16.dp))
    }
}
