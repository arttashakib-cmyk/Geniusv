package com.mindrush.app

import com.mindrush.app.core.Clock
import com.mindrush.app.game.*

class FakeClock(var t: Long = 1_000) : Clock {
    override fun nowMs(): Long = t
    fun advance(ms: Long) { t += ms }
}

fun config(
    gameId: String, mode: GameMode, duration: Int = 60, questions: Int = 20, lives: Int = 3,
    fixed: Int? = null, startLevel: Int = 1, seed: Long = 7
) = SessionConfig("test-$gameId-$seed", gameId, mode, duration, questions, lives, fixed, startLevel, seed)

fun newEngine(
    game: GameDefinition, cfg: SessionConfig, clock: FakeClock
) = GameSessionEngine(cfg, game, clock, AdaptiveDifficultyEngine(cfg.fixedLevel ?: cfg.startLevel, cfg.fixedLevel != null), { clock.t })

fun correctIndexOf(q: Question): Int = when (val b = q.body) {
    is ChoiceBody -> b.correctIndex
    is PickBody -> b.correctIndex
    else -> error("not an index question")
}

fun wrongIndexOf(q: Question): Int = when (val b = q.body) {
    is ChoiceBody -> (b.correctIndex + 1) % b.options.size
    is PickBody -> (b.correctIndex + 1) % b.items.size
    else -> error("not an index question")
}
