package com.mindrush.app

import com.mindrush.app.game.*
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ScoringTest {
    private val body = ChoiceBody("q", null, emptyList(), listOf("1", "2"), emptyList(), 0, "e")

    @Test fun difficultyFactorBounds() {
        assertEquals(0.8, ScoringEngine.difficultyFactor(1), 1e-9)
        assertEquals(1.0, ScoringEngine.difficultyFactor(10), 1e-9)
    }

    @Test fun fastCorrectAnswerAtLevel1() {
        assertEquals(80, ScoringEngine.questionPoints(body, 1, 3000, 1000, Verdict(true)))
    }

    @Test fun slowCorrectAnswerAtLevel10() {
        // T = 0.7 + 0.3 * 0.5 = 0.85 -> 100 * 1.0 * 0.85 = 85
        assertEquals(85, ScoringEngine.questionPoints(body, 10, 3000, 6000, Verdict(true)))
    }

    @Test fun wrongAndSkippedEarnNothing() {
        assertEquals(0, ScoringEngine.questionPoints(body, 5, 3000, 1000, Verdict(false)))
        assertEquals(0, ScoringEngine.questionPoints(body, 5, 3000, null, Verdict(false, skipped = true)))
    }

    @Test fun longerMemorySequencesScoreMore() {
        val short = RecallBody("p", List(3) { "1" }, 500, RecallMode.FORWARD, "111", "e")
        val long = RecallBody("p", List(8) { "1" }, 500, RecallMode.FORWARD, "11111111", "e")
        val a = ScoringEngine.questionPoints(short, 3, 3000, 2000, Verdict(true))
        val b = ScoringEngine.questionPoints(long, 3, 3000, 2000, Verdict(true))
        assertTrue(b > a)
    }

    @Test fun noGoCorrectReactionHasFlatScore() {
        val r = ReactionBody("p", "r", false, Glyph("■"), 800, 900, "e")
        assertEquals(Math.round(100 * ScoringEngine.difficultyFactor(5) * 0.85).toInt(), ScoringEngine.questionPoints(r, 5, 500, null, Verdict(true)))
    }
}

class AdaptiveDifficultyTest {
    private fun good() = AdaptiveDifficultyEngine.Sample(true, 1000, 3000)
    private fun bad() = AdaptiveDifficultyEngine.Sample(false, 9000, 3000)

    @Test fun noChangeWithInsufficientData() {
        val e = AdaptiveDifficultyEngine(3)
        repeat(4) { e.record(good()) }
        assertEquals(3, e.level)
    }

    @Test fun promotesAfterConsistentStrongPerformance() {
        val e = AdaptiveDifficultyEngine(3)
        repeat(5) { e.record(good()) }
        assertEquals(4, e.level)
    }

    @Test fun slowButAccurateDoesNotPromote() {
        val e = AdaptiveDifficultyEngine(3)
        repeat(8) { e.record(AdaptiveDifficultyEngine.Sample(true, 9000, 3000)) }
        assertEquals(3, e.level)
    }

    @Test fun demotesAfterSustainedStruggle() {
        val e = AdaptiveDifficultyEngine(5)
        repeat(5) { e.record(bad()) }
        assertEquals(4, e.level)
    }

    @Test fun neverLeavesBounds() {
        val top = AdaptiveDifficultyEngine(10)
        repeat(30) { top.record(good()) }
        assertEquals(10, top.level)
        val bottom = AdaptiveDifficultyEngine(1)
        repeat(30) { bottom.record(bad()) }
        assertEquals(1, bottom.level)
    }

    @Test fun fixedModeNeverChanges() {
        val e = AdaptiveDifficultyEngine(4, fixed = true)
        repeat(30) { e.record(good()) }
        assertEquals(4, e.level)
    }

    @Test fun windowIsClearedAfterChangeToPreventOscillation() {
        val e = AdaptiveDifficultyEngine(5)
        repeat(5) { e.record(good()) }
        assertEquals(6, e.level)
        repeat(4) { e.record(bad()) }
        assertEquals(6, e.level) // fewer than 5 fresh samples: no immediate demotion
    }

    @Test fun singleResponseNeverChangesLevel() {
        val e = AdaptiveDifficultyEngine(5)
        e.record(bad())
        assertEquals(5, e.level)
    }
}
