package com.mindrush.app

import com.mindrush.app.game.*
import com.mindrush.app.game.games.*
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

private fun q(body: QBody) = Question("q1", "g", 1, null, null, "", body)

class AnswerEvaluatorTest {
    @Test fun forwardRecallRequiresExactOrder() {
        val b = RecallBody("p", listOf("1", "2", "3"), 500, RecallMode.FORWARD, "123", "e")
        assertTrue(AnswerEvaluator.evaluate(q(b), Answer.Typed("123")).correct)
        assertTrue(AnswerEvaluator.evaluate(q(b), Answer.Typed("۱۲۳")).correct)
        assertFalse(AnswerEvaluator.evaluate(q(b), Answer.Typed("132")).correct)
        assertFalse(AnswerEvaluator.evaluate(q(b), Answer.Typed("12")).correct)
        assertFalse(AnswerEvaluator.evaluate(q(b), Answer.Typed("1234")).correct)
    }

    @Test fun reverseRecallValidatesOrderAndLength() {
        val digits = listOf(4, 7, 1)
        val b = RecallBody("p", digits.map { it.toString() }, 500, RecallMode.REVERSE, digits.reversed().joinToString(""), "e")
        assertTrue(AnswerEvaluator.evaluate(q(b), Answer.Typed("174")).correct)
        assertFalse(AnswerEvaluator.evaluate(q(b), Answer.Typed("471")).correct)
        assertFalse(AnswerEvaluator.evaluate(q(b), Answer.Typed("17")).correct)
    }

    @Test fun numericRecallAcceptsNegativeNumbers() {
        val b = RecallBody("p", listOf("5"), 500, RecallMode.NUMERIC, "-7", "e")
        assertTrue(AnswerEvaluator.evaluate(q(b), Answer.Typed("-7")).correct)
        assertTrue(AnswerEvaluator.evaluate(q(b), Answer.Typed("−۷")).correct)
        assertFalse(AnswerEvaluator.evaluate(q(b), Answer.Typed("7")).correct)
    }

    @Test fun gridRecallNeedsTheExactSet() {
        val b = GridBody("p", 3, setOf(1, 4, 8), 1000, "e")
        assertTrue(AnswerEvaluator.evaluate(q(b), Answer.Cells(setOf(8, 4, 1))).correct)
        assertFalse(AnswerEvaluator.evaluate(q(b), Answer.Cells(setOf(1, 4))).correct)
        assertFalse(AnswerEvaluator.evaluate(q(b), Answer.Cells(setOf(1, 4, 8, 2))).correct)
    }

    @Test fun reactionRules() {
        val go = ReactionBody("p", "r", true, Glyph("●"), 800, 900, "e")
        val noGo = ReactionBody("p", "r", false, Glyph("■"), 800, 900, "e")
        assertTrue(AnswerEvaluator.evaluate(q(go), Answer.Reaction(true)).correct)
        assertFalse(AnswerEvaluator.evaluate(q(go), Answer.Reaction(false)).correct)
        assertTrue(AnswerEvaluator.evaluate(q(noGo), Answer.Reaction(false)).correct)
        assertFalse(AnswerEvaluator.evaluate(q(noGo), Answer.Reaction(true)).correct)
        assertFalse(AnswerEvaluator.evaluate(q(go), Answer.Reaction(true, premature = true)).correct)
    }

    @Test fun skipIsNotAWrongAnswer() {
        val b = ChoiceBody("p", null, emptyList(), listOf("1", "2"), emptyList(), 0, "e")
        val v = AnswerEvaluator.evaluate(q(b), Answer.Skip)
        assertTrue(v.skipped); assertFalse(v.correct)
    }

    @Test fun analyticsSeparateSkippedFromWrongAndComputeMedian() {
        fun rec(i: Int, c: Boolean, s: Boolean, rt: Long?) =
            AnswerRecord(i, "q$i", "g", null, null, 1, c, s, rt, 0, 0, "")
        val sum = SessionAnalytics.summarize(listOf(rec(0, true, false, 1000), rec(1, true, false, 3000), rec(2, false, false, 2000), rec(3, false, true, null), rec(4, true, false, 5000)))
        assertEquals(3, sum.correct); assertEquals(1, sum.wrong); assertEquals(1, sum.skipped)
        assertEquals(0.75, sum.accuracy, 1e-9)
        assertEquals(2500L, sum.medianMs); assertEquals(riskMean(), sum.meanMs)
        assertEquals(2, sum.bestStreak)
    }

    private fun riskMean(): Long = (1000L + 3000 + 2000 + 5000) / 4
}

class SessionEngineTest {
    private fun speed(clock: FakeClock, duration: Int = 30, fixed: Int? = 1) =
        newEngine(AdditionGame, config("addition", GameMode.SPEED, duration = duration, fixed = fixed), clock)

    @Test fun speedModeEndsWhenTimeIsUpExactlyOnce() {
        val clock = FakeClock()
        val e = speed(clock)
        e.start()
        assertEquals(Phase.ACTIVE, e.state().phase)
        clock.advance(29_000); e.tick()
        assertEquals(Phase.ACTIVE, e.state().phase)
        clock.advance(2_000); e.tick()
        assertEquals(Phase.FINISHED, e.state().phase)
        val r1 = e.result()
        e.finish(FinishReason.USER_EXIT); e.tick()
        assertEquals(FinishReason.TIME_UP, e.result().reason)
        assertEquals(r1.durationMs, e.result().durationMs)
        assertEquals(1, e.result().unanswered)
    }

    @Test fun duplicateSubmissionIsIgnored() {
        val clock = FakeClock()
        val e = speed(clock)
        e.start()
        val first = e.state().question!!
        clock.advance(500)
        assertTrue(e.submit(first.id, Answer.Index(correctIndexOf(first))))
        assertFalse(e.submit(first.id, Answer.Index(correctIndexOf(first))))
        e.finish(FinishReason.USER_EXIT)
        assertEquals(1, e.result().records.size)
        assertEquals(1, e.result().correct)
    }

    @Test fun wrongAnswersEarnNothingAndBreakStreak() {
        val clock = FakeClock()
        val e = speed(clock)
        e.start()
        var q = e.state().question!!
        e.submit(q.id, Answer.Index(correctIndexOf(q)))
        q = e.state().question!!
        e.submit(q.id, Answer.Index(wrongIndexOf(q)))
        val s = e.state()
        assertEquals(1, s.correct); assertEquals(1, s.wrong); assertEquals(0, s.streak); assertEquals(1, s.bestStreak)
        assertEquals(0, s.feedback!!.points)
    }

    @Test fun survivalEndsWhenLivesRunOut() {
        val clock = FakeClock()
        val e = newEngine(AdditionGame, config("addition", GameMode.SURVIVAL, duration = 180, lives = 3, fixed = 1), clock)
        e.start()
        repeat(3) {
            val q = e.state().question!!
            assertEquals(Phase.ACTIVE, e.state().phase)
            e.submit(q.id, Answer.Index(wrongIndexOf(q)))
        }
        assertEquals(Phase.FINISHED, e.state().phase)
        assertEquals(FinishReason.LIVES_OUT, e.result().reason)
        assertEquals(0, e.state().lives)
    }

    @Test fun survivalSkipCostsALife() {
        val clock = FakeClock()
        val e = newEngine(AdditionGame, config("addition", GameMode.SURVIVAL, lives = 2, fixed = 1), clock)
        e.start()
        e.skip(e.state().question!!.id)
        assertEquals(1, e.state().lives)
    }

    @Test fun accuracyModeEndsAfterConfiguredQuestionsAndWaitsAfterMistakes() {
        val clock = FakeClock()
        val e = newEngine(AdditionGame, config("addition", GameMode.ACCURACY, questions = 3, fixed = 1), clock)
        e.start()
        var q = e.state().question!!
        e.submit(q.id, Answer.Index(wrongIndexOf(q)))
        assertTrue(e.state().awaitingAdvance)
        assertFalse(e.submit(q.id, Answer.Index(correctIndexOf(q)))) // locked while reading the explanation
        e.advance()
        repeat(2) {
            q = e.state().question!!
            e.submit(q.id, Answer.Index(correctIndexOf(q)))
        }
        assertEquals(Phase.FINISHED, e.state().phase)
        assertEquals(FinishReason.QUESTIONS_DONE, e.result().reason)
        assertEquals(3, e.result().records.size)
    }

    @Test fun pausedTimeIsNotCounted() {
        val clock = FakeClock()
        val e = speed(clock, duration = 30)
        e.start()
        clock.advance(10_000)
        e.pause()
        clock.advance(120_000)
        e.tick()
        assertEquals(Phase.PAUSED, e.state().phase)
        e.resume()
        assertEquals(10_000L, e.elapsedMs())
        clock.advance(19_000); e.tick()
        assertEquals(Phase.ACTIVE, e.state().phase)
        clock.advance(2_000); e.tick()
        assertEquals(Phase.FINISHED, e.state().phase)
    }

    @Test fun answersWhilePausedAreRejected() {
        val clock = FakeClock()
        val e = speed(clock)
        e.start()
        val q = e.state().question!!
        e.pause()
        assertFalse(e.submit(q.id, Answer.Index(correctIndexOf(q))))
    }

    @Test fun reactionTimeStartsOnlyAtStimulusOnset() {
        for (seed in 1L..80L) {
            val clock = FakeClock()
            val e = newEngine(SelectiveReactionGame, config("selective_reaction", GameMode.SPEED, fixed = 1, seed = seed), clock)
            e.start()
            val q = e.state().question!!
            val b = q.body as ReactionBody
            if (!b.isTarget) continue
            clock.advance(b.preDelayMs)        // waiting period: must NOT be counted
            e.beginInput(q.id)
            clock.advance(321)
            assertTrue(e.submit(q.id, Answer.Reaction(tapped = true)))
            e.finish(FinishReason.USER_EXIT)
            assertEquals(321L, e.result().records[0].responseMs)
            return
        }
        error("no target trial found")
    }

    @Test fun prematureTapHasNoResponseTime() {
        for (seed in 1L..80L) {
            val clock = FakeClock()
            val e = newEngine(SelectiveReactionGame, config("selective_reaction", GameMode.SPEED, fixed = 1, seed = seed), clock)
            e.start()
            val q = e.state().question!!
            clock.advance(200)
            e.submit(q.id, Answer.Reaction(tapped = true, premature = true))
            e.finish(FinishReason.USER_EXIT)
            val r = e.result().records[0]
            assertNull(r.responseMs); assertFalse(r.correct)
            return
        }
    }

    @Test fun memoryQuestionsHaveNoTimerUntilInputBegins() {
        val clock = FakeClock()
        val e = newEngine(NumberMemoryGame, config("number_memory", GameMode.SPEED, fixed = 1), clock)
        e.start()
        val q = e.state().question!!
        val b = q.body as RecallBody
        clock.advance(5_000)                 // memorisation phase
        e.beginInput(q.id)
        clock.advance(1_500)
        e.submit(q.id, Answer.Typed(b.expected))
        e.finish(FinishReason.USER_EXIT)
        assertEquals(1500L, e.result().records[0].responseMs)
    }

    @Test fun fixedLevelNeverChangesDuringTheRound() {
        val clock = FakeClock()
        val e = newEngine(AdditionGame, config("addition", GameMode.SPEED, duration = 600, fixed = 4), clock)
        e.start()
        repeat(30) {
            val q = e.state().question!!
            clock.advance(300)
            e.submit(q.id, Answer.Index(correctIndexOf(q)))
            assertEquals(4, e.state().level)
        }
    }

    @Test fun adaptiveLevelRisesAfterStrongStreak() {
        val clock = FakeClock()
        val e = newEngine(AdditionGame, config("addition", GameMode.SPEED, duration = 600, fixed = null, startLevel = 2), clock)
        e.start()
        repeat(5) {
            val q = e.state().question!!
            clock.advance(400)
            e.submit(q.id, Answer.Index(correctIndexOf(q)))
        }
        assertEquals(3, e.state().level)
    }

    @Test fun resultSummaryIsConsistent() {
        val clock = FakeClock()
        val e = speed(clock, duration = 60)
        e.start()
        repeat(4) {
            val q = e.state().question!!
            clock.advance(1000)
            e.submit(q.id, Answer.Index(if (it % 2 == 0) correctIndexOf(q) else wrongIndexOf(q)))
        }
        e.finish(FinishReason.USER_EXIT)
        val r = e.result()
        assertEquals(2, r.correct); assertEquals(2, r.wrong); assertEquals(0.5, r.accuracy, 1e-9)
        assertEquals(r.records.sumOf { it.points }, r.score)
        assertEquals(SessionStatus.ABANDONED, r.status)
        assertNotNull(r.medianMs)
    }
}
