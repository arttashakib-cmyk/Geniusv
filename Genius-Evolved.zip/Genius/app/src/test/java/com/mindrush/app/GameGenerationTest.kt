package com.mindrush.app

import com.mindrush.app.game.*
import com.mindrush.app.game.games.*
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.random.Random

class GameGenerationTest {
    private fun forAll(block: (GameDefinition, Question, Int) -> Unit) {
        for (g in GameRegistry.all) for (level in 1..10) for (seed in 1..25) {
            val rng = Random(seed * 131L + level)
            val scratch = mutableMapOf<String, Any>()
            for (i in 1..6) {
                val q = g.generate(GenContext(level, rng, i, "t", g.id, scratch))
                block(g, q, level)
            }
        }
    }

    @Test fun registryHasUniqueGames() {
        assertEquals(36, GameRegistry.all.size)
        assertEquals(36, GameRegistry.all.map { it.id }.toSet().size)
        
    }

    @Test fun everyGameProducesStructurallyValidQuestions() {
        forAll { g, q, level ->
            assertEquals(level, q.level)
            val gid = if (g.id == "mental_chain") "mental_chain" else g.id
            assertEquals(gid, q.gameId)
            when (val b = q.body) {
                is ChoiceBody -> {
                    assertTrue(b.options.size >= 2)
                    assertEquals("duplicate options in ${g.id}", b.options.size, b.options.toSet().size)
                    assertTrue(b.correctIndex in b.options.indices)
                    assertTrue(b.explanation.isNotBlank())
                }
                is PickBody -> {
                    assertTrue(b.items.size >= 2)
                    assertTrue(b.correctIndex in b.items.indices)
                    assertTrue(b.columns >= 1)
                }
                is RecallBody -> {
                    assertTrue(b.steps.isNotEmpty() && b.expected.isNotEmpty() && b.showMsPerStep > 0)
                    assertTrue(b.steps.size <= 20)
                }
                is GridBody -> {
                    assertTrue(b.size in 3..5)
                    assertTrue(b.cells.isNotEmpty() && b.cells.all { it in 0 until b.size * b.size })
                }
                is ReactionBody -> assertTrue(b.windowMs > 0 && b.preDelayMs > 0)
            }
        }
    }

    @Test fun generationIsReproducibleForTheSameSeed() {
        for (g in GameRegistry.all) {
            val a = g.generate(GenContext(5, Random(99), 1, "s", g.id))
            val b = g.generate(GenContext(5, Random(99), 1, "s", g.id))
            assertEquals(g.id, a.body, b.body)
        }
    }

    @Test fun arithmeticAnswersMatchIndependentEvaluator() {
        val games = listOf(AdditionGame, SubtractionGame, MultiplicationGame, MixedOperationsGame)
        for (g in games) for (level in 1..10) for (seed in 1..60) {
            val q = g.generate(GenContext(level, Random(seed.toLong()), 1, "t", g.id))
            val b = q.body as ChoiceBody
            val expected = Arith.evaluate(b.expression!!)
            assertEquals("${g.id}: ${b.expression}", expected, b.options[b.correctIndex].toLong())
        }
    }

    @Test fun subtractionIsNonNegativeBeforeLevelEight() {
        for (level in 1..7) for (seed in 1..80) {
            val q = SubtractionGame.generate(GenContext(level, Random(seed.toLong()), 1, "t", "subtraction"))
            val b = q.body as ChoiceBody
            assertTrue(b.options[b.correctIndex].toLong() >= 0)
            assertTrue(b.options.all { it.toLong() >= 0 })
        }
    }

    @Test fun mixedOperationsDivisionIsAlwaysExact() {
        for (level in 1..10) for (seed in 1..80) {
            val q = MixedOperationsGame.generate(GenContext(level, Random(seed.toLong()), 1, "t", "mixed_ops"))
            val expr = (q.body as ChoiceBody).expression!!
            assertTrue(expr, Arith.evaluate(expr) != null)
        }
    }

    @Test fun sequencesHaveExactlyOneLogicalNextValue() {
        for (level in 1..10) for (seed in 1..80) {
            val q = NumberSequenceGame.generate(GenContext(level, Random(seed.toLong()), 1, "t", "number_sequence"))
            val b = q.body as ChoiceBody
            val terms = b.expression!!.split(",").map { it.trim() }.filter { it != "?" }.map { it.toLong() }
            val answer = b.options[b.correctIndex].toLong()
            assertEquals(b.expression, setOf(answer), NumberSequenceGame.candidateNext(terms))
        }
    }

    private fun parseRational(s: String): Pair<Long, Long> = when {
        s.endsWith("%") -> s.dropLast(1).toLong() to 100L
        s.contains("/") -> s.split("/").let { it[0].toLong() to it[1].toLong() }
        s.contains("×") -> s.split("×").let { it[0].toLong() * it[1].toLong() to 1L }
        s.contains("−") -> s.split("−").let { it[0].toLong() - it[1].toLong() to 1L }
        s.contains(".") -> s.split(".").let { val d = GamePow(it[1].length); (it[0].toLong() * d + it[1].toLong()) to d }
        else -> s.toLong() to 1L
    }

    private fun GamePow(n: Int): Long { var r = 1L; repeat(n) { r *= 10 }; return r }

    @Test fun numberComparisonAnswerKeysAreMathematicallyCorrect() {
        for (level in 1..10) for (seed in 1..120) {
            val q = NumberComparisonGame.generate(GenContext(level, Random(seed.toLong()), 1, "t", "number_comparison"))
            val b = q.body as ChoiceBody
            val (an, ad) = parseRational(b.glyphs[0].text)
            val (bn, bd) = parseRational(b.glyphs[1].text)
            val cmp = (an * bd).compareTo(bn * ad)
            val expected = if (cmp > 0) 0 else if (cmp < 0) 1 else 2
            assertEquals("${b.glyphs[0].text} vs ${b.glyphs[1].text}", expected, b.correctIndex)
        }
    }

    @Test fun spatialRotationHasExactlyOneRotatedOptionAndNoMirrorMatch() {
        for (level in 1..10) for (seed in 1..60) {
            val q = SpatialRotationGame.generate(GenContext(level, Random(seed.toLong()), 1, "t", "spatial_rotation"))
            val b = q.body as PickBody
            val n = b.target[0].gridSize
            val target = b.target[0].cells.toSet()
            val rotations = ShapeOps.rotations(target, n)
            val matching = b.items.indices.filter { i -> rotations.any { it == b.items[i].cells.toSet() } }
            assertEquals(listOf(b.correctIndex), matching)
            assertEquals(b.items.size, b.items.map { it.cells.toSet() }.toSet().size)
        }
    }

    @Test fun mirrorImageIsNotARotationForChiralShapes() {
        val rng = Random(5)
        var checked = 0
        for (i in 0 until 200) {
            val s = ShapeOps.randomShape(rng, 4, 6)
            if (!ShapeOps.isChiral(s, 4)) continue
            checked++
            assertTrue(ShapeOps.rotations(s, 4).none { it == ShapeOps.mirror(s, 4) })
        }
        assertTrue(checked > 0)
    }

    @Test fun rotatingFourTimesReturnsTheOriginal() {
        val s = setOf(0, 1, 5, 10)
        assertEquals(s, ShapeOps.rotate(s, 4, 4))
        assertEquals(ShapeOps.rotate(s, 4, 2), ShapeOps.rotate(ShapeOps.rotate(s, 4, 1), 4, 1))
    }

    @Test fun targetSearchHasExactlyOneTarget() {
        for (level in 1..10) for (seed in 1..60) {
            val q = TargetSearchGame.generate(GenContext(level, Random(seed.toLong()), 1, "t", "target_search"))
            val b = q.body as PickBody
            val t = b.target[0].text
            assertEquals(1, b.items.count { it.text == t })
            assertEquals(t, b.items[b.correctIndex].text)
        }
    }

    @Test fun rapidMatchAnswerKeyMatchesStrings() {
        for (level in 1..10) for (seed in 1..80) {
            val q = RapidMatchGame.generate(GenContext(level, Random(seed.toLong()), 1, "t", "rapid_match"))
            val b = q.body as ChoiceBody
            val same = b.glyphs[0].text == b.glyphs[1].text
            assertEquals(if (same) 0 else 1, b.correctIndex)
        }
    }

    @Test fun logicOrderingSolverFindsUniqueAnswers() {
        val worlds = LogicDeductionGame.consistentOrders(3, listOf(0 to 1, 1 to 2))
        assertEquals(1, worlds.size)
        assertEquals(listOf(0, 1, 2), worlds[0])
        assertEquals(3, LogicDeductionGame.consistentOrders(3, listOf(0 to 1)).size)
    }

    @Test fun ruleSwitchAnnouncesTheFirstRuleAndLaterSwitches() {
        val scratch = mutableMapOf<String, Any>()
        val rng = Random(3)
        var banners = 0
        for (i in 1..40) {
            val q = RuleSwitchGame.generate(GenContext(4, rng, i, "t", "rule_switch", scratch))
            val b = q.body as PickBody
            assertTrue(b.rule != null)
            if (i == 1) assertTrue(b.banner != null)
            if (b.banner != null) banners++
        }
        assertTrue(banners >= 3)
    }

    @Test fun mentalChainRotatesComponentsAndKeepsSubGame() {
        val scratch = mutableMapOf<String, Any>()
        val rng = Random(11)
        val seen = mutableSetOf<String>()
        for (i in 1..8) {
            val q = MentalChainGame.generate(GenContext(3, rng, i, "t", "mental_chain", scratch))
            assertEquals("mental_chain", q.gameId)
            assertTrue(q.subGameId != null && GameRegistry.byId(q.subGameId!!) != null)
            seen.add(q.component!!)
        }
        assertEquals(4, seen.size)
    }

    @Test fun selectiveReactionHasBothTargetAndNonTargetTrials() {
        var targets = 0; var others = 0
        val rng = Random(2)
        for (i in 1..100) {
            val b = SelectiveReactionGame.generate(GenContext(5, rng, i, "t", "selective_reaction")).body as ReactionBody
            if (b.isTarget) targets++ else others++
        }
        assertTrue(targets > 20 && others > 20)
    }
}
