package com.mindrush.app

import com.mindrush.app.core.Fa
import com.mindrush.app.domain.DayStreak
import org.junit.Assert.assertEquals
import org.junit.Test
import java.time.LocalDate

class FaTest {
    @Test fun toPersianDigits() = assertEquals("۱۲۳۴۵۶۷۸۹۰", Fa.toPersianDigits("1234567890"))

    @Test fun normalizesPersianAndArabicDigits() {
        assertEquals("123.5", Fa.normalizeDigits("۱۲۳٫۵"))
        assertEquals("4567", Fa.normalizeDigits("٤٥٦٧"))
        assertEquals("-12", Fa.normalizeDigits("\u2212۱۲"))
    }

    @Test fun formatHonoursSetting() {
        assertEquals("۳٫۵ + ۲", Fa.format("3.5 + 2", true))
        assertEquals("3.5 + 2", Fa.format("3.5 + 2", false))
    }

    @Test fun dayStreakCountsConsecutiveDays() {
        val today = LocalDate.of(2026, 10, 13)
        assertEquals(3, DayStreak.compute(listOf("2026-10-13", "2026-10-12", "2026-10-11", "2026-10-08"), today))
        assertEquals(2, DayStreak.compute(listOf("2026-10-12", "2026-10-11"), today))
        assertEquals(0, DayStreak.compute(listOf("2026-10-10"), today))
        assertEquals(0, DayStreak.compute(emptyList(), today))
    }

    @Test fun dayKeyUsesConfiguredZone() {
        val ms = 1_760_397_600_000L // 2025-10-13T23:20:00Z
        val tehran = DayStreak.dayKey(ms, "Asia/Tehran")
        val utc = DayStreak.dayKey(ms, "UTC")
        assertEquals("2025-10-14", tehran)
        assertEquals("2025-10-13", utc)
    }
}
